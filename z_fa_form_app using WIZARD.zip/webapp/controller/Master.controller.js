sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"faf/tmc/z_fa_form_app/util/dataManagerLib",
	'sap/ui/core/Fragment',
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/ValidateException",
	'sap/m/MessageBox',
	'sap/m/MessageToast',
	'sap/m/Token',
	"sap/m/Button",
	"sap/m/Dialog",
	'sap/ui/model/FilterOperator',
	'sap/ui/model/Filter',
	"sap/m/Text"
], function (Controller, dataManagerLib, Fragment, JSONModel, ValidateException, MessageBox, MessageToast, Token, Button, Dialog,
	FilterOperator, Filter, Text) {
	"use strict";

	return Controller.extend("faf.tmc.z_fa_form_app.controller.Master", {
		// enabledObj: {}, 
		getAllData: {},
		oItemss: [],
		ParticipateRowId: {
			id: ""
		},
		AnnexureARowId: {
			id: ""
		},
		AnnexureBRowId: {
			id: ""
		},
		AnnexureDRowId: {
			id: ""
		},
		AnnexureERowId: {
			id: ""
		},
		AnnexureFRowId: {
			id: ""
		},
		AnnexureGRowId: {
			id: ""
		},
		AnnexureHRowId: {
			id: ""
		},
		SectionDTableRowId: {
			id: ""
		},
		SectionETableRowId: {
			id: ""
		},
		SectionE2TableRowId: {
			id: ""
		},
		onInit: function () {
			var that = this;

			that._wizard = this.byId("itb1");
			that._oNavContainer = this.byId("app");

			var oPersonalDataModel = new JSONModel();
			that.getView().setModel(oPersonalDataModel, "oPersonalDataModel");

			var Attachments = new JSONModel();
			that.getView().setModel(Attachments, "Attachments");

			var oInfoModel = new JSONModel();
			that.getView().setModel(oInfoModel, "oInfoModel");

			var oStuInfoModel = new JSONModel();
			that.getView().setModel(oStuInfoModel, "oStuInfoModel");

			var GenderModel = new JSONModel();
			that.getView().setModel(GenderModel, "GenderModel");

			var oAllDataModel = new JSONModel();
			that.getView().setModel(oAllDataModel, "oAllDataModel");
			var oSectionBModel = new JSONModel();
			that.getView().setModel(oSectionBModel, "oSectionBModel");
			var oSectionBTblModel = new JSONModel();
			that.getView().setModel(oSectionBTblModel, "oSectionBTblModel");
			var oSectionCModel = new JSONModel();
			that.getView().setModel(oSectionCModel, "oSectionCModel");
			var oSectionDModel = new JSONModel();
			that.getView().setModel(oSectionDModel, "oSectionDModel");
			var oSectionDTBLModel = new JSONModel();
			that.getView().setModel(oSectionDTBLModel, "oSectionDTBLModel");
			var oSectionEModel = new JSONModel();
			that.getView().setModel(oSectionEModel, "oSectionEModel");
			var oSctionETbl1Model = new JSONModel();
			that.getView().setModel(oSctionETbl1Model, "oSectionETbl1Model");
			var oSectionETbl2Model = new JSONModel();
			that.getView().setModel(oSectionETbl2Model, "oSectionETbl2Model");
			var oSectionFModel = new JSONModel();
			that.getView().setModel(oSectionFModel, "oSectionFModel");
			var oSectionGModel = new JSONModel();
			that.getView().setModel(oSectionGModel, "oSectionGModel");
			var oAnnexureAModel = new JSONModel();
			that.getView().setModel(oAnnexureAModel, "oAnnexureAModel");
			var oAnnexureBModel = new JSONModel();
			that.getView().setModel(oAnnexureBModel, "oAnnexureBModel");
			var oAnnexureCModel = new JSONModel();
			that.getView().setModel(oAnnexureCModel, "oAnnexureCModel");
			var oAnnexureDModel = new JSONModel();
			that.getView().setModel(oAnnexureDModel, "oAnnexureDModel");
			var oAnnexureEModel = new JSONModel();
			that.getView().setModel(oAnnexureEModel, "oAnnexureEModel");
			var oAnnexureFModel = new JSONModel();
			that.getView().setModel(oAnnexureFModel, "oAnnexureFModel");
			var oAnnexureGModel = new JSONModel();
			that.getView().setModel(oAnnexureGModel, "oAnnexureGModel");
			var oAnnexureHModel = new JSONModel();
			that.getView().setModel(oAnnexureHModel, "oAnnexureHModel");

		},

		onAfterRendering: function () {
			var oModel = new sap.ui.model.json.JSONModel();
			var oShell = sap.ui.getCore().byId('Shell');

			// //Get Header Data
			// dataManagerLib.getHeaderData(
			// 	function (response) {
			// 		var oStudentData = JSON.parse(response.EPrsldata);
			// 		var oStudentModel = new JSONModel(oStudentData);
			// 		oShell.setModel(oStudentModel, "oStudentModel");
			// 	},
			// 	function (error) {});

			//Get Header Data
			dataManagerLib.getHeaderData(
				function (response) {
					// var oStudentData = JSON.parse(response.results);
					var oStudentData = response.results;
					oStudentData.forEach(function (oValue) {
						//Student Data 
						if (oValue.Key === 'Header') {
							var oStudentHeader = JSON.parse(oValue.Value);
							if (oStudentHeader.GEOGRAPHIC === 'Major Cities') {
								oStudentHeader.GEOGRAPHIC = 'MajorCities';
							} else if (oStudentHeader.GEOGRAPHIC === 'other towns and rural valleys') {
								oStudentHeader.GEOGRAPHIC = 'othertownsandruralvalleys';
							} else if (oStudentHeader.GEOGRAPHIC === 'High altitude rural areas') {
								oStudentHeader.GEOGRAPHIC = 'Highaltituderuralareas';
							}

							var oPersonalDataModel = new JSONModel(oStudentHeader);
							sap.ui.getCore().byId('Master').setModel(oPersonalDataModel, "oPersonalDataModel");

						}

						//Attachment
						if (oValue.Key === 'Attachments') {
							var oAttachmentData = JSON.parse(oValue.Value);
							var Attachments = new JSONModel(oAttachmentData);
							sap.ui.getCore().byId('Master').setModel(Attachments, "Attachments");
							// oShell.setModel(oAllDataModel, "oAllDataModel");
							// sap.ui.getCore().byId('Master').getModel('oAllDataModel').refresh();
						}

						//All Data
						if (oValue.Key === 'All Data') {
							var oAllData = JSON.parse(oValue.Value);

							var oAllDataModel = new JSONModel(oAllData);
							sap.ui.getCore().byId('Master').setModel(oAllDataModel, "oAllDataModel");
							// oShell.setModel(oAllDataModel, "oAllDataModel");
							// sap.ui.getCore().byId('Master').getModel('oAllDataModel').refresh();
						}

						//Section B Data
						if (oValue.Key === 'Sec B') {
							var oSecBData = JSON.parse(oValue.Value);
							var oSectionBModel = new JSONModel(oSecBData);
							sap.ui.getCore().byId('Master').setModel(oSectionBModel, "oSectionBModel");
							// oShell.setModel(oSectionBModel, "oSectionBModel");
							// sap.ui.getCore().byId('Master').getModel('oSectionBModel').refresh();
						}

						//Section B Table Data
						if (oValue.Key === 'Sec B Tbl') {
							var oSecBTblData = JSON.parse(oValue.Value);
							var oSectionBTblModel = new JSONModel(oSecBTblData);
							sap.ui.getCore().byId('Master').setModel(oSectionBTblModel, "oSectionBTblModel");
							// oShell.setModel(oSectionBTblModel, "oSectionBTblModel");
							// sap.ui.getCore().byId('Master').getModel('oSectionBTblModel').refresh();
						}

						//Section C Data
						if (oValue.Key === 'Sec C') {
							var oSecCData = JSON.parse(oValue.Value);
							var oSectionCModel = new JSONModel(oSecCData);
							sap.ui.getCore().byId('Master').setModel(oSectionCModel, "oSectionCModel");
							// oShell.setModel(oSectionCModel, "oSectionCModel");
							// sap.ui.getCore().byId('Master').getModel('oSectionCModel').refresh();
						}

						//Section D Data
						if (oValue.Key === 'Sec D') {
							var oSecDData = JSON.parse(oValue.Value);
							var oSectionDModel = new JSONModel(oSecDData);
							sap.ui.getCore().byId('Master').setModel(oSectionDModel, "oSectionDModel");
							// oShell.setModel(oSectionDModel, "oSectionDModel");
							// sap.ui.getCore().byId('Master').getModel('oSectionDModel').refresh();
						}

						//Section D Table Data
						if (oValue.Key === 'Sec D Tbl') {
							var oSecDTblData = JSON.parse(oValue.Value);
							var oSectionDTBLModel = new JSONModel(oSecDTblData);
							sap.ui.getCore().byId('Master').setModel(oSectionDTBLModel, "oSectionDTBLModel");
							// oShell.setModel(oSectionDTBLModel, "oSectionDTBLModel");
							// sap.ui.getCore().byId('Master').getModel('oSectionDTBLModel').refresh();
						}

						//Section E Data
						if (oValue.Key === 'Sec E') {
							var oSecEData = JSON.parse(oValue.Value);
							var oSectionEModel = new JSONModel(oSecEData);
							sap.ui.getCore().byId('Master').setModel(oSectionEModel, "oSectionEModel");
							// oShell.setModel(oSectionEModel, "oSectionEModel");
							// sap.ui.getCore().byId('Master').getModel('oSectionEModel').refresh();
						}

						//Section E 1 Table Data
						if (oValue.Key === 'Sec E 1') {
							var oSecE1Data = JSON.parse(oValue.Value);
							var oSectionETbl1Model = new JSONModel(oSecE1Data);
							sap.ui.getCore().byId('Master').setModel(oSectionETbl1Model, "oSectionETbl1Model");
							// oShell.setModel(oSectionETbl1Model, "oSectionETbl1Model");
							// sap.ui.getCore().byId('Master').getModel('oSectionETbl1Model').refresh();
						}

						//Section E 2 Table Data
						if (oValue.Key === 'Sec E 2') {
							var oSecE2Data = JSON.parse(oValue.Value);
							var oSectionETbl2Model = new JSONModel(oSecE2Data);
							sap.ui.getCore().byId('Master').setModel(oSectionETbl2Model, "oSectionETbl2Model");
							// oShell.setModel(oSectionETbl2Model, "oSectionETbl2Model");
							// sap.ui.getCore().byId('Master').getModel('oSectionETbl2Model').refresh();
						}

						//Section F Data
						if (oValue.Key === 'Sec F') {
							var oSecFData = JSON.parse(oValue.Value);
							var oSectionFModel = new JSONModel(oSecFData);
							sap.ui.getCore().byId('Master').setModel(oSectionFModel, "oSectionFModel");
							// oShell.setModel(oSectionFModel, "oSectionFModel");
							// sap.ui.getCore().byId('Master').getModel('oSectionFModel').refresh();
						}

						//Annexure A Data
						if (oValue.Key === 'Ann A') {
							var oAnxAData = JSON.parse(oValue.Value);
							var oAnnexureAModel = new JSONModel(oAnxAData);
							sap.ui.getCore().byId('Master').setModel(oAnnexureAModel, "oAnnexureAModel");
							// oShell.setModel(oAnnexureAModel, "oAnnexureAModel");
							// sap.ui.getCore().byId('Master').getModel('oAnnexureAModel').refresh();
						}

						//Annexure B Data
						if (oValue.Key === 'Ann B') {
							var oAnxBData = JSON.parse(oValue.Value);
							var oAnnexureBModel = new JSONModel(oAnxBData);
							sap.ui.getCore().byId('Master').setModel(oAnnexureBModel, "oAnnexureBModel");
							// oShell.setModel(oAnnexureBModel, "oAnnexureBModel");
							// sap.ui.getCore().byId('Master').getModel('oAnnexureBModel').refresh();
						}

						//Annexure C Data
						if (oValue.Key === 'Ann C') {
							var oAnxCData = JSON.parse(oValue.Value);
							var oAnnexureCModel = new JSONModel(oAnxCData);
							sap.ui.getCore().byId('Master').setModel(oAnnexureCModel, "oAnnexureCModel");
							// oShell.setModel(oAnnexureCModel, "oAnnexureCModel");
							// sap.ui.getCore().byId('Master').getModel('oAnnexureCModel').refresh();
						}

						//Annexure D Data
						if (oValue.Key === 'Ann D') {
							var oAnxDData = JSON.parse(oValue.Value);
							var oAnnexureDModel = new JSONModel(oAnxDData);
							sap.ui.getCore().byId('Master').setModel(oAnnexureDModel, "oAnnexureDModel");
							// oShell.setModel(oAnnexureDModel, "oAnnexureDModel");
							// sap.ui.getCore().byId('Master').getModel('oAnnexureDModel').refresh();
						}

						//Annexure E Data
						if (oValue.Key === 'Ann E') {
							var oAnxEData = JSON.parse(oValue.Value);
							var oAnnexureEModel = new JSONModel(oAnxEData);
							sap.ui.getCore().byId('Master').setModel(oAnnexureEModel, "oAnnexureEModel");
							// oShell.setModel(oAnnexureEModel, "oAnnexureEModel");
							// sap.ui.getCore().byId('Master').getModel('oAnnexureEModel').refresh();
						}

						//Annexure F Data
						if (oValue.Key === 'Ann F') {
							var oAnxFData = JSON.parse(oValue.Value);
							var oAnnexureFModel = new JSONModel(oAnxFData);
							sap.ui.getCore().byId('Master').setModel(oAnnexureFModel, "oAnnexureFModel");
							// oShell.setModel(oAnnexureFModel, "oAnnexureFModel");
							// sap.ui.getCore().byId('Master').getModel('oAnnexureFModel').refresh();
						}

						//Annexure G Data
						if (oValue.Key === 'Ann G') {
							var oAnxGData = JSON.parse(oValue.Value);
							var oAnnexureGModel = new JSONModel(oAnxGData);
							sap.ui.getCore().byId('Master').setModel(oAnnexureGModel, "oAnnexureGModel");
							// oShell.setModel(oAnnexureGModel, "oAnnexureGModel");
							// sap.ui.getCore().byId('Master').getModel('oAnnexureGModel').refresh();
						}

						//Annexure H Data
						if (oValue.Key === 'Ann H') {
							var oAnxHData = JSON.parse(oValue.Value);
							var oAnnexureHModel = new JSONModel(oAnxHData);
							sap.ui.getCore().byId('Master').setModel(oAnnexureHModel, "oAnnexureHModel");
							// oShell.setModel(oAnnexureHModel, "oAnnexureHModel");
							// sap.ui.getCore().byId('Master').getModel('oAnnexureHModel').refresh();
						}

						//Empty Data Send to Launchpad
						if (oValue.Key === 'Empty') {
							var dialog2 = new Dialog({
								title: 'Information',
								type: 'Message',
								state: 'Information',
								content: new Text({
									text: 'You do not have Financial Aid',
								}),
								beginButton: new Button({
									type: sap.m.ButtonType.Emphasized,
									text: 'OK',
									press: function () {
										// sap.ui.getCore().byId("homeBtn").onclick();
										var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

										// Navigate back to FLP home
										oCrossAppNavigator.toExternal({
											target: {
												shellHash: "#"
											}
										});
										dialog2.close();
									}
								}),
							});
							dialog2.open();

						}
					});

					// var oStudentModel = new JSONModel(oStudentData);
					// oShell.setModel(oStudentModel, "oStudentModel");
				},
				function (error) {
					var dialog1 = new Dialog({
						title: 'Confirm',
						type: 'Message',
						state: 'Success',
						content: new Text({
							text: 'You do not have Financial Aid',
						}),
						beginButton: new Button({
							type: sap.m.ButtonType.Emphasized,
							text: 'OK',
							press: function () {
								// sap.ui.getCore().byId("homeBtn").onclick();
								var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

								// Navigate back to FLP home
								oCrossAppNavigator.toExternal({
									target: {
										shellHash: "#"
									}
								});
								dialog1.close();
							}
						}),
					});
					dialog1.open();
				});

		},
		additionalInfoValidation: function (oEvent) {
			var that = this;
			// var oShell = sap.ui.getCore().byId('Shell');
			//Personal Information
			var InfoModel = that.getView().getModel("oPersonalDataModel").getData();

			var first_name = this.byId('first_name').getValue();
			var Mid_Name = this.byId('Mid_Name').getValue();
			var Last_Name = this.byId('Last_Name').getValue();
			var date_birth = this.byId('date_birth').getValue();
			var date_issue = this.byId('date_issue').getValue();
			var date_of_Expiry = this.byId('date_of_Expiry').getValue();
			var Citizen_Ship = this.byId('Citizen_Ship').getValue();
			var P_city = this.byId("P_city").getValue();
			var P_Town = this.byId("P_Town").getValue();
			var Identification_Number = this.byId('Identification_Number').getValue();
			var Issued_By = this.byId('Issued_By').getValue();
			var Current_Residence = this.byId('Current_Residence').getValue();
			var Permanent_Address = this.byId('Permanent_Address').getValue();
			// var getView_city = this.getView().byId("City");
			// var City = getView_city.mProperties.selectedKey;
			var Email_Address = this.byId('Email_Address').getValue();
			var parent_email = this.byId('P_Email_Address').getValue();
			var Home_Phone = this.byId('Home_Phone').getValue();
			var Mobile_Phone = this.byId('Mobile_Phone').getValue();

			// var Gender = this.byId('Gender').getSelectedButton().getText();
			var Gender = "";
			if (this.byId('Gender').getSelectedItem() === '' || this.byId('Gender').getSelectedItem() === null) {} else {
				Gender = this.byId('Gender').getSelectedItem().getProperty('text');
			}

			// var Student_Marital_Status = this.byId('Student_Martial_Status').getSelectedButton().getText();
			var Student_Marital_Status = "";
			if (this.byId('Student_Martial_Status').getSelectedItem() === '' || this.byId('Student_Martial_Status').getSelectedItem() === null) {} else {
				Student_Marital_Status = this.byId('Student_Martial_Status').getSelectedItem().getProperty('text');
			}

			// var Parent_Current_Marital_Status = this.byId('Parent_Martial_Status').getSelectedButton().getText();
			var Parent_Current_Marital_Status = "";
			if (this.byId('Parent_Martial_Status').getSelectedItem() === '' || this.byId('Parent_Martial_Status').getSelectedItem() === null) {} else {
				Parent_Current_Marital_Status = this.byId('Parent_Martial_Status').getSelectedItem().getProperty('text');
			}

			var Geographic = "";
			if (this.byId('Geographic').getSelectedItem() === '' || this.byId('Geographic').getSelectedItem() === null) {} else {
				Geographic = this.byId('Geographic').getSelectedItem().getProperty('text');
			}

			var PersonalInformation = {
				"OBJID": InfoModel.OBJID,
				"PRE_APP_NO": InfoModel.PRE_APP_NO,
				"VORNA": first_name,
				"MIDNM": Mid_Name,
				"NACHN": Last_Name,
				"GBDAT": date_birth,
				"NATIO": Citizen_Ship,
				"GBORT": P_city,
				"GBLND": P_Town,
				"PASSN": Identification_Number,
				"GESCH": Gender,
				"FAMST": Student_Marital_Status,
				"P_FAMST": Parent_Current_Marital_Status,
				"PASS_ISSUEPLACE": Issued_By,
				"PASS_ISSUEDATE": date_issue,
				"PASS_EXPIRYDATE": date_of_Expiry,
				"ADDRESS": Current_Residence,
				"PRMT_ADDRESS": Permanent_Address,
				"GEOGRAPHIC": Geographic,
				"EMAIL": Email_Address,
				"P_EMAIL": parent_email,
				"HOM_NUMBER": Home_Phone,
				"MOB_NUMBER": Mobile_Phone,
			};

			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyy-MM-dd"
			});
			PersonalInformation.GBDAT = dateFormat.format(new Date(PersonalInformation.GBDAT));
			PersonalInformation.PASS_ISSUEDATE = dateFormat.format(new Date(PersonalInformation.PASS_ISSUEDATE));
			PersonalInformation.PASS_EXPIRYDATE = dateFormat.format(new Date(PersonalInformation.PASS_EXPIRYDATE));
			// var PersonalInfoModel = new JSONModel(PersonalInformation);
			// that.getView().setModel(PersonalInfoModel, "PersonalInfoModel");
			// var a = this.getView().getModel("PersonalInfoModel").getData();
			// this.getView().getModel("oStudentModel").setData(a);

			//
			// var oStuInfoModel = new JSONModel(PersonalInformation);
			this.getView().getModel('oStuInfoModel').setData(PersonalInformation);

			var IPersonalInfoJSON = JSON.stringify(PersonalInformation);

			// var oStudentHeader = JSON.parse(oValue.Value);
			// var oInfoModel = new JSONModel(IPersonalInfoJSON);
			// sap.ui.getCore().byId('Master').setModel(oInfoModel, "oInfoModel");

			this.getView().getModel('oInfoModel').setData(IPersonalInfoJSON);

			this.getView().getModel('oInfoModel').refresh();

			// var PersonalInformation = that.getView().getModel("PersonalInformation").getData();

			var oAttachment = that.getView().getModel("Attachments").getData()[0];
			var IAttachmentDataJSON = JSON.stringify(oAttachment);
			// tab 1

			//ISecB - object ke andar yeh yeh fields hon gi		
			var oCurrency = this.byId("CurrencyID").getValue();
			var TotalnoMember = this.byId("TotalnoMemberID").getValue();
			var EarningMembers = this.byId("EarningMembersID").getValue();
			var NonEarningMember = this.byId("NonEarningMemberID").getValue();
			var RetiredMembers = this.byId("RetiredMembersID").getValue();
			var MembersAttendingSchool = this.byId("MembersAttendingSchoolID").getValue();
			var MembersDisablility = this.byId("MembersDisablilityID").getValue();

			var ISecB = {
				"CURRENCY": oCurrency,
				"TMHLD": TotalnoMember,
				"ERNMB": EarningMembers,
				"NERMB": NonEarningMember,
				"RETMB": RetiredMembers,
				"MASCU": MembersAttendingSchool,
				"MBDIS": MembersDisablility,
			};
			var ISecBJSON = JSON.stringify(ISecB);
			this.getView().getModel('oSectionBModel').setData(ISecB);
			this.getView().getModel('oSectionBModel').refresh();

			//ISecB - object ke andar yeh yeh fields hon gi		

			//ISecBTbl - Section B Table Data
			var oSectB = this.byId("SectionBTbl").mAggregations.items["length"];
			var ISecBTbl = [];
			for (var b = 0; b < oSectB; b++) {
				var oSBName = this.byId('SectionBTbl').mAggregations.items[b].mAggregations.cells[0].mProperties.value;
				var oSBRelation = this.byId('SectionBTbl').mAggregations.items[b].mAggregations.cells[1].mProperties.value;
				var oSBAge = this.byId('SectionBTbl').mAggregations.items[b].mAggregations.cells[2].mProperties.value;
				var oSBMaritalStatus = this.byId('SectionBTbl').mAggregations.items[b].mAggregations.cells[3].mProperties.value;
				var oSBEconomicStatus = this.byId('SectionBTbl').mAggregations.items[b].mAggregations.cells[4].mProperties.value;
				var oSBPhysicalStatus = this.byId('SectionBTbl').mAggregations.items[b].mAggregations.cells[5].mProperties.value;
				var oSBLivingwithHouseHold = this.byId('SectionBTbl').mAggregations.items[b].mAggregations.cells[6].mProperties.value;

				var oObjectSecBTable = {
					"NAME": oSBName,
					"RELSH": oSBRelation,
					"AGE": oSBAge,
					"MRTST": oSBMaritalStatus,
					"ECOST": oSBEconomicStatus,
					"PHSST": oSBPhysicalStatus,
					"LIVWH": oSBLivingwithHouseHold
				};
				ISecBTbl.push(oObjectSecBTable);
			}
			var ISecBTblJSON = JSON.stringify(ISecBTbl);
			this.getView().getModel('oSectionBTblModel').setData(ISecBTbl);
			this.getView().getModel('oSectionBTblModel').refresh();
			//ISecBTbl - Section B Table Data

			//IAnxA - Annexure A Data
			var oAnxAA = this.byId("SectionBAnnexureATbl").mAggregations.items["length"];
			var IAnxA = [];
			var oAnnexureAAnnualSalary = 0;
			var oAnnexureAInvest = 0;
			var oAnnexureAOther = 0;
			for (var b = 0; b < oAnxAA; b++) {
				var oAAName = this.byId('SectionBAnnexureATbl').mAggregations.items[b].mAggregations.cells[0].mProperties.value;
				var oAATypeOfWork = this.byId('SectionBAnnexureATbl').mAggregations.items[b].mAggregations.cells[1].mProperties.value;
				var oAANAPOE = this.byId('SectionBAnnexureATbl').mAggregations.items[b].mAggregations.cells[2].mProperties.value;
				var oAAANLIN_FSALRY = this.byId('SectionBAnnexureATbl').mAggregations.items[b].mAggregations.cells[3].mProperties.value;
				var oAAANLIN_INVEST = this.byId('SectionBAnnexureATbl').mAggregations.items[b].mAggregations.cells[4].mProperties.value;
				var oAAOTHIN = this.byId('SectionBAnnexureATbl').mAggregations.items[b].mAggregations.cells[5].mProperties.value;

				var oObjectAnnexureATable = {
					"NAME": oAAName,
					"TYWRK": oAATypeOfWork,
					"NAPOE": oAANAPOE,
					"ANLIN_FSALRY": oAAANLIN_FSALRY,
					"ANLIN_INVEST": oAAANLIN_INVEST,
					"OTHIN": oAAOTHIN
				};
				oAnnexureAAnnualSalary = parseInt(oAnnexureAAnnualSalary) + parseInt(oAAANLIN_FSALRY);
				oAnnexureAInvest = parseInt(oAnnexureAInvest) + parseInt(oAAANLIN_INVEST);
				oAnnexureAOther = parseInt(oAnnexureAOther) + parseInt(oAAOTHIN);
				IAnxA.push(oObjectAnnexureATable);
			}

			this.byId("IncomefromSalaryandBusinessCID").setValue(oAnnexureAAnnualSalary);
			this.byId("IncomefromInvestmentsCID").setValue(oAnnexureAInvest);
			this.byId("OtherIncomeCID").setValue(oAnnexureAOther);

			var IAnxAJSON = JSON.stringify(IAnxA);
			this.getView().getModel('oAnnexureAModel').setData(IAnxA);
			this.getView().getModel('oAnnexureAModel').refresh();
			//IAnxA - Annexure A Data

			//IAnxB - Annexure B Data 
			var oAnxAB = this.byId("SectionBAnnexureBTbl").mAggregations.items["length"];
			var IAnxB = [];
			var oAnnexureBAnnualCost = 0;
			var oAnnexureBAnnualFinancial = 0;
			for (var b = 0; b < oAnxAB; b++) {
				var oABNAME = this.byId('SectionBAnnexureBTbl').mAggregations.items[b].mAggregations.cells[0].mProperties.value;
				var oABCLSTD = this.byId('SectionBAnnexureBTbl').mAggregations.items[b].mAggregations.cells[1].mProperties.value;
				var oABNAIAC = this.byId('SectionBAnnexureBTbl').mAggregations.items[b].mAggregations.cells[2].mProperties.value;
				var oABANCST = this.byId('SectionBAnnexureBTbl').mAggregations.items[b].mAggregations.cells[3].mProperties.value;
				// var oABANFAD = this.byId('SectionBAnnexureBTbl').mAggregations.items[b].mAggregations.cells[4].getProperty("selected") ===
				// 	true ? "x" : "";
				// var oABSOFAD = this.byId('SectionBAnnexureBTbl').mAggregations.items[b].mAggregations.cells[5].getProperty("selected") ===
				// 	true ? "x" : "";
				var oABANFAD = this.byId('SectionBAnnexureBTbl').mAggregations.items[b].mAggregations.cells[4].mProperties.value;

				var oABSOFAD = this.byId('SectionBAnnexureBTbl').mAggregations.items[b].mAggregations.cells[5].mProperties.value;
				// var oABSOFAD = this.byId('SectionBAnnexureBTbl').mAggregations.items[b].mAggregations.cells[5].getProperty('selectedKey')

				var oABIS_PRIVATE = this.byId('SectionBAnnexureBTbl').mAggregations.items[b].mAggregations.cells[6].getProperty('selectedKey')

				var oABROAD = this.byId('SectionBAnnexureBTbl').mAggregations.items[b].mAggregations.cells[7].getProperty('selectedKey')

				var oABSELF_EDUCATION = this.byId('SectionBAnnexureBTbl').mAggregations.items[b].mAggregations.cells[8].getProperty('selectedKey')

				// var oABIS_PRIVATE = this.byId('SectionBAnnexureBTbl').mAggregations.items[b].mAggregations.cells[6].getProperty("selected") ===
				// 	true ? "x" : "";
				// var oABROAD = this.byId('SectionBAnnexureBTbl').mAggregations.items[b].mAggregations.cells[7].getProperty("selected") ===
				// 	true ? "x" : "";
				// var oABSELF_EDUCATION = this.byId('SectionBAnnexureBTbl').mAggregations.items[b].mAggregations.cells[8].getProperty("selected") ===
				// 	true ? "x" : "";

				var oObjectAnnexureBTable = {
					"NAME": oABNAME,
					"CLSTD": oABCLSTD,
					"NAIAC": oABNAIAC,
					"ANCST": oABANCST,
					"ANFAD": oABANFAD,
					"SOFAD": oABSOFAD,
					"IS_PRIVATE": oABIS_PRIVATE,
					"ABROAD": oABROAD,
					"SELF_EDUCATION": oABSELF_EDUCATION,
				};
				oAnnexureBAnnualCost = parseInt(oAnnexureBAnnualCost) + parseInt(oABANCST);
				// oAnnexureBAnnualFinancial = parseInt(oAnnexureBAnnualFinancial) + parseInt(oABANFAD);
				oAnnexureBAnnualFinancial = parseInt(oAnnexureBAnnualFinancial) + parseInt(oABANFAD);
				IAnxB.push(oObjectAnnexureBTable);
			}

			this.byId("EducationExpenditureCID").setValue(oAnnexureBAnnualCost);
			this.byId("FinancialAidReceivedCID").setValue(oAnnexureBAnnualFinancial);

			var IAnxBJSON = JSON.stringify(IAnxB);
			this.getView().getModel('oAnnexureBModel').setData(IAnxB);
			this.getView().getModel('oAnnexureBModel').refresh();
			//IAnxB - Annexure B Data

			//IAnxC - Annexure C Data
			var HouseRent = this.byId("HouseRentID").getValue();
			var UtilitiesElectric = this.byId("UtilitiesElectricID").getValue();
			var UtilitiesWater = this.byId("UtilitiesWaterID").getValue();
			var UtilitiesTele = this.byId("UtilitiesTeleID").getValue();
			var GovtTax = this.byId("GovtTaxID").getValue();
			var FoodandGrocery = this.byId("FoodandGroceryID").getValue();
			var InsuranceHealth = this.byId("InsuranceHealthID").getValue();
			var Transportation = this.byId("TransportationID").getValue();
			var VehicleMaintenance = this.byId("VehicleMaintenanceID").getValue();
			var MedicalExpenses = this.byId("MedicalExpensesID").getValue();
			var DentalCare = this.byId("DentalCareID").getValue();
			var Clothing = this.byId("ClothingID").getValue();
			var FitnessPersonal = this.byId("FitnessPersonalID").getValue();
			var DiningEntertainment = this.byId("DiningEntertainmentID").getValue();
			var Vacations = this.byId("VacationsID").getValue();
			var Travel = this.byId("TravelID").getValue();
			var LoanRepayment = this.byId("LoanRepaymentID").getValue();
			var SalaryPaid = this.byId("SalaryPaidID").getValue();
			var DonationCharity = this.byId("DonationCharityID").getValue();
			var OtherExpenses = this.byId("OtherExpensesID").getValue();
			var OtherExpenses2 = this.byId("OtherExpenses2ID").getValue();
			var OtherExpenses3 = this.byId("OtherExpenses3ID").getValue();

			var oAnxCTotal;

			if (HouseRent !== "" &&
				UtilitiesElectric !== "" &&
				UtilitiesWater !== "" &&
				UtilitiesTele !== "" &&
				GovtTax !== "" &&
				FoodandGrocery !== "" &&
				InsuranceHealth !== "" &&
				Transportation !== "" &&
				VehicleMaintenance !== "" &&
				MedicalExpenses !== "" &&
				DentalCare !== "" &&
				Clothing !== "" &&
				FitnessPersonal !== "" &&
				DiningEntertainment !== "" &&
				Vacations !== "" &&
				Travel !== "" &&
				LoanRepayment !== "" &&
				SalaryPaid !== "" &&
				DonationCharity !== "" &&
				OtherExpenses !== "" &&
				OtherExpenses2 !== "" &&
				OtherExpenses3 !== ""
			) {
				var oAnxCTotal = parseInt(HouseRent) +
					parseInt(UtilitiesElectric) +
					parseInt(UtilitiesWater) +
					parseInt(UtilitiesTele) +
					parseInt(GovtTax) +
					parseInt(FoodandGrocery) +
					parseInt(InsuranceHealth) +
					parseInt(Transportation) +
					parseInt(VehicleMaintenance) +
					parseInt(MedicalExpenses) +
					parseInt(DentalCare) +
					parseInt(Clothing) +
					parseInt(FitnessPersonal) +
					parseInt(DiningEntertainment) +
					parseInt(Vacations) +
					parseInt(Travel) +
					parseInt(LoanRepayment) +
					parseInt(SalaryPaid) +
					parseInt(DonationCharity) +
					parseInt(OtherExpenses) +
					parseInt(OtherExpenses2) +
					parseInt(OtherExpenses3);
				this.byId('AnnexureCTotalID').setValue(oAnxCTotal);
			}

			this.byId("AllOtherExpenditureCID").setValue(oAnxCTotal);

			//	var input30 = this.byId("AnnexureCTotalID").getValue();
			var HouseHoldEmployee = this.byId("HouseHoldEmployeeID").getValue();
			var IAnxC = {
				"HSRNT": HouseRent,
				"UTEGH": UtilitiesElectric,
				"UTWGO": UtilitiesWater,
				"UTMTI": UtilitiesTele,
				"GTXSC": GovtTax,
				"FDGRY": FoodandGrocery,
				"INSRC": InsuranceHealth,
				"TRNST": Transportation,
				"VHMNT": VehicleMaintenance,
				"MDEXP": MedicalExpenses,
				"DTCRE": DentalCare,
				"CLOTH": Clothing,
				"FTPCR": FitnessPersonal,
				"DONET": DiningEntertainment,
				"VCTNS": Vacations,
				"TRVEL": Travel,
				"LNPYT": LoanRepayment,
				"SLPDT": SalaryPaid,
				"DNTNS": DonationCharity,
				"OTHEX": OtherExpenses,
				"OTHEX1": OtherExpenses2,
				"OTHEX2": OtherExpenses3
			};
			var IAnxCJSON = JSON.stringify(IAnxC);

			this.getView().getModel('oAnnexureCModel').setData(IAnxC);
			this.getView().getModel('oAnnexureCModel').refresh();

			//IAnxC - Annexure C Data

			//IAnxD - Annexure D Data 
			var oAnxAD = this.byId("SectionBAnnexureDTbl").mAggregations.items["length"];
			var IAnxD = [];
			var oAnnexureDCurrentValue = 0;
			for (var b = 0; b < oAnxAD; b++) {
				var oADDOPUR = this.byId('SectionBAnnexureDTbl').mAggregations.items[b].mAggregations.cells[0].mProperties.value;
				var oADSZPLT = this.byId('SectionBAnnexureDTbl').mAggregations.items[b].mAggregations.cells[1].mProperties.value;
				var oADADDRS = this.byId('SectionBAnnexureDTbl').mAggregations.items[b].mAggregations.cells[2].mProperties.value;
				var oADCTCTY = this.byId('SectionBAnnexureDTbl').mAggregations.items[b].mAggregations.cells[3].mProperties.value;
				var oADRCAGR = this.byId('SectionBAnnexureDTbl').mAggregations.items[b].mAggregations.cells[4].mProperties.value;
				var oADORCST = this.byId('SectionBAnnexureDTbl').mAggregations.items[b].mAggregations.cells[5].mProperties.value;
				var oADCRMVL = this.byId('SectionBAnnexureDTbl').mAggregations.items[b].mAggregations.cells[6].mProperties.value;

				var oObjectAnnexureDTable = {
					"DOPUR": oADDOPUR,
					"SZPLT": oADSZPLT,
					"ADDRS": oADADDRS,
					"CTCTY": oADCTCTY,
					"RCAGR": oADRCAGR,
					"ORCST": oADORCST,
					"CRMVL": oADCRMVL
				};
				oAnnexureDCurrentValue = parseInt(oAnnexureDCurrentValue) + parseInt(oADCRMVL);
				IAnxD.push(oObjectAnnexureDTable);
			}
			this.byId("LandDID").setValue(oAnnexureDCurrentValue);

			this.byId("AnnexureDTotalID").setValue(oAnnexureDCurrentValue);

			var IAnxDJSON = JSON.stringify(IAnxD);

			this.getView().getModel('oAnnexureDModel').setData(IAnxD);
			this.getView().getModel('oAnnexureDModel').refresh();
			//IAnxD - Annexure D Data

			//IAnxE - Annexure E Data
			var oAnxAE = this.byId("SectionBAnnexureETbl").mAggregations.items["length"];
			var IAnxE = [];
			var oAnnexureECurrentValue = 0;
			for (var b = 0; b < oAnxAE; b++) {
				var oAEDOPUR = this.byId('SectionBAnnexureETbl').mAggregations.items[b].mAggregations.cells[0].mProperties.value;
				var oAECRDAR = this.byId('SectionBAnnexureETbl').mAggregations.items[b].mAggregations.cells[1].mProperties.value;
				var oAEADDRS = this.byId('SectionBAnnexureETbl').mAggregations.items[b].mAggregations.cells[2].mProperties.value;
				var oAECTCTY = this.byId('SectionBAnnexureETbl').mAggregations.items[b].mAggregations.cells[3].mProperties.value;
				// var oAERCAGR = this.byId('SectionBAnnexureETbl').mAggregations.items[b].mAggregations.cells[4].mProperties.value;
				var oAERCAGR = this.byId('SectionBAnnexureETbl').mAggregations.items[b].mAggregations.cells[4].mProperties.selectedKey;
				var oAEORCST = this.byId('SectionBAnnexureETbl').mAggregations.items[b].mAggregations.cells[5].mProperties.value;
				var oAECRMVL = this.byId('SectionBAnnexureETbl').mAggregations.items[b].mAggregations.cells[6].mProperties.value;

				var oObjectAnxETable = {
					"DOPUR": oAEDOPUR,
					"CRDAR": oAECRDAR,
					"ADDRS": oAEADDRS,
					"CTCTY": oAECTCTY,
					"RCAGR": oAERCAGR,
					"ORCST": oAEORCST,
					"CRMVL": oAECRMVL
				};
				oAnnexureECurrentValue = parseInt(oAnnexureECurrentValue) + parseInt(oAECRMVL);
				IAnxE.push(oObjectAnxETable);
			}
			this.byId("PropertyDID").setValue(oAnnexureECurrentValue);

			this.byId("AnnexureETotalID").setValue(oAnnexureECurrentValue);

			var IAnxEJSON = JSON.stringify(IAnxE);

			this.getView().getModel('oAnnexureEModel').setData(IAnxE);
			this.getView().getModel('oAnnexureEModel').refresh();
			//IAnxE - Annexure E Data

			//IAnxF - Annexure F Data 
			var oAnxAF = this.byId("SectionBAnnexureFTbl").mAggregations.items["length"];
			var IAnxF = [];
			var oAnnexureFCurrentValue = 0;
			for (var b = 0; b < oAnxAF; b++) {
				var oAFMKMOD = this.byId('SectionBAnnexureFTbl').mAggregations.items[b].mAggregations.cells[0].mProperties.value;
				var oAFYROMF = this.byId('SectionBAnnexureFTbl').mAggregations.items[b].mAggregations.cells[1].mProperties.value;
				var oAFYRPUR = this.byId('SectionBAnnexureFTbl').mAggregations.items[b].mAggregations.cells[2].mProperties.value;
				var oAFORPRC = this.byId('SectionBAnnexureFTbl').mAggregations.items[b].mAggregations.cells[3].mProperties.value;
				var oAFCRMVL = this.byId('SectionBAnnexureFTbl').mAggregations.items[b].mAggregations.cells[4].mProperties.value;

				var oObjectAnxFTable = {
					"MKMOD": oAFMKMOD,
					"YROMF": oAFYROMF,
					"YRPUR": oAFYRPUR,
					"ORPRC": oAFORPRC,
					"CRMVL": oAFCRMVL
				};
				oAnnexureFCurrentValue = parseInt(oAnnexureFCurrentValue) + parseInt(oAFCRMVL);
				IAnxF.push(oObjectAnxFTable);
			}
			this.byId("MotorVehicleDID").setValue(oAnnexureFCurrentValue);

			this.byId("AnnexureFTotalID").setValue(oAnnexureFCurrentValue);

			var IAnxFJSON = JSON.stringify(IAnxF);

			this.getView().getModel('oAnnexureFModel').setData(IAnxF);
			this.getView().getModel('oAnnexureFModel').refresh();
			//IAnxF - Annexure F Data

			//IAnxG - Annexure G Data
			var CattleQuantity = this.byId("CattleQuantityID").getValue();
			var HorseQuantity = this.byId("HorseQuantityID").getValue();
			var SheepQuantity = this.byId("SheepQuantityID").getValue();
			var GoatsQuantity = this.byId("GoatsQuantityID").getValue();
			var AnnexureGOtherQuantity = this.byId("AnnexureGOtherQuantityID").getValue();

			var CattleMarketValue = this.byId("CattleMarketValueID").getValue();
			var HorseMarketValue = this.byId("HorseMarketValueID").getValue();
			var SheepMarketValue = this.byId("SheepMarketValueID").getValue();
			var GoatsMarketValue = this.byId("GoatsMarketValueID").getValue();
			var AnnexureGOtherMarketValue = this.byId("AnnexureGOtherMarketValueID").getValue();

			if (CattleMarketValue !== "" &&
				HorseMarketValue !== "" &&
				SheepMarketValue !== "" &&
				GoatsMarketValue !== "" &&
				AnnexureGOtherMarketValue !== "") {
				var oAnnexureGTotal = parseInt(CattleMarketValue) +
					parseInt(HorseMarketValue) +
					parseInt(SheepMarketValue) +
					parseInt(GoatsMarketValue) +
					parseInt(AnnexureGOtherMarketValue);
				this.byId("AnnexureGTotalID").setValue(oAnnexureGTotal);

				this.byId("LivestockDID").setValue(oAnnexureGTotal);
			}
			var IAnxG = {
				"CATTLEQNTTY": CattleQuantity,
				"CATTLECRMVL": CattleMarketValue,
				"HORSEQNTTY": HorseQuantity,
				"HORSECRMVL": HorseMarketValue,
				"SHEEPQNTTY": SheepQuantity,
				"SHEEPCRMVL": SheepMarketValue,
				"GOATQNTTY": GoatsQuantity,
				"GOATCRMVL": GoatsMarketValue,
				"OTHERQNTTY": AnnexureGOtherQuantity,
				"OTHERCRMVL": AnnexureGOtherMarketValue
			};

			var IAnxGJSON = JSON.stringify(IAnxG);

			this.getView().getModel('oAnnexureGModel').setData(IAnxG);
			this.getView().getModel('oAnnexureGModel').refresh();

			//IAnxG - Annexure G Data

			//IAnxH - Annexure H Data
			var oAnxAH = this.byId("SectionBAnnexureHTbl").mAggregations.items["length"];
			var IAnxH = [];
			var oAnnexureHAmount = 0;
			for (var b = 0; b < oAnxAH; b++) {
				var oAHNACHD = this.byId('SectionBAnnexureHTbl').mAggregations.items[b].mAggregations.cells[0].mProperties.value;
				var oAHNMOBK = this.byId('SectionBAnnexureHTbl').mAggregations.items[b].mAggregations.cells[1].mProperties.value;
				var oAHACCTY = this.byId('SectionBAnnexureHTbl').mAggregations.items[b].mAggregations.cells[2].mProperties.value;
				var oAHCURRY = this.byId('SectionBAnnexureHTbl').mAggregations.items[b].mAggregations.cells[3].mProperties.value;
				var oAHAMUNT = this.byId('SectionBAnnexureHTbl').mAggregations.items[b].mAggregations.cells[4].mProperties.value;

				var oObjectAnxHTable = {
					"NACHD": oAHNACHD,
					"NMOBK": oAHNMOBK,
					"ACCTY": oAHACCTY,
					"CURRY": oAHCURRY,
					"AMUNT": oAHAMUNT
				};
				oAnnexureHAmount = parseInt(oAnnexureHAmount) + parseInt(oAHAMUNT);
				IAnxH.push(oObjectAnxHTable);
			}

			this.byId("CashandBankBalancesDID").setValue(oAnnexureHAmount);

			var IAnxHJSON = JSON.stringify(IAnxH);

			this.getView().getModel('oAnnexureHModel').setData(IAnxH);
			this.getView().getModel('oAnnexureHModel').refresh();
			//IAnxH - Annexure H Data

			//IAnxData Object 
			var AnnexureCHouseHold = this.byId('HouseHoldEmployeeID').getValue();
			var AnnexureCTotalValue = this.byId('AnnexureCTotalID').getValue();
			var PersoninBusinessID = this.byId('PersoninBusinessID').getValue();
			var AnnexureHCashinHandCurrency = this.byId("AnnexureHCashinHandCurrencyID").getValue();
			var AnnexureHCashinHandCurrency2 = this.byId("AnnexureHCashinHandCurrency2ID").getValue();
			var AnnexureHCashinHandAmount = this.byId("AnnexureHCashinHandAmountID").getValue();
			var AnnexureHCashinHandAmount2 = this.byId("AnnexureHCashinHandAmount2ID").getValue();
			var IAnxData = {
				"AA_ANLIN_FSALRY": oAnnexureAAnnualSalary,
				"AA_ANLIN_INVEST": oAnnexureAInvest,
				"AA_OTHIN": oAnnexureAOther,
				"AA_HMPEB": PersoninBusinessID, //PersoninBusiness,
				"AB_ANCST": oAnnexureBAnnualCost,
				"AB_ANFAD": oAnnexureBAnnualFinancial,
				"AC_HMPEB": AnnexureCHouseHold,
				"AC_TOTAL": AnnexureCTotalValue,
				"AD_CRMVL": oAnnexureDCurrentValue,
				"AE_CRMVL": oAnnexureECurrentValue,
				"AF_CRMVL": oAnnexureFCurrentValue,
				"AG_CRMVL": oAnnexureGTotal,
				"AH_AMUNT": oAnnexureHAmount,
				"AH_CURCY1": AnnexureHCashinHandCurrency,
				"AH_CIN1": AnnexureHCashinHandAmount,
				"AH_CURCY2": AnnexureHCashinHandCurrency2,
				"AH_CIN2": AnnexureHCashinHandAmount2
			};
			var oHouseHoldIncome = parseInt(IAnxData.AA_ANLIN_FSALRY) + parseInt(IAnxData.AA_ANLIN_INVEST) + parseInt(IAnxData.AA_OTHIN) +
				parseInt(IAnxData.AB_ANCST);
			this.byId("AnnualHouseHoldIncomeHI").setValue(oHouseHoldIncome);

			var AnnualHouseHoldExp = parseInt(IAnxData.AB_ANFAD) + parseInt(IAnxData.AC_TOTAL);
			this.byId("AnnualHouseHoldExp").setValue(AnnualHouseHoldExp);

			var NetdesposibleIncome = parseInt(oHouseHoldIncome) - parseInt(AnnualHouseHoldExp);
			this.byId("NetdesposibleIncome").setValue(NetdesposibleIncome);

			var IAnxDataJSON = JSON.stringify(IAnxData);

			// this.getView().getModel('oAllDataModel').setData(IAnxData);
			// this.getView().getModel('oAllDataModel').refresh();
			//IAnxData Object 

			//Section C Object

			// oAnnexureAAnnualSalary
			// oAnnexureAInvest
			// oAnnexureAOther
			// oAnnexureBAnnualCost
			// oAnnexureBAnnualFinancial
			// AnnexureCHouseHold
			var oSCANHEX_GT_ANHIN;
			oSCANHEX_GT_ANHIN = this.byId('SecCANHEX_GT_ANHIN').getSelectedItem().getProperty('text');
			// if (this.byId("rbg1").mProperties.selectedIndex === 0) {
			// 	oSCANHEX_GT_ANHIN = 'Yes'
			// } else {
			// 	oSCANHEX_GT_ANHIN = 'No'
			// }
			var oSCEXP_MEET_DIFFE = this.byId("textAreaWithBinding2").getValue();

			var oSCPRJ_HH_INCNEXT;
			oSCPRJ_HH_INCNEXT = this.byId('SecCPRJ_HH_INCNEXT').getSelectedItem().getProperty('text');
			// if (this.byId("rbg2").mProperties.selectedIndex === 0) {
			// 	oSCPRJ_HH_INCNEXT = 'Increase'
			// } else if (this.byId("rbg2").mProperties.selectedIndex === 1) {
			// 	oSCPRJ_HH_INCNEXT = 'Decrease'
			// } else {
			// 	oSCPRJ_HH_INCNEXT = 'No Change'
			// }

			var oSCEXP_RES_PROJCH = this.byId("ProjectExplainSignificent").getValue();
			// var oSectionCModel_Radio_Yes = this.byId("RB11").getProperty("selected");
			// var oSectionCModel_Radio_No = this.byId("RB12").getProperty("selected");
			// var oSectionCModel_Increase = this.byId("RB21").getProperty("selected");
			// var oSectionCModel_decrease = this.byId("RB22").getProperty("selected");
			// var oSectionCModel_Nochange = this.byId("RB23").getProperty("selected");

			var ISecC = {
				"INSAB": oAnnexureAAnnualSalary,
				"INCIN": oAnnexureAInvest,
				"OTHIN": oAnnexureAOther,
				"FINRE": oAnnexureBAnnualCost,
				// "ANHIN": ,
				"EDCEX": oAnnexureBAnnualFinancial,
				"OTHEX": AnnexureCHouseHold,
				"ANHEX": AnnualHouseHoldExp,
				"NTDIN": NetdesposibleIncome,
				"ANHEX_GT_ANHIN": oSCANHEX_GT_ANHIN,
				"EXP_MEET_DIFFE": oSCEXP_MEET_DIFFE,
				"PRJ_HH_INCNEXT": oSCPRJ_HH_INCNEXT,
				"EXP_RES_PROJCH": oSCEXP_RES_PROJCH,
			}
			var ISecCJSON = JSON.stringify(ISecC);

			this.getView().getModel('oSectionCModel').setData(ISecC);
			this.getView().getModel('oSectionCModel').refresh();

			//Section C Object

			//Section D Object
			var STSBD = this.byId("StocksSecuritiesandBondsDID").getValue();
			var OTHER = this.byId("Other1DID").getValue();
			var Other2DID = this.byId("Other2DID").getValue();
			var Other3DID = this.byId("Other3DID").getValue();

			// TotalDID
			if (oAnnexureDCurrentValue !== "" &&
				oAnnexureECurrentValue !== "" &&
				oAnnexureFCurrentValue !== "" &&
				oAnnexureGTotal !== "" &&
				oAnnexureHAmount !== "" &&
				STSBD !== "" &&
				OTHER !== "" &&
				Other2DID !== "" &&
				Other3DID !== ""
			) {
				var TotalDID = parseInt(oAnnexureDCurrentValue) + parseInt(oAnnexureECurrentValue) + parseInt(oAnnexureFCurrentValue) + parseInt(
					oAnnexureGTotal) + parseInt(oAnnexureHAmount) + parseInt(STSBD) + parseInt(OTHER) + parseInt(Other2DID) + parseInt(Other3DID);
				this.byId("TotalDID").setValue(TotalDID);
			}

			var ISecD = {
				"LAND": oAnnexureDCurrentValue,
				"PRPTY": oAnnexureECurrentValue,
				"MTVEH": oAnnexureFCurrentValue,
				"LIVST": oAnnexureGTotal,
				"BBNDP": oAnnexureHAmount,
				"STSBD": STSBD,
				"OTHER": OTHER,
				"OTHER1": Other2DID,
				"OTHER2": Other3DID,
				"TOTAL": TotalDID
			};
			var ISecDJSON = JSON.stringify(ISecD);

			this.getView().getModel('oSectionDModel').setData(ISecD);
			this.getView().getModel('oSectionDModel').refresh();
			// Section D Data

			// Section D table data
			var oSecD = this.byId("SectionDTbl").mAggregations.items["length"];
			var ISecDTbl = [];
			var oSecDBalance = 0;
			for (var d = 0; d < oSecD; d++) {
				var oDNOFLD = this.byId('SectionDTbl').mAggregations.items[d].mAggregations.cells[0].mProperties.value;
				var oDPRPOS = this.byId('SectionDTbl').mAggregations.items[d].mAggregations.cells[1].mProperties.value;
				var oDCURRC = this.byId('SectionDTbl').mAggregations.items[d].mAggregations.cells[2].mProperties.value;
				var oDPRAMN = this.byId('SectionDTbl').mAggregations.items[d].mAggregations.cells[3].mProperties.value;
				var oDANREP = this.byId('SectionDTbl').mAggregations.items[d].mAggregations.cells[4].mProperties.value;
				var oDINTRT = this.byId('SectionDTbl').mAggregations.items[d].mAggregations.cells[5].mProperties.value;
				var oDOTSBL = this.byId('SectionDTbl').mAggregations.items[d].mAggregations.cells[6].mProperties.value;

				var oObjectSecDTable = {
					"NOFLD": oDNOFLD,
					"PRPOS": oDPRPOS,
					"CURRC": oDCURRC,
					"PRAMN": oDPRAMN,
					"ANREP": oDANREP,
					"INTRT": oDINTRT,
					"OTSBL": oDOTSBL,
				};
				oSecDBalance = parseInt(oSecDBalance) + parseInt(oDOTSBL);
				ISecDTbl.push(oObjectSecDTable);
			}
			this.byId("SectionDTotalID").setValue(oSecDBalance);

			var ISecDTblJSON = JSON.stringify(ISecDTbl);

			this.getView().getModel('oSectionDTBLModel').setData(ISecDTbl);
			this.getView().getModel('oSectionDTBLModel').refresh();

			// oAnnexureDCurrentValue
			// oAnnexureECurrentValue
			// oAnnexureFCurrentValue
			// oAnnexureGTotal
			// oAnnexureHAmount

			//Section D Object

			//Section E Object
			var oSEVISIT;
			oSEVISIT = this.byId('SecEVISIT').getSelectedItem().getProperty('text');

			// if (this.byId("rbg3").mProperties.selectedIndex === 0) {
			// 	oSEVISIT = 'Yes'
			// } else {
			// 	oSEVISIT = 'No'
			// }
			var oSEFLYVT = this.byId("sectionEt").getValue();
			var oSEEXPLN = this.byId("textAreaSectionEFooter").getValue();

			var ISecE = {
				"VISIT": oSEVISIT,
				"FLYVT": oSEFLYVT,
				"EXPLN": oSEEXPLN
			};
			var ISecEJSON = JSON.stringify(ISecE);

			this.getView().getModel('oSectionEModel').setData(ISecE);
			this.getView().getModel('oSectionEModel').refresh();

			// Section E Data

			//Section E 1 Table Data
			var oSecE1 = this.byId("SectionETbl").mAggregations.items["length"];
			var ISecET1 = [];
			for (var b = 0; b < oSecE1; b++) {
				var oSENAME = this.byId('SectionETbl').mAggregations.items[b].mAggregations.cells[0].mProperties.value;
				var oSECCVST = this.byId('SectionETbl').mAggregations.items[b].mAggregations.cells[1].mProperties.value;
				var oSEVSPRP = this.byId('SectionETbl').mAggregations.items[b].mAggregations.cells[2].mProperties.value;
				var oSEVDATE = this.byId('SectionETbl').mAggregations.items[b].mAggregations.cells[3].mProperties.value;
				var oSECURCY = this.byId('SectionETbl').mAggregations.items[b].mAggregations.cells[4].mProperties.value;
				var oSEAMUNT = this.byId('SectionETbl').mAggregations.items[b].mAggregations.cells[5].mProperties.value;
				var oSEPADBY = this.byId('SectionETbl').mAggregations.items[b].mAggregations.cells[6].mProperties.value;

				var oObjectSecE1Table = {
					"NAME": oSENAME,
					"CCVST": oSECCVST,
					"VSPRP": oSEVSPRP,
					"VDATE": oSEVDATE,
					"CURCY": oSECURCY,
					"AMUNT": oSEAMUNT,
					"PADBY": oSEPADBY
				};

				ISecET1.push(oObjectSecE1Table);
			}
			var ISecET1JSON = JSON.stringify(ISecET1);

			this.getView().getModel('oSectionETbl1Model').setData(ISecET1);
			this.getView().getModel('oSectionETbl1Model').refresh();
			//Section E 1 Table Data

			//Section E 2 Table Data
			var oSecE2 = this.byId("SectionE2Tbl").mAggregations.items["length"];
			var ISecET2 = [];
			for (var b = 0; b < oSecE2; b++) {
				var oSE2NMORG = this.byId('SectionE2Tbl').mAggregations.items[b].mAggregations.cells[0].mProperties.value;
				var oSE2NMFND = this.byId('SectionE2Tbl').mAggregations.items[b].mAggregations.cells[1].mProperties.value;
				var oSE2CURCY = this.byId('SectionE2Tbl').mAggregations.items[b].mAggregations.cells[2].mProperties.value;
				var oSE2AMTAP = this.byId('SectionE2Tbl').mAggregations.items[b].mAggregations.cells[3].mProperties.value;
				var oSE2AMAPR = this.byId('SectionE2Tbl').mAggregations.items[b].mAggregations.cells[4].mProperties.value;

				var oObjectSecE2Table = {
					"NMORG": oSE2NMORG,
					"NMFND": oSE2NMFND,
					"CURCY": oSE2CURCY,
					"AMTAP": oSE2AMTAP,
					"AMAPR": oSE2AMAPR
				};
				ISecET2.push(oObjectSecE2Table);
			}
			var ISecET2JSON = JSON.stringify(ISecET2);

			this.getView().getModel('oSectionETbl2Model').setData(ISecET2);
			this.getView().getModel('oSectionETbl2Model').refresh();
			//Section E 2 Data

			//Section F Object
			var ANTUT = this.byId("AnnualTuition").getValue();
			var ANROF = this.byId("AnnualResidence").getValue();
			var TOCST = this.byId("TotalCosts").getValue();
			var PRCTR = this.byId("ParentsContribution").getValue();
			var CTBOT = this.byId("ContributionOtherMembers").getValue();
			var ASSTS = this.byId("HouseholdAssets").getValue();
			var FNOTS = this.byId("FundingOtherSources").getValue();
			var OTHSP = this.byId("OthersTab5").getValue();
			var TOTSR = this.byId("TotalAvailableSources").getValue();
			var RQUCA = this.byId("FinancialAidRequested").getValue();
			var NAME = this.byId("NameFG").getValue();
			var RELSP = this.byId("RelationshipFG").getValue();
			var ADDRS = this.byId("HomeAddressFG").getValue();
			var PASSP = this.byId("PassportFG").getValue();
			var MOBIL = this.byId("MobileContactFG").getValue();
			var EMAIL = this.byId("EmailAddressFG").getValue();
			var OCCPT = this.byId("OccupationFG").getValue();
			var OFADR = this.byId("OfficeAddressFG").getValue();

			var GURNT;
			GURNT = this.byId('GURNT').getSelectedItem().getProperty('text');
			// if (this.byId("sectionFrb1").mProperties.selectedIndex === 0) {
			// 	GURNT = 'Yes'
			// } else {
			// 	GURNT = 'No'
			// }

			var PRNME = this.byId("providedGuaranteeStudentFG1").getValue();
			var PRNME2 = this.byId("providedGuaranteeStudentFG2").getValue();

			var NAMEZ = this.byId("NameSG").getValue();
			var RELSPZ = this.byId("RelationshipSG").getValue();
			var ADDRSZ = this.byId("HomeAddressSG").getValue();
			var PASSPZ = this.byId("PassportSG").getValue();
			var MOBILZ = this.byId("MobileContactSG").getValue();
			var EMAILZ = this.byId("EmailAddressSG").getValue();
			var OCCPTZ = this.byId("OccupationSG").getValue();
			var OFADRZ = this.byId("OfficeAddressSG").getValue();

			var GURNTZ;
			GURNTZ = this.byId('GURNTZ').getSelectedItem().getProperty('text');
			// if (this.byId("sectionFrb2").mProperties.selectedIndex === 0) {
			// 	GURNTZ = 'Yes'
			// } else {
			// 	GURNTZ = 'No'
			// }

			var PRNMEZ = this.byId("providedGuaranteeStudentSG1").getValue();
			var PRNMEZ2 = this.byId("providedGuaranteeStudentSG2").getValue();
			var ISecF = {
				"ANTUT": ANTUT,
				"ANROF": ANROF,
				"TOCST": TOCST,
				"PRCTR": PRCTR,
				"CTBOT": CTBOT,
				"ASSTS": ASSTS,
				"FNOTS": FNOTS,
				"OTHSP": OTHSP,
				"TOTSR": TOTSR,
				"RQUCA": RQUCA,
				"NAME": NAME,
				"RELSP": RELSP,
				"ADDRS": ADDRS,
				"PASSP": PASSP,
				"MOBIL": MOBIL,
				"EMAIL": EMAIL,
				"OCCPT": OCCPT,
				"OFADR": OFADR,
				"GURNT": GURNT,
				"PRNME": PRNME,
				"PRNME2": PRNME2,
				"NAMEZ": NAMEZ,
				"RELSPZ": RELSPZ,
				"ADDRSZ": ADDRSZ,
				"PASSPZ": PASSPZ,
				"MOBILZ": MOBILZ,
				"EMAILZ": EMAILZ,
				"OCCPTZ": OCCPTZ,
				"OFADRZ": OFADRZ,
				"GURNTZ": GURNTZ,
				"PRNMEZ": PRNMEZ,
				"PRNMEZ2": PRNMEZ2
			}

			var ISecFJSON = JSON.stringify(ISecF);

			this.getView().getModel('oSectionFModel').setData(ISecF);
			this.getView().getModel('oSectionFModel').refresh();

			//Section F Object

			// var IStudentDataJSON = JSON.stringify(IStudentData);
			if (this.getView().getModel('oStudentModel') !== undefined) {
				var IStudentData = this.getView().getModel('oStudentModel').getData();
				var IStudentDataJSON = JSON.stringify(IStudentData);
			}

			var FirstTabObj = {
				"input1": TotalnoMember,
				"input2": EarningMembers,
				"input3": NonEarningMember,
				"input4": RetiredMembers,
				"input5": MembersAttendingSchool,
				"input6": MembersDisablility,
				"input7": HouseRent,
				"input8": UtilitiesElectric,
				"input9": UtilitiesWater,
				"input10": UtilitiesTele,
				"input11": GovtTax,
				"input12": FoodandGrocery,
				// "input13": PersoninBusiness,
				"input14": InsuranceHealth,
				"input15": Transportation,
				"input16": VehicleMaintenance,
				"input17": MedicalExpenses,
				"input18": DentalCare,
				"input19": Clothing,
				"input20": FitnessPersonal,
				"input21": DiningEntertainment,
				"input22": Vacations,
				"input23": Travel,
				"input24": LoanRepayment,
				"input25": SalaryPaid,
				"input26": DonationCharity,
				"input27": OtherExpenses,
				"input28": OtherExpenses2,
				"input29": OtherExpenses3,
				//	"input30": input30,
				"input31": HouseHoldEmployee,
				"input32": CattleQuantity,
				"input33": HorseQuantity,
				"input34": SheepQuantity,
				"input35": GoatsQuantity,
				"input36": AnnexureGOtherQuantity,
				"input37": CattleMarketValue,
				"input38": HorseMarketValue,
				"input39": SheepMarketValue,
				"input40": GoatsMarketValue,
				"input41": AnnexureGOtherMarketValue,
				"input42": AnnexureHCashinHandCurrency,
				"input43": AnnexureHCashinHandCurrency2,
				"input44": AnnexureHCashinHandAmount,
				"input45": AnnexureHCashinHandAmount2,
				// "tblMembersHousehold": tblMembersHousehold,
				// "tblAnnexureA": tblAnnexureA,
				// "tblAnnexureB": tblAnnexureB,
				// "tblAnnexureD": tblAnnexureD,
				// "tblAnnexureE": tblAnnexureE,
				// "tblAnnexureF": tblAnnexureF,
				// "tblAnnexureH": tblAnnexureH,

			};
			var model = new JSONModel(FirstTabObj);
			that.getView().setModel(model, "firsttAbfields");
			var firstTabmodel = that.getView().getModel("firsttAbfields").getData();

			// tab 2
			var input46 = this.byId("IncomefromSalaryandBusinessCID").getValue();
			var input47 = this.byId("IncomefromInvestmentsCID").getValue();
			var input48 = this.byId("OtherIncomeCID").getValue();
			var input49 = this.byId("FinancialAidReceivedCID").getValue();
			var input50 = this.byId("EducationExpenditureCID").getValue();
			var input51 = this.byId("AllOtherExpenditureCID").getValue();
			var textarea1 = this.byId("textAreaWithBinding2").getValue();
			var textarea2 = this.byId("ProjectExplainSignificent").getValue();

			var SecondTabObj = {
				"input46": input46,
				"input47": input47,
				"input48": input48,
				"input49": input49,
				"input50": input50,
				"input51": input51,
				"textarea1": textarea1,
				"textarea2": textarea2
			};
			var model = new JSONModel(SecondTabObj);
			that.getView().setModel(model, "2ndTabFields");
			var secTabModel = that.getView().getModel("2ndTabFields").getData();

			// tab 3
			var LandD = this.byId("LandDID").getValue();
			var PropertyD = this.byId("PropertyDID").getValue();
			var MotorVehicleD = this.byId("MotorVehicleDID").getValue();
			var LivestockD = this.byId("LivestockDID").getValue();
			var CashandBankBalancesD = this.byId("CashandBankBalancesDID").getValue();
			var StocksSecuritiesandBondsD = this.byId("StocksSecuritiesandBondsDID").getValue();
			var Other1D = this.byId("Other1DID").getValue();
			var Other2D = this.byId("Other2DID").getValue();
			var Other3D = this.byId("Other3DID").getValue();

			var thirdTabObj = {
				"input52": LandD,
				"input53": PropertyD,
				"input54": MotorVehicleD,
				"input55": LivestockD,
				"input56": CashandBankBalancesD,
				"input57": StocksSecuritiesandBondsD,
				"input58": Other1D,
				"input59": Other2D,
				"input60": Other3D
			};
			var model = new JSONModel(thirdTabObj);
			that.getView().setModel(model, "3rdTabFields");
			var thrdTabModel = that.getView().getModel("3rdTabFields").getData();

			// tab 4
			var sectionEt = this.byId("sectionEt").getValue();
			var textAreaSectionEFooter = this.byId("textAreaSectionEFooter").getValue();

			var forthTabObj = {
				"input61": sectionEt,
				"textarea3": textAreaSectionEFooter
			};
			var model = new JSONModel(forthTabObj);
			that.getView().setModel(model, "4thTabFields");
			var fothTabModel = that.getView().getModel("4thTabFields").getData();

			// tab 5
			var AnnualTuition = this.byId("AnnualTuition").getValue();
			var AnnualResidence = this.byId("AnnualResidence").getValue();
			var TotalCosts = this.byId("TotalCosts").getValue();
			var ParentsContribution = this.byId("ParentsContribution").getValue();
			var ContributionOtherMembers = this.byId("ContributionOtherMembers").getValue();
			var HouseholdAssets = this.byId("HouseholdAssets").getValue();
			var FundingOtherSources = this.byId("FundingOtherSources").getValue();
			var OthersTab5 = this.byId("OthersTab5").getValue();
			var TotalAvailableSources = this.byId("TotalAvailableSources").getValue();
			var FinancialAidRequested = this.byId("FinancialAidRequested").getValue();
			var NameFG = this.byId("NameFG").getValue();
			var RelationshipFG = this.byId("RelationshipFG").getValue();
			var HomeAddressFG = this.byId("HomeAddressFG").getValue();
			var PassportFG = this.byId("PassportFG").getValue();
			var MobileContactFG = this.byId("MobileContactFG").getValue();
			var EmailAddressFG = this.byId("EmailAddressFG").getValue();
			var OccupationFG = this.byId("OccupationFG").getValue();
			var OfficeAddressFG = this.byId("OfficeAddressFG").getValue();
			var providedGuaranteeStudentFG1 = this.byId("providedGuaranteeStudentFG1").getValue();
			var providedGuaranteeStudentFG2 = this.byId("providedGuaranteeStudentFG2").getValue();
			var NameSG = this.byId("NameFG").getValue();
			var RelationshipSG = this.byId("RelationshipSG").getValue();
			var HomeAddressSG = this.byId("HomeAddressSG").getValue();
			var PassportSG = this.byId("PassportSG").getValue();
			var MobileContactSG = this.byId("MobileContactSG").getValue();
			var EmailAddressSG = this.byId("EmailAddressSG").getValue();
			var OccupationSG = this.byId("OccupationSG").getValue();
			var OfficeAddressSG = this.byId("OfficeAddressSG").getValue();
			var providedGuaranteeStudentSG1 = this.byId("providedGuaranteeStudentSG1").getValue();
			var providedGuaranteeStudentSG2 = this.byId("providedGuaranteeStudentSG2").getValue();

			var fifthTabObj = {
				"input62": AnnualTuition,
				"input63": AnnualResidence,
				"input64": TotalCosts,
				"input65": ParentsContribution,
				"input66": ContributionOtherMembers,
				"input67": HouseholdAssets,
				"input68": FundingOtherSources,
				"input69": OthersTab5,
				"input70": TotalAvailableSources,
				"input71": FinancialAidRequested,
				"input72": NameFG,
				"input73": RelationshipFG,
				"input74": HomeAddressFG,
				"input75": PassportFG,
				"input76": MobileContactFG,
				"input77": EmailAddressFG,
				"input78": OccupationFG,
				"input79": OfficeAddressFG,
				"input80": providedGuaranteeStudentFG1,
				"input81": providedGuaranteeStudentFG2,
				"input82": NameSG,
				"input83": RelationshipSG,
				"input84": HomeAddressSG,
				"input85": PassportSG,
				"input86": MobileContactSG,
				"input87": EmailAddressSG,
				"input88": OccupationSG,
				"input89": OfficeAddressSG,
				"input90": providedGuaranteeStudentSG1,
				"input91": providedGuaranteeStudentSG2,
			};
			var model = new JSONModel(fifthTabObj);
			that.getView().setModel(model, "5thTabFields");
			var fifTabModel = that.getView().getModel("5thTabFields").getData();

			//Save Data
			var oAllDataArray = {

			};
			// var oJson = JSON.stringify(oAllDataArray);

			// PersonalInformation

			var oSaveObject = {
				// "PersonalInfo": IPersonalInfoJSON,
				// "PersonalData": IStudentDataJSON,
				"PersonalData": IPersonalInfoJSON,
				"Attachment": IAttachmentDataJSON,
				"AnexureData": IAnxDataJSON,
				"SectionB": ISecBJSON,
				"SecbTbl": ISecBTblJSON,
				"SectionC": ISecCJSON,
				"SectionD": ISecDJSON,
				"SecdTbl": ISecDTblJSON,
				"SectionE": ISecEJSON,
				"SeceT1": ISecET1JSON,
				"SeceT2": ISecET2JSON,
				"SectionF": ISecFJSON,
				"AnexureA": IAnxAJSON,
				"AnexureB": IAnxBJSON,
				"AnexureC": IAnxCJSON,
				"AnexureD": IAnxDJSON,
				"AnexureE": IAnxEJSON,
				"AnexureF": IAnxFJSON,
				"AnexureG": IAnxGJSON,
				"AnexureH": IAnxHJSON,
				"ICall": "C"
			};
			//Section Personal Information student
			if (oEvent.getSource().sId.split('-')[2] === 'ProductInfoStep') {
				//send Data
				//call for Save Data
				dataManagerLib.saveRequest(oSaveObject,
					function (response) {},
					function (error) {});
			}
			//Section B Data
			if (oEvent.getSource().sId.split('-')[2] === 'ProductInfo') {

				//call for Save Data
				dataManagerLib.saveRequest(oSaveObject,
					function (response) {},
					function (error) {});

				//1 var ISecBJSON = JSON.stringify(ISecB);
				//2 var ISecBTblJSON = JSON.stringify(ISecBTbl);
				//3 var ISecCJSON = JSON.stringify(ISecC);
				//4 var ISecDJSON = JSON.stringify(ISecD);
				//5 var ISecDTblJSON = JSON.stringify(ISecDTbl);
				//6 var ISecEJSON = JSON.stringify(ISecE);
				//7 var ISecET1JSON = JSON.stringify(ISecET1);
				//8 var ISecET2JSON = JSON.stringify(ISecET2);
				//9 var ISecFJSON = JSON.stringify(ISecF);
				//0 var IAnxHJSON = JSON.stringify(IAnxH);
				//1 var IAnxGJSON = JSON.stringify(IAnxG);
				//2 var IAnxFJSON = JSON.stringify(IAnxF);
				//3 var IAnxEJSON = JSON.stringify(IAnxE);
				//4 var IAnxDataJSON = JSON.stringify(IAnxData);
				//5 var IAnxDJSON = JSON.stringify(IAnxD);
				//6 var IAnxCJSON = JSON.stringify(IAnxC);
				//7 var IAnxBJSON = JSON.stringify(IAnxB);
				//8 var IAnxAJSON = JSON.stringify(IAnxA);
				//9 var IStudentDataJSON = JSON.stringify(IStudentData);

				// //send Data
				// dataManagerLib.getDetailAllData(IStudentDataJSON, IAnxFJSON, ISecET2JSON, ISecET1JSON, ISecEJSON, ISecDTblJSON, ISecDJSON,
				// 	ISecCJSON, ISecBTblJSON, ISecBJSON, IAnxHJSON, IAnxGJSON, IAnxFJSON, IAnxEJSON, IAnxDataJSON, IAnxDJSON, IAnxCJSON, IAnxBJSON,
				// 	IAnxAJSON,
				// 	function (response) {
				// 		// var oStudentData = JSON.parse(response.results);
				// 		// var oStudentData = response.results;
				// 	},
				// 	function (error) {
				// 	});
			}
			// Section C Data
			if (oEvent.getSource().sId.split('-')[2] === 'OptionalInfoStep') {
				//send Data
				//call for Save Data
				dataManagerLib.saveRequest(oSaveObject,
					function (response) {},
					function (error) {});
			}
			//Section D Data
			if (oEvent.getSource().sId.split('-')[2] === 'PricingStep') {
				//call for Save Data
				dataManagerLib.saveRequest(oSaveObject,
					function (response) {},
					function (error) {});
			}
			// Section E Data
			if (oEvent.getSource().sId.split('-')[2] === 'PricingStepp') {
				//call for Save Data
				dataManagerLib.saveRequest(oSaveObject,
					function (response) {},
					function (error) {});
			}
			// Section F Data
			if (oEvent.getSource().sId.split('-')[2] === 'PricinStepp') {
				//call for Save Data
				dataManagerLib.saveRequest(oSaveObject,
					function (response) {

					},
					function (error) {});
			}

			//Personal Information
			if (PersonalInformation.first_name === "" ||
				PersonalInformation.Mid_Name === "" ||
				PersonalInformation.Last_Name === "" || PersonalInformation.date_birth === "" || PersonalInformation.Citizen_Ship === "" ||
				PersonalInformation.P_city === "" || PersonalInformation.P_Town === "" || PersonalInformation.Gender === "" ||
				PersonalInformation.Student_Martial_Status === "" || PersonalInformation.Parent_Martial_Status === "" ||
				PersonalInformation.Identification_Number === "" || PersonalInformation.Issued_By === "" || PersonalInformation.Current_Residence ===
				"" || PersonalInformation.Permanent_Address ===
				"" ||
				PersonalInformation.City === "" || PersonalInformation.Email_Address === "" || PersonalInformation.Home_Phone === "" ||
				PersonalInformation.Mobile_Phone === "") {
				that._wizard.invalidateStep(this.byId("Personal_info"));

			} else {
				that._wizard.validateStep(this.byId("Personal_info"));
			}

			// tab 1
			if (
				//tblMembersHousehold < "1" ||
				// tblAnnexureA < "1" || tblAnnexureB < "1" || tblAnnexureD < "1" || tblAnnexureE < "1" ||
				// 	tblAnnexureF < "1" || tblAnnexureH < "1" ||
				firstTabmodel.input1 === "" || firstTabmodel.input2 === "" || firstTabmodel.input3 === "" ||
				firstTabmodel.input4 === "" ||
				firstTabmodel.input5 === "" ||
				firstTabmodel.input6 === "" || firstTabmodel.input7 === "" || firstTabmodel.input8 === "" || firstTabmodel.input9 === "" ||
				firstTabmodel.input10 === "" ||
				firstTabmodel.input11 === "" || firstTabmodel.input12 === "" || firstTabmodel.input13 === "" || firstTabmodel.input14 === "" ||
				firstTabmodel.input15 === "" ||
				firstTabmodel.input16 === "" || firstTabmodel.input17 === "" || firstTabmodel.input18 === "" || firstTabmodel.input19 === "" ||
				firstTabmodel.input20 === "" ||
				firstTabmodel.input21 === "" || firstTabmodel.input22 === "" || firstTabmodel.input23 === "" || firstTabmodel.input24 === "" ||
				firstTabmodel.input25 === "" ||
				firstTabmodel.input26 === "" || firstTabmodel.input27 === "" || firstTabmodel.input28 === "" || firstTabmodel.input29 === "" ||
				firstTabmodel.input31 === "" || firstTabmodel.input32 === "" || firstTabmodel.input33 === "" || firstTabmodel.input34 === "" ||
				firstTabmodel.input35 === "" ||
				firstTabmodel.input36 === "" || firstTabmodel.input37 === "" || firstTabmodel.input38 === "" || firstTabmodel.input39 === "" ||
				firstTabmodel.input40 === "" ||
				firstTabmodel.input41 === "" || firstTabmodel.input42 === "" || firstTabmodel.input43 === "" || firstTabmodel.input44 === "" ||
				firstTabmodel.input45 === "") {
				that._wizard.invalidateStep(this.byId("ProductInfoStep"));
			} else {
				that._wizard.validateStep(this.byId("ProductInfoStep"));
			}

			// tab2
			if (secTabModel.input46 === "" || secTabModel.input47 === "" || secTabModel.input48 === "" || secTabModel.input49 === "" ||
				secTabModel.input50 === "" ||
				secTabModel.input51 === "" || secTabModel.textarea1 === "" || secTabModel.textarea2 === "") {
				that._wizard.invalidateStep(this.byId("ProductInfo"));
			} else {
				that._wizard.validateStep(this.byId("ProductInfo"));
			}
			// tab 3
			if (thrdTabModel.input52 === "" || thrdTabModel.input53 === "" || thrdTabModel.input54 === "" || thrdTabModel.input55 === "" ||
				thrdTabModel.input56 === "" ||
				thrdTabModel.input57 === "" || thrdTabModel.input58 === "" || thrdTabModel.input59 === "" || thrdTabModel.input60 === "") {
				that._wizard.invalidateStep(this.byId("OptionalInfoStep"));
			} else {
				that._wizard.validateStep(this.byId("OptionalInfoStep"));
			}
			//tab4
			if (fothTabModel.input61 === "" || fothTabModel.textarea3 === "") {
				that._wizard.invalidateStep(this.byId("PricingStep"));
			} else {
				that._wizard.validateStep(this.byId("PricingStep"));
			}
			if (fifTabModel.input62 === "" || fifTabModel.input63 === "" || fifTabModel.input64 === "" || fifTabModel.input65 === "" ||
				fifTabModel.input66 === "" ||
				fifTabModel.input67 === "" || fifTabModel.input68 === "" || fifTabModel.input69 === "" || fifTabModel.input70 === "" ||
				fifTabModel.input71 === "" ||
				fifTabModel.input72 === "" || fifTabModel.input73 === "" || fifTabModel.input74 === "" || fifTabModel.input75 === "" ||
				fifTabModel.input76 === "" ||
				fifTabModel.input77 === "" || fifTabModel.input78 === "" || fifTabModel.input79 === "" || fifTabModel.input80 === "" ||
				fifTabModel.input81 === "" || fifTabModel.input82 === "" || fifTabModel.input83 === "" ||
				fifTabModel.input84 === "" || fifTabModel.input85 === "" || fifTabModel.input86 === "" || fifTabModel.input87 === "" ||
				fifTabModel.input88 === "" || fifTabModel.input89 === "" || fifTabModel.input90 === "" ||
				fifTabModel.input91 === "") {
				that._wizard.invalidateStep(this.byId("PricingStepp"));
			} else {
				that._wizard.validateStep(this.byId("PricingStepp"));
			}

			var oModel = new sap.ui.model.json.JSONModel();
			var oShell = sap.ui.getCore().byId('Shell');

			//Get PR Data
			// dataManagerLib.getPRData(
			// 	function (response) {
			// 		var oPRData = JSON.parse(response.EPrsldata);
			// 		var oPRModel = new JSONModel(oPRData);
			// 		oShell.setModel(oPRModel, "oPRDataModel");

			// 	},
			// 	function (error) {

			// 	});

		},
		btnSave: function (oEvent) {
			var that = this;
			var getPersonalData = that.getView().getModel("oPersonalDataModel").getData();
			var oPeronslData = that.getView().getModel("oStuInfoModel").getData();

			var PersonalInfoData1 = getPersonalData;
			// var PersonalInfoData1 = JSON.parse(getPersonalData);
			that.getView().getModel('oPersonalDataModel').setData(PersonalInformation);
			var PersonalInfoData = that.getView().getModel("oPersonalDataModel").getData();
			// var oInfoModel = that.getView().getModel("oInfoModel").getData();
			// var oInfoModel = JSON.parse(oInfoModel);
			var check = that.byId('undertakingCheckID').getProperty("selected") ===
				true ? "1" : "";
			// var FAMST = this.byId('Student_Martial_Status').getSelectedButton().getText();
			// var P_FAMST = this.byId('Parent_Martial_Status').getSelectedButton().getText();
			// var oGeographic = this.byId('Geographic').getSelectedButton().getText();

			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyy-MM-dd"
			});
			oPeronslData.PASS_ISSUEDATE = dateFormat.format(new Date(oPeronslData.PASS_ISSUEDATE));
			oPeronslData.PASS_EXPIRYDATE = dateFormat.format(new Date(oPeronslData.PASS_EXPIRYDATE));

			var PersonalInformation = {
				"OBJID": oPeronslData.OBJID,
				"VORNA": oPeronslData.VORNA,
				"MIDNM": oPeronslData.MIDNM,
				"NACHN": oPeronslData.NACHN,
				"GBDAT": oPeronslData.GBDAT,
				"NATIO": oPeronslData.NATIO,
				"GBORT": oPeronslData.GBORT,
				"GBLND": oPeronslData.GBLND,
				"PASSN": oPeronslData.PASSN,
				"GESCH": oPeronslData.GESCH,
				"FAMST": oPeronslData.FAMST,
				"P_FAMST": oPeronslData.P_FAMST,
				"PASS_ISSUEPLACE": oPeronslData.PASS_ISSUEPLACE,
				"PASS_ISSUEDATE": oPeronslData.PASS_ISSUEDATE,
				"PASS_EXPIRYDATE": oPeronslData.PASS_EXPIRYDATE,
				"ADDRESS": oPeronslData.ADDRESS,
				"PRMT_ADDRESS": oPeronslData.PRMT_ADDRESS,
				"GEOGRAPHIC": oPeronslData.GEOGRAPHIC,
				//"GEOGRAPHIC": oGeographic,
				"EMAIL": oPeronslData.EMAIL,
				"EXCHANGE_RATE": oPeronslData.EXCHANGE_RATE,
				"HOM_NUMBER": oPeronslData.HOM_NUMBER,
				"MOB_NUMBER": oPeronslData.MOB_NUMBER,
				"FA_STATUS": check
			};
			that.getView().getModel('oPersonalDataModel').setData(PersonalInformation);
			var PersonalInfoData = that.getView().getModel("oPersonalDataModel").getData();
			// var oInfoModel = that.getView().getModel("oInfoModel").getData();
			// var oInfoModel = JSON.parse(oInfoModel);
			var oAttachment = that.getView().getModel("Attachments").getData()[0];
			var oAllDataModel = that.getView().getModel("oAllDataModel").getData();
			var oSectionBModel = that.getView().getModel("oSectionBModel").getData();
			var SectionBTblModel = that.getView().getModel("oSectionBTblModel").getData();
			var oSectionCModel = that.getView().getModel("oSectionCModel").getData();
			var oSectionDModel = that.getView().getModel("oSectionDModel").getData();
			var oSectionDTBLModel = that.getView().getModel("oSectionDTBLModel").getData();
			var oSectionEModel = that.getView().getModel("oSectionEModel").getData();
			var oSectionETbl1Model = that.getView().getModel("oSectionETbl1Model").getData();
			var oSectionETbl2Model = that.getView().getModel("oSectionETbl2Model").getData();
			var oSectionFModel = that.getView().getModel("oSectionFModel").getData();
			var oSectionGModel = that.getView().getModel("oSectionGModel").getData();
			var oAnnexureAModel = that.getView().getModel("oAnnexureAModel").getData();
			var oAnnexureBModel = that.getView().getModel("oAnnexureBModel").getData();
			var oAnnexureCModel = that.getView().getModel("oAnnexureCModel").getData();
			var oAnnexureDModel = that.getView().getModel("oAnnexureDModel").getData();
			var oAnnexureEModel = that.getView().getModel("oAnnexureEModel").getData();
			var oAnnexureFModel = that.getView().getModel("oAnnexureFModel").getData();
			var oAnnexureGModel = that.getView().getModel("oAnnexureGModel").getData();
			var oAnnexureHModel = that.getView().getModel("oAnnexureHModel").getData();

			// //First condition
			var total_earn_memeber = 0;
			if (oSectionBModel.ERNMB !== "" || oSectionBModel.NERMB !== "") {
				total_earn_memeber = Number(oSectionBModel.ERNMB) / Number(oSectionBModel.NERMB);

				if (total_earn_memeber >= 1.00) {
					total_earn_memeber = 0;
				} else if (total_earn_memeber > 0.50 && total_earn_memeber < 1.00) {
					total_earn_memeber = 2;
				} else if (total_earn_memeber > 0.25 && total_earn_memeber <= 0.50) {
					total_earn_memeber = 4;
				} else if (total_earn_memeber <= 0.25) {
					total_earn_memeber = 6;
				}
			} else {
				total_earn_memeber = 0;
			}
			//	second condition
			var Parent_Count = 0;
			if (PersonalInfoData.P_FAMST === "Married") {
				Parent_Count = 0;
			} else if (PersonalInfoData.P_FAMST === "Seperated/Divorced") {
				Parent_Count = 2;
			} else if (PersonalInfoData.P_FAMST === "No Parent") {
				Parent_Count = 4;
			} else {
				Parent_Count = 0;
			}
			// 	//third Condition
			// var disable = "";
			// Number(oSectionBModel.MASCU)
			// if (oSectionBModel.MASCU === 0) {
			// 	disable = 0;
			// } else {
			// 	disable = 2;
			// }
			// fourth condition
			//pick greater one value age_con
			var age_con = [];
			var oDisable = [];
			SectionBTblModel.forEach(function (item, index) {
				var age = SectionBTblModel[index].AGE;
				if (age >= 15) {
					// age_con = "0";
					age_con.push(0);
				} else if (age > 10 && age < 15) {
					// age_con = "2";
					age_con.push(2);
				} else if (age <= 10) {
					// age_con = "4";
					age_con.push(4);
				}
				if (item.PHSST === 'Disable' || item.PHSST === 'DISABLE' || item.PHSST === 'disable') {
					oDiable.push(1)
				}
			});
			var disable = 0;
			var oDisLength = oDisable.length;
			if (oDisable.length > 0) {
				disable = 2;
			} else {
				disable = 0;
			}
			var age_max = Math.max.apply(Math, age_con);

			let IS_PRIVATE = 0;
			let flag1 = 0;
			let flag2 = 0;
			oAnnexureBModel.forEach(function (item) {
				// var row = oAnnexureBModel[item];
				var Privatevalue = item.IS_PRIVATE;
				if (Privatevalue === "x") {
					flag1++;
				} else if (Privatevalue === "") {
					flag2++;
				}
			});
			if (flag1 > 0 && flag2 > 0) {
				IS_PRIVATE = 2;
			} else if (flag1 > 0) {
				IS_PRIVATE = 0;
			} else if (flag2 > 0) {
				IS_PRIVATE = 4;
			} else {
				IS_PRIVATE = 0;
			}

			//Geographic Profile
			var GEOGRAPHIC = 0;
			if (PersonalInfoData.GEOGRAPHIC === "Major Cities") {
				GEOGRAPHIC = 0;
			} else if (PersonalInfoData.GEOGRAPHIC === "other towns and rural valleys") {
				GEOGRAPHIC = 5;
			} else if (PersonalInfoData.GEOGRAPHIC === "High altitude rural areas") {
				GEOGRAPHIC = 10;
			} else {
				GEOGRAPHIC = 0;
			}

			//seventh condiotn
			var Housing_max = 4;
			var Housing_values = [];
			if (oAnnexureDModel.length > 0) {
				oAnnexureDModel.forEach(function (item, index) {
					var Housing_profile = oAnnexureDModel[index].SZPLT;
					if (Housing_profile >= "10") {
						Housing_values.push("0");
					} else if (Housing_profile < "10") {
						Housing_values.push("4");
					} else {
						Housing_values.push("4");
					}
				});

				Housing_max = Math.max.apply(Math, Housing_values);
			}

			var Mobility_Profile = 0;
			if (oAnnexureFModel.length >= 2) {
				Mobility_Profile = 0;
			} else if (oAnnexureFModel.length === 1) {
				Mobility_Profile = 2;
			} else if (oAnnexureFModel.length === 0) {
				Mobility_Profile = 4;
			} else {
				Mobility_Profile = 0;
			}

			//Wealth_Profile
			var Wealth_Profile = 0;
			if (oSectionDModel.TOTAL > 125000) {
				Wealth_Profile = 0;
			} else if (oSectionDModel.TOTAL > 75000 && oSectionDModel.TOTAL <= 125000) {
				Wealth_Profile = 4;
			} else if (oSectionDModel.TOTAL > 25000 && oSectionDModel.TOTAL <= 75000) {
				Wealth_Profile = 8;
			} else if (oSectionDModel.TOTAL <= 25000) {
				Wealth_Profile = 12;
			} else {
				Wealth_Profile = 0;
			}

			//annual monetory income

			var Annual_Monetary_Incom_U = 0;
			var Annual_Monetary_Incom_R = 0;
			var get_OValue = this.byId("AnnualHouseHoldIncomeHI").getValue();
			var get_Vvalue = oAllDataModel.AB_ANCST;
			// var get_expValue = get_OValue - get_Vvalue / exchangerate ;
			var get_expValue = get_OValue - get_Vvalue; // / exchangerate ;
			if (PersonalInfoData.GEOGRAPHIC === "Major Cities") {
				Annual_Monetary_Incom_R = 0;
				if (get_expValue > 25000) {
					Annual_Monetary_Incom_U = 0;
				} else if (get_expValue > 20000 && get_expValue <= 25000) {
					Annual_Monetary_Incom_U = 7;
				} else if (get_expValue > 15000 && get_expValue <= 20000) {
					Annual_Monetary_Incom_U = 14;
				} else if (get_expValue > 10000 && get_expValue <= 15000) {
					Annual_Monetary_Incom_U = 21;
				} else if (get_expValue > 5000 && get_expValue <= 10000) {
					Annual_Monetary_Incom_U = 28;
				} else if (get_expValue <= 15000) {
					Annual_Monetary_Incom_U = 35;
				}
			} else if (PersonalInfoData.GEOGRAPHIC === "other towns and rural valleys") {
				Annual_Monetary_Incom_U = 0;
				if (get_expValue > 25000) {
					Annual_Monetary_Incom_R = 0;
				} else if (get_expValue > 20000 && get_expValue <= 25000) {
					Annual_Monetary_Incom_R = 3;
				} else if (get_expValue > 15000 && get_expValue <= 20000) {
					Annual_MoAnnual_Monetary_Incom_Rnetary_Incom = 6;
				} else if (get_expValue > 10000 && get_expValue <= 15000) {
					Annual_Monetary_Incom_R = 9;
				} else if (get_expValue > 5000 && get_expValue <= 10000) {
					Annual_Monetary_Incom_R = 12;
				} else if (get_expValue <= 15000) {
					Annual_Monetary_Incom_R = 15;
				}
			} else {
				Annual_Monetary_Incom_U = 0;
				Annual_Monetary_Incom_R = 0;
				// if (oInfoModel.Geographic === "other towns and rural valleys") {
				// 	if (get_expValue > 25000) {
				// 		Annual_Monetary_Incom = 0;
				// 	} else if (get_expValue > 20000 && get_expValue <= 25000) {
				// 		Annual_Monetary_Incom = 3;
				// 	} else if (get_expValue > 15000 && get_expValue <= 20000) {
				// 		Annual_Monetary_Incom = 6;
				// 	} else if (get_expValue > 10000 && get_expValue <= 15000) {
				// 		Annual_Monetary_Incom = 9;
				// 	} else if (get_expValue > 5000 && get_expValue <= 10000) {
				// 		Annual_Monetary_Incom = 12;
				// 	} else if (get_expValue <= 15000) {
				// 		Annual_Monetary_Incom = 15;
				// 	}

				// }
			};

			// eventh condiotn
			var farmland = 0;
			oAnnexureEModel.forEach(function (item, index) {
				var Res_Com_Agri = oAnnexureEModel[index].RCAGR;
				if (Res_Com_Agri === "A") {
					// if (oAnnexureDModel.SZPLT > 4) {
					farmland = 0;
					// }
					// else if (oAnnexureDModel.SZPLT <= 4) {
					// 	farmland = 10;
					// }
				} else {
					farmland = 10;
				}
			});

			//cattle and horse
			var horse_cattle = 0;
			var a = oAnnexureGModel.CATTLEQNTTY;
			// Number(a);
			var b = oAnnexureGModel.HORSEQNTTY;
			// Number(b);
			var total_Cat_horse = Number(a) + Number(b);
			// Number(total_Cat_horse);
			if (total_Cat_horse > 10 || total_Cat_horse > 10) {
				horse_cattle = 0;
			} else if (total_Cat_horse > 8 && total_Cat_horse <= 10) {
				horse_cattle = 1;
			} else if (total_Cat_horse > 6 && total_Cat_horse <= 8) {
				horse_cattle = 2;
			} else if (total_Cat_horse > 4 && total_Cat_horse <= 6) {
				horse_cattle = 3;
			} else if (total_Cat_horse > 2 && total_Cat_horse <= 4) {
				horse_cattle = 4;
			} else if (total_Cat_horse <= 2 && total_Cat_horse <= 2) {
				horse_cattle = 5;
			} else {
				horse_cattle = 0;
			}
			// var Loan_Repayment = "";
			// var per_loan = (oAnnexureCModel.LNPYT / 100) * 50;
			// if (per_loan > "20") {
			// 	Loan_Repayment = "0";

			// 	if (per_loan > "15" && per_loan <= "20") {
			// 		Loan_Repayment = "1";
			// 	} else if (per_loan > "10" && per_loan <= '15') {
			// 		Loan_Repayment = "2";
			// 	} else if (per_loan <= "10") {
			// 		Loan_Repayment = "3";
			// 	}
			// } else {

			// }

			//sheep and goat
			var sheep_goat = 0;
			var c = oAnnexureGModel.SHEEPQNTTY;
			// Number(c);
			var d = oAnnexureGModel.GOATQNTTY;
			// Number(d);
			var total_Quantity = Number(c) + Number(d);
			// Number(total_Quantity);
			if (total_Quantity > 100) {
				sheep_goat = 0;
			} else if (total_Quantity > 75 && total_Quantity <= 100) {
				sheep_goat = 1;
			} else if (total_Quantity > 50 && total_Quantity <= 75) {
				sheep_goat = 2;
			} else if (total_Quantity > 20 && total_Quantity <= 50) {
				sheep_goat = 3;
			} else if (total_Quantity > 5 && total_Quantity <= 20) {
				sheep_goat = 4;
			} else if (total_Quantity <= 5) {
				sheep_goat = 5;
			} else {
				sheep_goat = 0;
			}

			var Annual_Rent_Expense = 0;
			Number(oAnnexureCModel.HSRNT);
			if (oAnnexureCModel.HSRNT > 9000) {
				Annual_Rent_Expense = 0;
			} else if (oAnnexureCModel.HSRNT > 6000 && oAnnexureCModel.HSRNT <= 9000) {
				Annual_Rent_Expense = 1;
			} else if (oAnnexureCModel.HSRNT > 3000 && oAnnexureCModel.HSRNT <= 6000) {
				Annual_Rent_Expense = 3;
			} else if (oAnnexureCModel.HSRNT <= 3000) {
				Annual_Rent_Expense = 5;
			} else {
				Annual_Rent_Expense = 0;
			}

			var Electricity_Gas_Heating = 0;
			Number(oAnnexureCModel.UTEGH);
			if (oAnnexureCModel.UTEGH > 1200) {
				Electricity_Gas_Heating = 0;
			} else if (oAnnexureCModel.UTEGH > 900 && oAnnexureCModel.UTEGH <= 1200) {
				Electricity_Gas_Heating = 1;
			} else if (oAnnexureCModel.UTEGH > 600 && oAnnexureCModel.UTEGH <= 900) {
				Electricity_Gas_Heating = 3;
			} else if (oAnnexureCModel.UTEGH <= 600) {
				Electricity_Gas_Heating = 5;
			} else {
				Electricity_Gas_Heating = 0;
			}

			var Loans = 0;
			if (oAnnexureFModel.length >= 2) {
				Loans = 0;
			} else if (oAnnexureFModel.length === 1) {
				Loans = 1;
			} else if (oAnnexureFModel.length === 0) {
				Loans = 2;
			} else {
				Loans = 0;
			}

			var Loan_Repayment = 0;
			var get_Value = this.byId("AnnualHouseHoldIncomeHI").getValue();
			Number(get_Value);
			Number(oAllDataModel.AB_ANCST);
			var loan = 0;
			oSectionDTBLModel.forEach(function (item) {
				loan = loan + Number(item.ANREP);
			});
			var loan_cal = loan / get_Value - oAllDataModel.AB_ANCST;
			if (loan_cal > 20) {
				Loan_Repayment = 0;
			} else if (loan_cal > 15 && loan_cal <= 20) {
				Loan_Repayment = 1;
			} else if (loan_cal > 10 && loan_cal <= 15) {
				Loan_Repayment = 2;
			} else if (loan_cal <= 10) {
				Loan_Repayment = 3;
			} else {
				Loan_Repayment = 0;
			}

			var Overseas_Travel = 0;
			if (oSectionETbl1Model.length > 2) {
				Overseas_Travel = -5;
				// } else if (oSectionETbl1Model.length > 1 && oSectionETbl1Model.length <= 2) {
			} else if (oSectionETbl1Model.length === 2) {
				Overseas_Travel = -3;
			} else if (oSectionETbl1Model.length === 1) {
				Overseas_Travel = -2;
			} else if (oSectionETbl1Model.length === 0) {
				Overseas_Travel = 0;
			} else {
				Overseas_Travel = 0;
			}

			var family_vacation = 0;
			Number(oSectionEModel.FLYVT);
			if (oSectionEModel.FLYVT === "3") {
				family_vacation = -5;
			} else if (oSectionEModel.FLYVT === "2") {
				family_vacation = -3;
			} else if (oSectionEModel.FLYVT === "1") {
				family_vacation = -2;
			} else if (oSectionEModel.FLYVT === "0") {
				family_vacation = 0;
			} else {
				family_vacation = 0;
			}

			let IS_ABROAD = 0;
			let flagAB = 0;
			let flag3 = 0;
			oAnnexureBModel.forEach(function (item) {
				// var row = oAnnexureBModel[item];
				var PrivatevalueAB = item.IS_PRIVATE;
				if (PrivatevalueAB === "x") {
					flagAB++;
				} else if (PrivatevalueAB === "") {
					flag3++;
				}
			});
			if (flagAB > 0 && flag3 > 0) {
				IS_ABROAD = 2;
			} else if (flagAB > 0) {
				IS_ABROAD = 0;
			} else if (flag3 > 0) {
				IS_ABROAD = 4;
			} else {
				IS_ABROAD = 0;
			}

			// let IS_ABROAD = "";
			// let flagAB = 0;
			// let flag3 = 0;
			// oAnnexureBModel.forEach(function (item) {
			// 	// var row = oAnnexureBModel[item];
			// 	var Privatevalue = item.IS_ABROAD;
			// 	if (Privatevalue === "x") {
			// 		flagAB++;
			// 	} else if (Privatevalue === "") {
			// 		flag3++;
			// 	}
			// });
			// if (flagAB > 2) {
			// 	IS_ABROAD = -5;
			// } else if (flagAB > 1 && flagAB <= 2) {
			// 	IS_ABROAD = -3;
			// } else if (flagAB === 1) {
			// 	IS_ABROAD = -2;
			// 	else if (flagAB === 0) {
			// 		IS_ABROAD = 0;
			// 	}
			// } else {

			// }

			var total_Assessment = total_earn_memeber + Parent_Count + disable + age_max + IS_PRIVATE + GEOGRAPHIC + Housing_max +
				Mobility_Profile + Wealth_Profile + Annual_Monetary_Incom_U + Annual_Monetary_Incom_R + farmland + horse_cattle + sheep_goat +
				Annual_Rent_Expense + Electricity_Gas_Heating + Loans + Loan_Repayment + Overseas_Travel + family_vacation + IS_ABROAD;

			var logical_cond = {
				"TOTALASSESSMENT": total_Assessment,
				"TEARN": total_earn_memeber,
				"PCONT": Parent_Count,
				"DISLE": disable,
				"AGECHD": age_max,
				"TOEDU": IS_PRIVATE,
				"GEOPH": GEOGRAPHIC, //Geographic_Profile,
				"HOPRO": Housing_max, //Housing_values,
				"MOPRO": Mobility_Profile,
				"WEPRO": Wealth_Profile,
				"ANMIU": Annual_Monetary_Incom_U,
				"ANMIR": Annual_Monetary_Incom_R,
				"FARML": farmland,
				"HORSE": horse_cattle,
				"SHEEP": sheep_goat,
				// Live_Stock_Category_II: "",
				// Annual_Rent_Expense: "",
				"ANNUE": Annual_Rent_Expense,
				"ELCGH": Electricity_Gas_Heating,
				"ATCLO": Loans,
				"LOANR": Loan_Repayment,
				"PEROT": Overseas_Travel,
				"FAMVA": family_vacation,
				"OVEDU": IS_ABROAD
			};
			var logical_cond = JSON.stringify(logical_cond);
			var IPersonalInfoDataJSON = JSON.stringify(oPeronslData);
			var IAttachmentDataJSON = JSON.stringify(oAttachment);
			var oInfoModel = JSON.stringify(oInfoModel);
			var IStudentDataJSON = JSON.stringify(oSectionBModel);
			var IAnxDataJSON = JSON.stringify(oAllDataModel);
			var ISecBJSON = JSON.stringify(oSectionBModel);
			var ISecBTblJSON = JSON.stringify(SectionBTblModel);
			var ISecCJSON = JSON.stringify(oSectionCModel);
			var ISecDJSON = JSON.stringify(oSectionDModel);
			var ISecDTblJSON = JSON.stringify(oSectionDTBLModel);
			var ISecEJSON = JSON.stringify(oSectionEModel);
			var ISecET1JSON = JSON.stringify(oSectionETbl1Model);
			var ISecET2JSON = JSON.stringify(oSectionETbl2Model);
			var ISecFJSON = JSON.stringify(oSectionFModel);
			var IAnxAJSON = JSON.stringify(oAnnexureAModel);
			var IAnxBJSON = JSON.stringify(oAnnexureBModel);
			var IAnxCJSON = JSON.stringify(oAnnexureCModel);
			var IAnxDJSON = JSON.stringify(oAnnexureDModel);
			var IAnxEJSON = JSON.stringify(oAnnexureEModel);
			var IAnxFJSON = JSON.stringify(oAnnexureFModel);
			var IAnxGJSON = JSON.stringify(oAnnexureGModel);
			var IAnxHJSON = JSON.stringify(oAnnexureHModel);

			var oSaveObject = {
				"AssessmentData": logical_cond,
				"PersonalData": IPersonalInfoDataJSON,
				"Attachment": IAttachmentDataJSON,
				"AnexureData": IAnxDataJSON,
				"SectionB": ISecBJSON,
				"SecbTbl": ISecBTblJSON,
				"SectionC": ISecCJSON,
				"SectionD": ISecDJSON,
				"SecdTbl": ISecDTblJSON,
				"SectionE": ISecEJSON,
				"SeceT1": ISecET1JSON,
				"SeceT2": ISecET2JSON,
				"SectionF": ISecFJSON,
				"AnexureA": IAnxAJSON,
				"AnexureB": IAnxBJSON,
				"AnexureC": IAnxCJSON,
				"AnexureD": IAnxDJSON,
				"AnexureE": IAnxEJSON,
				"AnexureF": IAnxFJSON,
				"AnexureG": IAnxGJSON,
				"AnexureH": IAnxHJSON,
				"ICall": "C"
			};

			var dialog = new Dialog({
				title: 'Confirm',
				type: 'Message',
				state: 'Success',
				content: new Text({
					text: 'Do you want to Save Data?'
				}),
				beginButton: new Button({
					type: sap.m.ButtonType.Emphasized,
					text: 'Yes',
					press: function () {
						//call for Save Data
						dataManagerLib.saveRequest(oSaveObject,
							function (response) {
								var dialog = new Dialog({
									title: 'Confirm',
									type: 'Message',
									state: 'Success',
									content: new Text({
										text: 'Data has been saved?'
									}),
									beginButton: new Button({
										type: sap.m.ButtonType.Emphasized,
										text: 'Yes',
										press: function () {
											dialog.close();
										}
									}),
								});
								dialog.open();
							},
							function (error) {
								var dialog1 = new Dialog({
									title: 'Confirm',
									type: 'Message',
									state: 'Success',
									content: new Text({
										text: 'Data has been saved?'
									}),
									beginButton: new Button({
										type: sap.m.ButtonType.Emphasized,
										text: 'Yes',
										press: function () {
											dialog1.close();
										}
									}),
								});
								dialog1.open();
							});
						dialog.close();
					}

				}),
				endButton: new Button({
					text: 'No',
					press: function () {
						dialog.close();
					}
				}),
				afterClose: function () {
					dialog.destroy();
				}
			});
			dialog.open();

		},
		AgreeCheck: function (oEvent) {

			var oCheck = oEvent.getParameters().selected;
			var oSaveBtn = this.byId('btn_save');
			if (oCheck === true) {
				oSaveBtn.setEnabled(true);
			} else {
				oSaveBtn.setEnabled(false);
			}
		},

		onAddSectionBTblRow: function (oEvent) {
			var that = this;

			var oText;
			that.ParticipateRowId.id = that.ParticipateRowId.id + 1;

			//window.id = window.id + 1;
			oText = "Name" + that.ParticipateRowId.id;
			var NameID = oText;
			oText = "Relation" + that.ParticipateRowId.id;
			var RelationID = oText;
			oText = "Age" + that.ParticipateRowId.id;
			var AgeID = oText;
			oText = "MaritalStatus" + that.ParticipateRowId.id;
			var MaritalStatusID = oText;
			oText = "EconomicStatus" + that.ParticipateRowId.id;
			var EconomicStatusID = oText;
			oText = "PhysicalStatus" + that.ParticipateRowId.id;
			var PhysicalStatusID = oText;
			oText = "Livingwithhousehold" + that.ParticipateRowId.id;
			var LivingwithhouseholdID = oText;

			var oItem = new sap.m.ColumnListItem({
				cells: [
					new sap.m.Input(NameID, {
						width: "100%"
					}),
					new sap.m.Input(RelationID, {
						width: "100%"
					}),
					new sap.m.Input(AgeID, {
						width: "100%"
					}),
					new sap.m.Input(MaritalStatusID, {
						width: "100%"
					}),
					new sap.m.Input(EconomicStatusID, {
						width: "100%"
					}),
					new sap.m.Input(PhysicalStatusID, {
						width: "100%"
					}),
					new sap.m.Input(LivingwithhouseholdID, {
						width: "100%"
					}),
				]
			});

			var oTable = this.getView().byId('SectionBTbl');
			oTable.addItem(oItem);

			// this.byId('SectionBTbl').mAggregations.items[0].mAggregations.cells
			// this.byId('SectionBTbl').mAggregations.items[0].mAggregations.cells[0].mProperties.value;

		},

		deleteRowSectionBTbl: function (oEvent) {
			var that = this;
			var ButtonID = oEvent.getSource().getId().split('-')[2];
			var oTable = this.getView().byId(ButtonID);
			oTable.removeItem(oEvent.getParameter('listItem'));
		},

		onAddSectionBAnnexureATblRow: function (oEvent) {
			var that = this;
			var oText;
			that.AnnexureARowId.id = that.AnnexureARowId.id + 1;

			//window.id = window.id + 1;
			oText = "AnnAName" + that.AnnexureARowId.id;
			var AnnANameID = oText;
			oText = "TypeOfWork" + that.AnnexureARowId.id;
			var TypeofWorkID = oText;
			oText = "NameAddress" + that.AnnexureARowId.id;
			var NameAddressID = oText;
			oText = "AnnIncomeSalary" + that.AnnexureARowId.id;
			var AnnIncomeSalaryID = oText;
			oText = "AnnIncomeInv" + that.AnnexureARowId.id;
			var AnnIncomeInvID = oText;
			oText = "OtherIncome" + that.AnnexureARowId.id;
			var OtherIncomeID = oText;

			var oItem = new sap.m.ColumnListItem({
				cells: [
					new sap.m.Input(AnnANameID, {
						width: "100%"
					}),
					new sap.m.Input(TypeofWorkID, {
						width: "100%"
					}),
					new sap.m.Input(NameAddressID, {
						width: "100%"
					}),
					new sap.m.Input(AnnIncomeSalaryID, {
						width: "100%"
					}),
					new sap.m.Input(AnnIncomeInvID, {
						width: "100%"
					}),
					new sap.m.Input(OtherIncomeID, {
						width: "100%"
					}),
				]
			});

			var oTable = this.getView().byId('SectionBAnnexureATbl');
			oTable.addItem(oItem);

		},

		deleteRowSectionBAnnexureATbl: function (oEvent) {
			var that = this;
			var ButtonID = oEvent.getSource().getId().split('-')[2];
			var oTable = this.getView().byId(ButtonID);
			oTable.removeItem(oEvent.getParameter('listItem'));
		},

		onAddSectionBAnnexureBTblRow: function (oEvent) {
			var that = this;
			var oText;
			that.AnnexureBRowId.id = that.AnnexureBRowId.id + 1;

			var oSelect = "";
			var oSelfEducation = [{
				id: "Yes",
				text: "Yes"
			}, {
				id: "No",
				text: "No"
			}];

			//window.id = window.id + 1;
			oText = "AnnBNameB" + that.AnnexureBRowId.id;
			var AnnBNameBID = oText;
			oText = "ClassLevelB" + that.AnnexureBRowId.id;
			var ClassLevelBID = oText;
			oText = "NameInstituteB" + that.AnnexureBRowId.id;
			var NameInstituteBID = oText;
			oText = "AnnCostB" + that.AnnexureBRowId.id;
			var AnnCostBID = oText;
			oText = "AnnFinAidB" + that.AnnexureBRowId.id;
			var AnnFinAidBID = oText;
			oText = "SoruceAnnFinAidB" + that.AnnexureBRowId.id;
			var SoruceAnnFinAidBID = oText;
			oText = "oPublic" + that.AnnexureBRowId.id;
			var oPublic = oText;
			oText = "Abroad" + that.AnnexureBRowId.id;
			var Abroad = oText;
			oText = "SelfEducation" + that.AnnexureBRowId.id;
			var SelfEducation = oText;

			var oItem = new sap.m.ColumnListItem({
				cells: [
					new sap.m.Input(AnnBNameBID, {
						width: "100%"
					}),
					new sap.m.Input(ClassLevelBID, {
						width: "100%"
					}),
					new sap.m.Input(NameInstituteBID, {
						width: "100%"
					}),
					new sap.m.Input(AnnCostBID, {
						width: "100%"
					}),
					new sap.m.Input(AnnFinAidBID, {
						width: "100%"
					}),
					// new sap.m.Input(SoruceAnnFinAidBID, {
					// 	width: "100%"
					// }),
					new sap.m.Select(SoruceAnnFinAidBID, {
						width: "100%"
					}),
					// new sap.m.Input(oPublic, {
					// 	width: "100%"
					// }),
					new sap.m.Select(oPublic, {
						width: "100%"
					}),
					// new sap.m.Input(Abroad, {
					// 	width: "100%"
					// }),
					new sap.m.Select(Abroad, {
						width: "100%"
					}),
					// new sap.m.Input(SelfEducation, {
					// 	width: "100%"
					// }),
					new sap.m.Select(SelfEducation, {
						width: "100%"
					}),
					// new sap.m.CheckBox(oPublic, {
					// 	width: "50%"
					// }),
					// new sap.m.CheckBox(Abroad, {
					// 	width: "50%"
					// }),
					// new sap.m.CheckBox(SelfEducation, {
					// 	width: "50%"
					// }),

				]
			});

			oSelect = sap.ui.getCore().byId(SoruceAnnFinAidBID);
			oSelect.destroyItems();
			oSelfEducation.forEach(function (item, index) {
				var oItems = new sap.ui.core.Item({
					key: item.id,
					text: item.text
				});
				oSelect.addItem(oItems);
			});
			oSelect = sap.ui.getCore().byId(oPublic);
			oSelect.destroyItems();
			oSelfEducation.forEach(function (item, index) {
				var oItems = new sap.ui.core.Item({
					key: item.id,
					text: item.text
				});
				oSelect.addItem(oItems);
			});
			oSelect = sap.ui.getCore().byId(Abroad);
			oSelect.destroyItems();
			oSelfEducation.forEach(function (item, index) {
				var oItems = new sap.ui.core.Item({
					key: item.id,
					text: item.text
				});
				oSelect.addItem(oItems);
			});
			oSelect = sap.ui.getCore().byId(SelfEducation);
			oSelect.destroyItems();
			oSelfEducation.forEach(function (item, index) {
				var oItems = new sap.ui.core.Item({
					key: item.id,
					text: item.text
				});
				oSelect.addItem(oItems);
			});

			var oTable = this.getView().byId('SectionBAnnexureBTbl');
			oTable.addItem(oItem);

		},

		deleteRowSectionBAnnexureBTbl: function (oEvent) {
			var that = this;
			var ButtonID = oEvent.getSource().getId().split('-')[2];
			var oTable = this.getView().byId(ButtonID);
			oTable.removeItem(oEvent.getParameter('listItem'));
		},

		onAddSectionBAnnexureDTblRow: function (oEvent) {
			var that = this;
			var oText;
			that.AnnexureDRowId.id = that.AnnexureDRowId.id + 1;

			//window.id = window.id + 1;
			oText = "DateofPurchaseD" + that.AnnexureDRowId.id;
			var DateofPurchaseDID = oText;
			oText = "SizeofPlotD" + that.AnnexureDRowId.id;
			var SizeofPlotDID = oText;
			oText = "LocationD" + that.AnnexureDRowId.id;
			var LocationDID = oText;
			oText = "CityD" + that.AnnexureDRowId.id;
			var CityDID = oText;
			oText = "ResidentialD" + that.AnnexureDRowId.id;
			var ResidentialDID = oText;
			oText = "OriginalCostD" + that.AnnexureDRowId.id;
			var OriginalCostDID = oText;
			oText = "CurrentMarketValueD" + that.AnnexureDRowId.id;
			var CurrentMarketValueDID = oText;

			var oItem = new sap.m.ColumnListItem({
				cells: [
					new sap.m.Input(DateofPurchaseDID, {
						width: "100%"
					}),
					new sap.m.Input(SizeofPlotDID, {
						width: "100%"
					}),
					new sap.m.Input(LocationDID, {
						width: "100%"
					}),
					new sap.m.Input(CityDID, {
						width: "100%"
					}),
					new sap.m.Input(ResidentialDID, {
						width: "100%"
					}),
					new sap.m.Input(OriginalCostDID, {
						width: "100%"
					}),
					new sap.m.Input(CurrentMarketValueDID, {
						width: "100%"
					}),
				]
			});

			var oTable = this.getView().byId('SectionBAnnexureDTbl');
			oTable.addItem(oItem);

		},

		deleteRowSectionBAnnexureDTbl: function (oEvent) {
			var that = this;
			var ButtonID = oEvent.getSource().getId().split('-')[2];
			var oTable = this.getView().byId(ButtonID);
			oTable.removeItem(oEvent.getParameter('listItem'));
		},

		onAddSectionBAnnexureETblRow: function (oEvent) {
			var that = this;
			var oText;
			that.AnnexureERowId.id = that.AnnexureERowId.id + 1;

			var oResAgr = [{
				id: "R",
				text: "Residential"
			}, {
				id: "C",
				text: "Commercial"
			}, {
				id: "A",
				text: "Agricultural"
			}];

			//window.id = window.id + 1;
			oText = "DateofPurchaseE" + that.AnnexureERowId.id;
			var DateofPurchaseEID = oText;
			oText = "CoveredAreaE" + that.AnnexureERowId.id;
			var CoveredAreaEID = oText;
			oText = "LocationE" + that.AnnexureERowId.id;
			var LocationEID = oText;
			oText = "CityE" + that.AnnexureERowId.id;
			var CityID = oText;
			oText = "ResidentialE" + that.AnnexureERowId.id;
			var ResidentialEID = oText;
			oText = "OriginalCostE" + that.AnnexureERowId.id;
			var OriginalCostEID = oText;
			oText = "CurrentMarketValueE" + that.AnnexureERowId.id;
			var CurrentMarketValueEID = oText;

			var oItem = new sap.m.ColumnListItem({
				cells: [
					new sap.m.Input(DateofPurchaseEID, {
						width: "100%"
					}),
					new sap.m.Input(CoveredAreaEID, {
						width: "100%"
					}),
					new sap.m.Input(LocationEID, {
						width: "100%"
					}),
					new sap.m.Input(CityID, {
						width: "100%"
					}),
					new sap.m.Select(ResidentialEID, {
						width: "100%"
					}),
					// new sap.m.Input(ResidentialEID, {
					// 	width: "100%"
					// }),
					new sap.m.Input(OriginalCostEID, {
						width: "100%"
					}),
					new sap.m.Input(CurrentMarketValueEID, {
						width: "100%"
					}),
				]
			});

			var oSelect = "";
			oSelect = sap.ui.getCore().byId(ResidentialEID);
			oSelect.destroyItems();
			oResAgr.forEach(function (item, index) {
				var oItems = new sap.ui.core.Item({
					key: item.id,
					text: item.text
				});
				oSelect.addItem(oItems);
			});

			var oTable = this.getView().byId('SectionBAnnexureETbl');
			oTable.addItem(oItem);

		},

		deleteRowSectionBAnnexureETbl: function (oEvent) {
			var that = this;
			var ButtonID = oEvent.getSource().getId().split('-')[2];
			var oTable = this.getView().byId(ButtonID);
			oTable.removeItem(oEvent.getParameter('listItem'));
		},

		onAddSectionBAnnexureFTblRow: function (oEvent) {
			var that = this;
			var oText;
			that.AnnexureFRowId.id = that.AnnexureFRowId.id + 1;

			//window.id = window.id + 1;
			oText = "MakeandModelF" + that.AnnexureFRowId.id;
			var MakeandModelFID = oText;
			oText = "YearofManufactureF" + that.AnnexureFRowId.id;
			var YearofManufactureFID = oText;
			oText = "YearofPurchaseF" + that.AnnexureFRowId.id;
			var YearofPurchaseFID = oText;
			oText = "OriginalPurchasePriseF" + that.AnnexureFRowId.id;
			var OriginalPurchasePriseFID = oText;
			oText = "CurrentMarketValueF" + that.AnnexureFRowId.id;
			var CurrentMarketValueFID = oText;

			var oItem = new sap.m.ColumnListItem({
				cells: [
					new sap.m.Input(MakeandModelFID, {
						width: "100%"
					}),
					new sap.m.Input(YearofManufactureFID, {
						width: "100%"
					}),
					new sap.m.Input(YearofPurchaseFID, {
						width: "100%"
					}),
					new sap.m.Input(OriginalPurchasePriseFID, {
						width: "100%"
					}),
					new sap.m.Input(CurrentMarketValueFID, {
						width: "100%"
					}),
				]
			});

			var oTable = this.getView().byId('SectionBAnnexureFTbl');
			oTable.addItem(oItem);

		},

		deleteRowSectionBAnnexureFTbl: function (oEvent) {
			var that = this;
			var ButtonID = oEvent.getSource().getId().split('-')[2];
			var oTable = this.getView().byId(ButtonID);
			oTable.removeItem(oEvent.getParameter('listItem'));
		},

		onAddSectionBAnnexureHTblRow: function (oEvent) {
			var that = this;
			var oText;
			that.AnnexureHRowId.id = that.AnnexureHRowId.id + 1;

			//window.id = window.id + 1;
			oText = "NameofAccountHolder" + that.AnnexureHRowId.id;
			var NameofAccountHolderID = oText;
			oText = "NameofBank" + that.AnnexureHRowId.id;
			var NameofBankID = oText;
			oText = "AccountType" + that.AnnexureHRowId.id;
			var AccountTypeID = oText;
			oText = "Currency" + that.AnnexureHRowId.id;
			var CurrencyID = oText;
			oText = "Amount" + that.AnnexureHRowId.id;
			var AmountID = oText;

			var oItem = new sap.m.ColumnListItem({
				cells: [
					new sap.m.Input(NameofAccountHolderID, {
						width: "100%"
					}),
					new sap.m.Input(NameofBankID, {
						width: "100%"
					}),
					new sap.m.Input(AccountTypeID, {
						width: "100%"
					}),
					new sap.m.Input(CurrencyID, {
						width: "100%"
					}),
					new sap.m.Input(AmountID, {
						width: "100%"
					}),
				]
			});

			var oTable = this.getView().byId('SectionBAnnexureHTbl');
			oTable.addItem(oItem);

		},

		deleteRowSectionBAnnexureHTbl: function (oEvent) {
			var that = this;
			var ButtonID = oEvent.getSource().getId().split('-')[2];
			var oTable = this.getView().byId(ButtonID);
			oTable.removeItem(oEvent.getParameter('listItem'));
		},

		onAddSectionDTblRow: function (oEvent) {
			var that = this;
			var oText;
			that.SectionDTableRowId.id = that.SectionDTableRowId.id + 1;

			//window.id = window.id + 1;
			oText = "SDNameofLender" + that.SectionDTableRowId.id;
			var NameofLenderID = oText;
			oText = "SDPurpose" + that.SectionDTableRowId.id;
			var PurposeID = oText;
			oText = "SDCurrencysecD" + that.SectionDTableRowId.id;
			var CurrencysecDID = oText;
			oText = "SDPrincipalAmount" + that.SectionDTableRowId.id;
			var PrincipalAmountID = oText;
			oText = "SDAnnualRepayment" + that.SectionDTableRowId.id;
			var AnnualRepaymentID = oText;
			oText = "SDInterestRate" + that.SectionDTableRowId.id;
			var InterestRateID = oText;
			oText = "SDOutStanding" + that.SectionDTableRowId.id;
			var OutStandingID = oText;

			var oItem = new sap.m.ColumnListItem({
				cells: [
					new sap.m.Input(NameofLenderID, {
						width: "100%"
					}),
					new sap.m.Input(PurposeID, {
						width: "100%"
					}),
					new sap.m.Input(CurrencysecDID, {
						width: "100%"
					}),
					new sap.m.Input(PrincipalAmountID, {
						width: "100%"
					}),
					new sap.m.Input(AnnualRepaymentID, {
						width: "100%"
					}),
					new sap.m.Input(InterestRateID, {
						width: "100%"
					}),
					new sap.m.Input(OutStandingID, {
						width: "100%"
					}),
				]
			});

			var oTable = this.getView().byId('SectionDTbl');
			oTable.addItem(oItem);

		},

		deleteRowSectionDTblRow: function (oEvent) {
			var that = this;
			var ButtonID = oEvent.getSource().getId().split('-')[2];
			var oTable = this.getView().byId(ButtonID);
			oTable.removeItem(oEvent.getParameter('listItem'));
		},

		onAddSectionETblRow: function (oEvent) {
			var that = this;
			var oText;
			that.SectionETableRowId.id = that.SectionETableRowId.id + 1;

			//window.id = window.id + 1;
			oText = "SEName" + that.SectionETableRowId.id;
			var Name = oText;
			oText = "SECityCountry" + that.SectionETableRowId.id;
			var CityCountryID = oText;
			oText = "SEPurposeVisit" + that.SectionETableRowId.id;
			var PurposeVisitID = oText;
			oText = "SEDates" + that.SectionETableRowId.id;
			var DatesID = oText;
			oText = "SECurrency" + that.SectionETableRowId.id;
			var CurrencyID = oText;
			oText = "SEAmount" + that.SectionE2TableRowId.id;
			var AmountID = oText;
			oText = "SEPaidBy" + that.SectionE2TableRowId.id;
			var PaidByID = oText;

			var oItem = new sap.m.ColumnListItem({
				cells: [
					new sap.m.Input(Name, {
						width: "100%"
					}),
					new sap.m.Input(CityCountryID, {
						width: "100%"
					}),
					new sap.m.Input(PurposeVisitID, {
						width: "100%"
					}),
					new sap.m.Input(DatesID, {
						width: "100%"
					}),
					new sap.m.Input(CurrencyID, {
						width: "100%"
					}),
					new sap.m.Input(AmountID, {
						width: "100%"
					}),
					new sap.m.Input(PaidByID, {
						width: "100%"
					}),
				]
			});

			var oTable = this.getView().byId('SectionETbl');
			oTable.addItem(oItem);

		},

		deleteRowSectionETblRow: function (oEvent) {
			var that = this;
			var ButtonID = oEvent.getSource().getId().split('-')[2];
			var oTable = this.getView().byId(ButtonID);
			oTable.removeItem(oEvent.getParameter('listItem'));
		},

		onAddSectionE2TblRow: function (oEvent) {
			var that = this;
			var oText;
			that.SectionE2TableRowId.id = that.SectionE2TableRowId.id + 1;

			//window.id = window.id + 1;
			oText = "SE2Name" + that.SectionE2TableRowId.id;
			var Name = oText;
			oText = "SE2NameFund" + that.SectionE2TableRowId.id;
			var NameFundID = oText;
			oText = "SE2Currency" + that.SectionE2TableRowId.id;
			var CurrencyID = oText;
			oText = "SE2AmountApplied" + that.SectionE2TableRowId.id;
			var AmountAppliedID = oText;
			oText = "SE2AmountApproved" + that.SectionE2TableRowId.id;
			var AmountApprovedID = oText;

			var oItem = new sap.m.ColumnListItem({
				cells: [
					new sap.m.Input(Name, {
						width: "100%"
					}),
					new sap.m.Input(NameFundID, {
						width: "100%"
					}),
					new sap.m.Input(CurrencyID, {
						width: "100%"
					}),
					new sap.m.Input(AmountAppliedID, {
						width: "100%"
					}),
					new sap.m.Input(AmountApprovedID, {
						width: "100%"
					}),
				]
			});

			var oTable = this.getView().byId('SectionE2Tbl');
			oTable.addItem(oItem);

		},

		deleteRowSectionE2TblRow: function (oEvent) {
			var that = this;
			var ButtonID = oEvent.getSource().getId().split('-')[2];
			var oTable = this.getView().byId(ButtonID);
			oTable.removeItem(oEvent.getParameter('listItem'));
		},

		handleDeleteAttDocument: function (oEvent) {
			var oView = this.getView();
			var oModel = new sap.ui.model.json.JSONModel();
			var index;
			var oItem = oEvent.getParameter("listItem"),
				sPath = oItem.getBindingContext("Attachments").getPath();
			index = sPath.charAt(sPath.lastIndexOf('/') + 1);
			if (index !== "-1") {
				this.oItemss.splice(index, 1);
				var oItemsTemp = JSON.parse(JSON.stringify(this.oItemss));
				oModel.setData(oItemsTemp);
				oView.setModel(oModel, "Attachments");
				sap.m.MessageToast.show("Deleted");
			}
		},

		onAttDocument: function () {
			// var oShell = sap.ui.getCore().byId('Shell');
			var _attachmentUploader = this.getView().byId("DocumentAtt");
			var items = {};
			var that = this;
			// var oView = this.getView();
			this.sFileName = _attachmentUploader.getValue();
			if (!_attachmentUploader.getValue()) {
				sap.m.MessageToast.show("Choose a file first");
				return;
			}
			var file = jQuery.sap.domById(_attachmentUploader.getId() + "-fu").files[0];
			//var base64_marker = 'data:' + file.type + ';base64,';
			var filezise;
			var mimetype;
			var filename;
			filename = file.name;
			filezise = file.size / 1000;
			mimetype = file.type;
			if (mimetype === "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") {
				mimetype = "xls";
			} else if (mimetype === "application/vnd.openxmlformats-officedocument.wordprocessingml.document") {
				mimetype = "doc";
			} else if (mimetype === "application/pdf") {
				mimetype = "pdf";
			}

			if (filezise <= 2000) {
				if (mimetype === "doc" || mimetype === "xls" || mimetype === "pdf") {
					var reader = new FileReader();
					var d = new Date().toLocaleDateString().split("/");
					var y = d.splice(-1)[0];
					d.splice(0, 0, y);
					var uploadDate = d.join("-");
					reader.onload = function (file) {
						var base64 = reader.result;
						var b64 = base64;
						if (b64) {
							var base64Temp = b64.split('base64,');
							if (base64Temp) {
								items = {
									FILENAME: filename,
									FILETYPE: mimetype,
									FILESIZE: filezise.toString(),
									UPLOAD_DATE: uploadDate,
									BASE64: base64Temp[1],
									CONTENT: base64Temp[1]
								};
							}
							that.oItemss.push(items);
							var oItemsTemp = JSON.parse(JSON.stringify(that.oItemss));
							var oAttachmentModel = new sap.ui.model.json.JSONModel();
							oAttachmentModel.setData(oItemsTemp);

							sap.ui.getCore().byId('Master').setModel(oAttachmentModel, "Attachments");
							// oView.setModel(oModel, "attachments");
							// 		dialog.close();
							file = "";
							_attachmentUploader.setValue("");
						}
					};

					reader.readAsDataURL(file);
				} else {
					sap.m.MessageToast.show("File Format not supported");
				}
			} else {
				sap.m.MessageToast.show("File should not be greater then 2 MB");
			}
			//EOC read base64

		},

		onAttPress: function (oEvent) {
			//var that = this;
			var that = this;
			var opath = oEvent.getParameter("listItem").getBindingContextPath().slice(1);
			var osplit = opath;
			var oModel = this.getView().getModel("Attachments").getData();
			var arr_fin_attachment = oModel;
			//this.arr_fin_attachment.forEach(function (item, index) {
			if (arr_fin_attachment[osplit]) {
				if (arr_fin_attachment[osplit].filetype.toLocaleLowerCase() === 'jpeg' || arr_fin_attachment[osplit].filetype.toLocaleLowerCase() ===
					'jpg') {
					var blob = that.b64toBlob(arr_fin_attachment[osplit].content, 'image/jpeg');
					var blobUrl = URL.createObjectURL(blob);
					window.open(blobUrl);
				} else if (arr_fin_attachment[osplit].filetype.toLocaleLowerCase() === 'pdf') {
					var blob = that.b64toBlob(arr_fin_attachment[osplit].content, 'application/pdf');
					var blobUrl = URL.createObjectURL(blob);
					window.open(blobUrl);
				} else if (arr_fin_attachment[osplit].filetype.toLocaleLowerCase() === 'png') {
					var blob = that.b64toBlob(arr_fin_attachment[osplit].content, 'image/png');
					var blobUrl = URL.createObjectURL(blob);
					window.open(blobUrl);
				} else if (arr_fin_attachment[osplit].filetype.toLocaleLowerCase() === 'xls' || arr_fin_attachment[osplit].filetype.toLocaleLowerCase() ===
					'xlsx') {
					var blob = that.b64toBlob(arr_fin_attachment[osplit].content, 'application/vnd.ms-excel');
					var blobUrl = URL.createObjectURL(blob);
					window.open(blobUrl);
				} else if (arr_fin_attachment[osplit].filetype.toLocaleLowerCase() === 'doc' || arr_fin_attachment[osplit].filetype.toLocaleLowerCase() ===
					'docx') {
					var blob = that.b64toBlob(arr_fin_attachment[osplit].content, 'application/msword');
					var blobUrl = URL.createObjectURL(blob);
					window.open(blobUrl);
				} else if (arr_fin_attachment[osplit].filetype.toLocaleLowerCase() === 'ppt') {
					var blob = that.b64toBlob(arr_fin_attachment[osplit].content, 'application/vnd.ms-powerpoint');
					var blobUrl = URL.createObjectURL(blob);
					window.open(blobUrl);
				} else if (arr_fin_attachment[osplit].filetype.toLocaleLowerCase() === 'txt') {
					var blob = that.b64toBlob(arr_fin_attachment[osplit].content, 'text/plain');
					var blobUrl = URL.createObjectURL(blob);
					window.open(blobUrl);
				}
			}
			//})
		},
		b64toBlob: function (b64Data, contentType, sliceSize) {
			contentType = contentType || '';
			sliceSize = sliceSize || 512;
			var byteCharacters = atob(b64Data);
			var byteArrays = [];
			for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
				var slice = byteCharacters.slice(offset, offset + sliceSize);
				var byteNumbers = new Array(slice.length);
				for (var i = 0; i < slice.length; i++) {
					byteNumbers[i] = slice.charCodeAt(i);
				}
				var byteArray = new Uint8Array(byteNumbers);
				byteArrays.push(byteArray);
			}
			var blob = new Blob(byteArrays, {
				type: contentType
			});
			return blob;
		},

	});
});