sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"faf/tmc/z_fa_form_app/model/models",
	"faf/tmc/z_fa_form_app/util/dataManagerLib"
], function (UIComponent, Device, models, dataManagerLib) {
	"use strict";

	return UIComponent.extend("faf.tmc.z_fa_form_app.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function () {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// enable routing
			this.getRouter().initialize();

			// set the device model
			this.setModel(models.createDeviceModel(), "device");
			var sUrl = "/sap/opu/odata/sap/ZFAD_APP_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
			sap.ui.getCore().setModel(oModel);
			dataManagerLib.init(oModel);
		}
	});
});