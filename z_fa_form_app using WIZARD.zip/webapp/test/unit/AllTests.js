sap.ui.define([
	"faf/tmc/z_fa_form_app/test/unit/controller/Master.controller"
], function () {
	"use strict";
});