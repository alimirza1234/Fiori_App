jQuery.sap.declare("faf.tmc.z_fa_form_app.util.Formatter");
faf.tmc.z_fa_form_app.util.Formatter = {
	formatAttachmentIcon: function (sMimeType) {
		if (sMimeType === "pdf") {
			return 'sap-icon://pdf-attachment';
		} else if (sMimeType === "doc") {
			return 'sap-icon://doc-attachment';
		} else if (sMimeType === "xls") {
			return 'sap-icon://excel-attachment';
		}
	}
};