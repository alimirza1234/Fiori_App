sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device"
], function (JSONModel, Device) {
	"use strict";
	var _modelBase = null;
	return {
		init: function (oDataModel) {
			_modelBase = oDataModel;
			_modelBase.setCountSupported(false);
		},
		getoDataModel: function () {
			return _modelBase;
		},
		oModelRefresh: function () {
			_modelBase.refresh(true, false);
		},
		_getOData: function (sPath, oContext, oUrlParams, successCallback, errorCallback) {
			_modelBase.read(sPath, oContext, oUrlParams, true, function (response) {
				successCallback(response);
			}, function (response) {
				errorCallback(response);
			});
		},
		_postData: function (sPath, oContext, sucessCallback, errorCallback) {
			_modelBase.create(sPath, oContext, null, sucessCallback, errorCallback)
		},

		getHeaderData: function (successCallback, errorCallback) {
			var sPath = "Initial_call_set?$filter=ICall eq 'R'"; //personalInfoSet(ICall='R')";
			//	var sPath = "Initial_call_set?$filter=ICall eq 'R'";

			this._getOData(sPath, null, null, function (objResponse) {
				var oResult = objResponse;

				successCallback(oResult);
			}, function (objResponse) {
				//console.log("Error");
				errorCallback(objResponse);
			});
		},

		getPRData: function (successCallback, errorCallback) {
			var sPath = "Get_PR_ET_SET?$filter=IvCall eq 'P'";

			this._getOData(sPath, null, null, function (objResponse) {
				var oResult = objResponse;

				successCallback(oResult);
			}, function (objResponse) {
				//console.log("Error");
				errorCallback(objResponse);
			});

		},

		getDetailData: function (ICollective, IQuotation, IPRNumber, successCallback, errorCallback) {
			var sPath = "Detail_ET_SET?$filter=IvCall eq 'D' and IvCollective eq '" + ICollective + "' and IvQuotation eq '" + IQuotation +
				"' and IvPrNmbr eq '" + IPRNumber + "'";

			this._getOData(sPath, null, null, function (objResponse) {
				var oResult = objResponse;

				successCallback(oResult);
			}, function (objResponse) {
				//console.log("Error");
				errorCallback(objResponse);
			});

		},

		getDetailAllData: function (IStudentData, ISecF, ISecET2, ISecET1, ISecE, ISecDTbl, ISecD, ISecC, ISecBTbl, ISecB, IAnxH, IAnxG, IAnxF,
			IAnxE, IAnxData, IAnxD, IAnxC, IAnxB, IAnxA, successCallback, errorCallback) {

			var sPath = "save_call_set(IStudentData='" + IStudentData + "',ISecF='" + ISecF + "',ISecET2='" + ISecET2 + "',ISecET1='" + ISecET1 +
				"',ISecE='" + ISecE + "',ISecDTbl='" + ISecDTbl + "',ISecD='" + ISecD + "',ISecC='" + ISecC + "',ISecBTbl='" + ISecBTbl +
				"',ISecB='" + ISecB + "',ICall='C',IAnxH='" + IAnxH + "',IAnxG='" + IAnxG + "',IAnxF='" + IAnxF + "',IAnxE='" + IAnxE +
				"',IAnxData='" + IAnxData + "',IAnxD='" + IAnxD + "',IAnxC='" + IAnxC + "',IAnxB='" + IAnxB + "',IAnxA='" + IAnxA + "')";

			this._getOData(sPath, null, null, function (objResponse) {
				var oResult = objResponse;

				successCallback(oResult);
			}, function (objResponse) {
				//console.log("Error");
				errorCallback(objResponse);
			});

		},

		saveData: function (oObject, sucessCallback, errorCallback) {
			var sPath = "save_data_set";

			this._postData(sPath, oObject,
				function (objResponse) {
					var oResult = objResponse;
					sucessCallback(oResult);
				},
				function (objResponse) {
					console.log("Error");
					errorCallback(objResponse);
				});

		},

		managerData: function (successCallback, errorCallback) {
			var sPath = "manager_list_set?$filter=ICall eq 'S'";

			this._getOData(encodeURI(sPath), null, null, function (objResponse) {
				var oResult = objResponse;

				successCallback(oResult);
			}, function (objResponse) {
				//console.log("Error");
				errorCallback(objResponse);
			});

		},

		saveRequest: function (oObject, sucessCallback, errorCallback) {
			var sPath = "save_data_set";

			this._postData(sPath, oObject,
				function (objResponse) {
					var oResult = objResponse;
					sucessCallback(oResult);
				},
				function (objResponse) {
					console.log("Error");
					errorCallback(objResponse);
				});

		},

		showRequest: function (oObject, sucessCallback, errorCallback) {
			var sPath = "Edit_et_set";

			this._postData(sPath, oObject,
				function (objResponse) {
					var oResult = objResponse;
					sucessCallback(oResult);
				},
				function (objResponse) {
					console.log("Error");
					errorCallback(objResponse);
				});

		},

	};
});