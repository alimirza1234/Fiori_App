sap.ui.define([
	"sap/ui/core/mvc/Controller",
	'sap/ui/core/Fragment',
	"sap/ui/core/routing/History",
	"sap/ui/model/json/JSONModel",
	'sap/m/MessageBox',
	"sap/m/Button",
	"sap/m/Dialog",
	'sap/m/MessageToast',
	"sap/m/MessageStrip",
	"sap/m/Text",
	'sap/m/Token',
	'sap/ui/model/FilterOperator',
	'sap/ui/model/Filter',
	'sap/ui/Device',
	"Business_Trip/Business_Trip_Req/utils/dataManagerLib"
], function (Controller, Fragment, History, JSONModel, MessageBox, Button, Dialog, MessageToast, MessageStrip, Text, Token,
	FilterOperator, Filter, Device, dataManagerLib) {
	"use strict";

	return Controller.extend("Business_Trip.Business_Trip_Req.controller.Create", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf Business_Trip.Business_Trip_Req.view.Create
		 */
		EmployeeData: {},
		TravelInformation: [],
		TravelInfoObj: {},
		Countryhelp: [],
		TripType: [],
		Region: [],
		SectionETableRowId: {
			id: ""
		},
		onInit: function () {},

		onAfterRendering: function () {
			var that = this;
			that.getView().setModel(new JSONModel({
				width: (Device.system.phone) ? "70em" : "70em"
			}));
			dataManagerLib.GetEmployeeData(
				function (res) {
					console.log(res);
					if (res == undefined) {} else {
						that.EmployeeData = res;
						var oModel = new sap.ui.model.json.JSONModel({
							"employee": res
						});
						that.getView().setModel(oModel, "oEmployeeModel");
						that.getView().setBusy(false);
					}
				},
				function (res) {
					console.log(res);
					MessageToast.show("HTTP Error occurred.");
					that.getView().setBusy(false);
				});
			that.TravelInfoObj = {
				Travel_Date: "",
				Return_Date: "",
				Ticket_Class: "",
				Ticket_Type: "",
				Departure_From: "",
				Departure_to: "",
				Need_Urgent: "",
				Need_Mehram: "",
				Mehram_First_Name: "",
				Mehram_Surname: "",
				Date_of_Birth: "",
				Passport_No: "",
				Passport_Expiry: "",
				ID_Number: ""
			};
			var oTravelInfoObjModel = new sap.ui.model.json.JSONModel(this.TravelInfoObj);
			that.getView().setModel(oTravelInfoObjModel, "oTravelInfoObjModel");
			var oTravelInfoListModel = new sap.ui.model.json.JSONModel(this.TravelInformation);
			that.getView().setModel(oTravelInfoListModel, "oTravelInfoListModel");
			//add
			dataManagerLib.GetData(
				function (res) {

					that.Countryhelp = (res.results);
					var CountryModel = new JSONModel(that.Countryhelp);
					that.getView().setModel(CountryModel, "CountryModel");
				},
				function (res) {
					console.log(res);
					MessageToast.show("HTTP Error occurred.");
					that.getView().setBusy(false);
				});
			//add trip_type
			dataManagerLib.TripType(
				function (res) {

					that.TripType = (res.results);
					var TripTypeModel = new JSONModel(that.TripType);
					that.getView().setModel(TripTypeModel, "TripTypeModel");
				},
				function (res) {
					console.log(res);
					MessageToast.show("HTTP Error occurred.");
					that.getView().setBusy(false);
				});
			// add region
			dataManagerLib.Region(
				function (res) {

					that.Region = (res.results);
					var RegionModel = new JSONModel(that.Region);
					that.getView().setModel(RegionModel, "RegionModel");
				},
				function (res) {
					console.log(res);
					MessageToast.show("HTTP Error occurred.");
					that.getView().setBusy(false);
				});

		},

		onBackPress: function () {
			this.nav.back('Empty');
		},

		getCountryData: function (oEvent) {
			//debugger;
			var sInputValue = oEvent.getSource().getValue();

			// create value help dialog
			if (!this._valueHelpDialog) {
				Fragment.load({
					name: "Business_Trip.Business_Trip_Req.fragments.AssignCountryList",
					controller: this
				}).then(function (oValueCountryHelpDialog) {
					this._valueHelpDialog = oValueCountryHelpDialog;
					this.getView().addDependent(this._valueHelpDialog);
					this._openValueHelpDialog(sInputValue);
				}.bind(this));
			} else {
				this._openValueHelpDialog(sInputValue);
			}
		},
		_openValueHelpDialog: function (sInputValue) {
			// create a filter for the binding
			this._valueHelpDialog.getBinding("items").filter([new Filter(
				"Landx",
				FilterOperator.Contains,
				sInputValue
			)]);

			// open value help dialog filtered by the input value
			this._valueHelpDialog.open(sInputValue);
		},
		_handleValueHelpSearch: function (evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter(
				"Landx",
				FilterOperator.Contains,
				sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},
		_handleValueHelpClose: function (evt) {
			var aSelectedItems = evt.getParameter("selectedItems");
			var getTEXT = aSelectedItems[0].getProperty("title");
			var Input = this.byId("Country");
			Input.setValue(getTEXT);
		},

		getRegionData: function (oEvent) {
			//debugger;
			var sInputValue = oEvent.getSource().getValue();

			// create value help dialog
			if (!this._valueRegionHelpDialog) {
				Fragment.load({
					name: "Business_Trip.Business_Trip_Req.fragments.AssignRegionList",
					controller: this
				}).then(function (oValueRegionHelpDialog) {
					this._valueRegionHelpDialog = oValueRegionHelpDialog;
					this.getView().addDependent(this._valueRegionHelpDialog);
					this._openRegionValueHelpDialog(sInputValue);
				}.bind(this));
			} else {
				this._openRegionValueHelpDialog(sInputValue);
			}
		},
		_openRegionValueHelpDialog: function (sInputValue) {
			// create a filter for the binding
			this._valueRegionHelpDialog.getBinding("items").filter([new Filter(
				"Bezei",
				FilterOperator.Contains,
				sInputValue
			)]);

			// open value help dialog filtered by the input value
			this._valueRegionHelpDialog.open(sInputValue);
		},
		_handleRegionValueHelpSearch: function (evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter(
				"Bezei",
				FilterOperator.Contains,
				sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},
		_handleRegionValueHelpClose: function (evt) {
			var aSelectedItems = evt.getParameter("selectedItems");
			var Input = this.byId("Region");
			var getTEXT = aSelectedItems[0].getProperty("title");
			Input.setValue(getTEXT);
		},

		onAddSectionform: function (oEvent) {
			//debugger;
			if (!this.tableAdd) {
				this.tableAdd = this.loadFragment({
					name: "Business_Trip.Business_Trip_Req.fragments.TravelInfo"
				}, this);
				var CountryoModel = new sap.ui.model.json.JSONModel(this.Countryhelp);
				this.getView().setModel(CountryoModel, "CountryoModel");
			}
			this.tableAdd.then(function (oDialog) {
				oDialog.open();
			});
		},
		onChangeSelect: function (oEvent) {
			var key = oEvent.getParameter("selectedItem").getProperty("key");
			if (key === 'yes') {
				this.byId('Mehram_First_Name').setVisible(true);
				this.byId('Mehram_Surname').setVisible(true);
				this.byId('Date_of_Birth').setVisible(true);
				this.byId('Passport_No').setVisible(true);
				this.byId('Passport_Expiry').setVisible(true);
				this.byId('ID_Number').setVisible(true);
				this.byId('MFN').setVisible(true);
				this.byId('MSN').setVisible(true);
				this.byId('DATE_OF_BIRTH').setVisible(true);
				this.byId('PN').setVisible(true);
				this.byId('PE').setVisible(true);
				this.byId('IDN').setVisible(true);
			} else {
				this.byId('Mehram_First_Name').setVisible(false);
				this.byId('Mehram_Surname').setVisible(false);
				this.byId('Date_of_Birth').setVisible(false);
				this.byId('Passport_No').setVisible(false);
				this.byId('Passport_Expiry').setVisible(false);
				this.byId('ID_Number').setVisible(false);
				this.byId('MFN').setVisible(false);
				this.byId('MSN').setVisible(false);
				this.byId('DATE_OF_BIRTH').setVisible(false);
				this.byId('PN').setVisible(false);
				this.byId('PE').setVisible(false);
				this.byId('IDN').setVisible(false);
			}
		},
		
		onCloseDialog: function () {
			// note: We don't need to chain to the pDialog promise, since this event-handler
			// is only called from within the loaded dialog itself.
			this.byId("AddTableD").close();
		},
		onOkDialog: function (evt) {
			// note: We don't need to chain to the pDialog promise, since this event-handler
			// is only called from within the loaded dialog itself.
			var travelDialogData = this.getView().getModel("oTravelInfoObjModel").getData();
			var oTravelInfoListModel = this.getView().getModel("oTravelInfoListModel");
			var oTravelInfoListData = oTravelInfoListModel.getData();
			oTravelInfoListData.push(JSON.parse(JSON.stringify(travelDialogData)));
			oTravelInfoListModel.setData(oTravelInfoListData);
			this.getView().getModel('oTravelInfoObjModel').refresh();
			this.byId("AddTableD").close();
		},
		deleteRowSectionETblRow: function (oEvent) {
			var dIndex = oEvent.getParameter("listItem").getBindingContext("oTravelInfoListModel").getPath();
			dIndex = dIndex.replace("/", "");
			var travelobj = this.TravelInformation[dIndex];
			var oTravelInfoListModel = this.getView().getModel("oTravelInfoListModel");
			var travellistData = oTravelInfoListModel.getData();
			var index = travellistData.indexOf(travelobj);
			if (index > -1) { // only splice array when item is found
				travellistData.splice(index, 1); // 2nd parameter means remove one item only
			}
			oTravelInfoListModel.setData(travellistData);

		},

		//for table
		onBeforeRendering: function () {
			if (Device.system.phone) {
				Device.orientation.attachHandler(this._orientationHandler, this);
				if (Device.orientation.portrait) {
					this._showMessageStrip(false);
				} else {
					this._showMessageStrip(true);
				}
			}
		},
		_orientationHandler: function (mParams) {
			if (mParams.landscape) {
				this._showMessageStrip(true);
			} else {
				this._showMessageStrip(false);
			}
		},
		_showMessageStrip: function (bShow) {
			var oMessageStrip = this.getView().byId("idMessageStrip");
			oMessageStrip.setVisible(bShow);
		},

		onExit: function () {
			Device.orientation.detachHandler(this._orientationHandler, this);
		}

	});

});