sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/Sorter",
	"sap/m/MessageBox",
	"sap/f/library",
	"Business_Trip/Business_Trip_Req/utils/Formatter",
	"Business_Trip/Business_Trip_Req/utils/dataManagerLib",
	"sap/m/MessageToast"
], function (Controller, JSONModel, Filter, FilterOperator, Sorter, MessageBox, library, Formatter, dataManagerLib, MessageToast) {
	"use strict";

	return Controller.extend("Business_Trip.Business_Trip_Req.controller.Master", {
		Trips: [],
		onInit: function () {
			this.bGrouped = false;
			this.bDescending = false;
			this.sSearchQuery = 0;
		},
		_fnGroup: function (oContext) {
			var sStatus = oContext.getProperty("Status");

			return {
				key: sStatus,
				text: sStatus
			};
		},
		onReset: function (oEvent) {
			this.bGrouped = false;
			this.bDescending = false;
			this.sSearchQuery = 0;
			this.byId("maxPrice").setValue("");

			this.fnApplyFiltersAndOrdering();
		},
		onGroup: function (oEvent) {
			this.bGrouped = !this.bGrouped;
			this.fnApplyFiltersAndOrdering();
		},

		onSort: function (oEvent) {
			this.bDescending = !this.bDescending;
			this.fnApplyFiltersAndOrdering();
		},
		onSearch: function (oEvent) {
			this.sSearchQuery = oEvent.getSource().getValue();
			this.fnApplyFiltersAndOrdering();
		},
		fnApplyFiltersAndOrdering: function (oEvent) {
			var aFilter,
				aSorters = [];

			if (this.bGrouped) {
				aSorters.push(new Sorter("Status", this.bDescending, this._fnGroup));
			} else {
				aSorters.push(new Sorter("Request_Number", this.bDescending));
			}

			if (this.sSearchQuery) {
				aFilter = new sap.ui.model.Filter({
					filters: [
						new Filter("Request_Number", sap.ui.model.FilterOperator.Contains, this.sSearchQuery),
						new Filter("Pernr", sap.ui.model.FilterOperator.Contains, this.sSearchQuery),
						new Filter("Name", sap.ui.model.FilterOperator.Contains, this.sSearchQuery),
						new Filter("Country", sap.ui.model.FilterOperator.Contains, this.sSearchQuery),
						new Filter("Start_Date", sap.ui.model.FilterOperator.Contains, this.sSearchQuery),
						new Filter("End_Date", sap.ui.model.FilterOperator.Contains, this.sSearchQuery),
						new Filter("Create_Date", sap.ui.model.FilterOperator.Contains, this.sSearchQuery),
						new Filter("Status", sap.ui.model.FilterOperator.Contains, this.sSearchQuery)
					]
				});
			}

			this.byId("idTripList").getBinding("items").filter(aFilter).sort(aSorters);
		},

		onListItemPress: function (oEvent) {
			var that = this;
			var oList = oEvent.getSource();
			var context = oList.getSelectedContexts(true);
			var sPath = context[0].sPath;
			var sPathIndex = sPath.split("/");
			var selectedIndex = sPathIndex[2];
			var sRefNo = that.Trips.results[selectedIndex];
			var DetailPage = sap.ui.getCore().byId("Detail");
			DetailPage.setBusy(true);
			if (typeof (DetailPage) !== 'undefined') {
				//sap.ui.getCore().byId("historyPage").getController().onInit();
				sap.ui.getCore().getElementById("Detail").invalidate();
			}
			that.nav.to('Detail');
		},
		handlecreate: function () {
			var CreatePage = sap.ui.getCore().byId("Create");
			CreatePage.setBusy(true);
			if (typeof (CreatePage) !== 'undefined') {
				//sap.ui.getCore().byId("historyPage").getController().onInit();
				sap.ui.getCore().getElementById("Create").invalidate();
			}
			this.nav.to('Create');
		},
		handleRefresh: function (oEvent) {
			this.onBeforeRendering();
		},
		
		onBeforeRendering: function () {
			var self = this;
			var that = this.getView();
			var oList = that.byId('idTripList');
			oList.setBusy(true);

			dataManagerLib.GetTripListData(
				function (res) {
					console.log(res);
					if (res.results.length == 0) {
						oList.setBusy(false);
					} else {
						self.Trips = res;
						var oModel = new sap.ui.model.json.JSONModel({
							"trips": res.results
						});
						oList.setModel(oModel, "oTripsModel");
						var count = res.results.length;
						var oPage = that.byId("MasterPage");
						oPage.setTitle("List of Request (" + count + ")");
						oList.setBusy(false);
					}

				},
				function (res) {
					console.log(res);
					MessageToast.show("HTTP Error occurred.");
					oList.setBusy(false);
				});
		},

		onAfterRendering: function () {
		},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf Business_Trip.Business_Trip_Req.view.Master
		 */
		onExit: function () {

		}

	});

});