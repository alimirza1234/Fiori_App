sap.ui.define([
	"Business_Trip/Business_Trip_Req/test/unit/controller/App.controller"
], function () {
	"use strict";
});