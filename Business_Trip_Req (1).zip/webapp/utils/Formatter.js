sap.ui.define(function() {
	"use strict";

	var Formatter = {

		status :  function (sStatus) {
				if (sStatus === "Approved") {
					return "Success";
				} else if (sStatus === "Processing") {
					return "Warning";
				} else if (sStatus === "Rejected"){
					return "Error";
				} else {
					return "None";
				}
		}
	};

	return Formatter;

},  /* bExport= */ true);
