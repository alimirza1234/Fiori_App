sap.ui.define([
	"sap/ui/model/json/JSONModel"
], function (JSONModel) {
	"use strict";

	var _modelBase = null;

	function _getOData(sPath, oContext, oUrlParams, successCallback, errorCallback) {
		_modelBase.read(sPath, oContext, oUrlParams, true, function (response) {

			successCallback(response);
		}, function (response) {

			errorCallback(response);
		});
	}

	function _postData(sPath, oContext, sucessCallback, errorCallback) {
		_modelBase.create(sPath, oContext, null, sucessCallback, errorCallback);
	}

	return {

		init: function (oDataModel) {
			_modelBase = oDataModel;
			_modelBase.setCountSupported(false);
		},

		getoDataModel: function () {
			return _modelBase;
		},

		oModelRefresh: function () {
			_modelBase.refresh(true, false);
		},

		GetData: function (successCallback, errorCallback) {
			// 	var paginationPrams = {
			// 	Max_R: sTaskID
			// };
			var sPath = "CountryValhelpSet?$format=json";

			_getOData(sPath, null, null, function (objResponse) {
				var oResult = objResponse;

				successCallback(oResult);
			}, function (objResponse) {
				//console.log("Error");
				errorCallback(objResponse);
			});

		},
		TripType: function (successCallback, errorCallback) {
			// 	var paginationPrams = {
			// 	Max_R: sTaskID
			// };
			var sPath = "TripTypeSet?$format=json";

			_getOData(sPath, null, null, function (objResponse) {
				var oResult = objResponse;

				successCallback(oResult);
			}, function (objResponse) {
				//console.log("Error");
				errorCallback(objResponse);
			});

		},
		Region: function (successCallback, errorCallback) {
			// 	var paginationPrams = {
			// 	Max_R: sTaskID
			// };
			var sPath = "CountryValhelpSet('IN')/NavCountryToCity?$format=json";

			_getOData(sPath, null, null, function (objResponse) {
				var oResult = objResponse;

				successCallback(oResult);
			}, function (objResponse) {
				//console.log("Error");
				errorCallback(objResponse);
			});

		},
		GetTripListData: function (successCallback, errorCallback) {
			var sPath = "TripInfoSet";
			_getOData(sPath, null, null, function (objResponse) {
				var oResult = objResponse;
				successCallback(oResult);
			}, function (objResponse) {
				errorCallback(objResponse);
			});

		},
		GetEmployeeData: function (successCallback, errorCallback) {

			var sPath = "TripInfoSet('00002344')?$format=json";

			_getOData(sPath, null, null, function (objResponse) {
				var oResult = objResponse;

				successCallback(oResult);
			}, function (objResponse) {
				//console.log("Error");
				errorCallback(objResponse);
			});

		},
		get_assigneto_filterlist: function (otabfilter, successCallback, errorCallback) {

			var sPath = "Get_dataSet(IvCall='" + otabfilter + "',IvGet=' ')";

			_getOData(sPath, null, null, function (objResponse) {
				var oResult = objResponse;

				successCallback(oResult);
			}, function (objResponse) {
				//console.log("Error");
				errorCallback(objResponse);
			});

		},
		get_assigneby_filterlist: function (otabfilter, successCallback, errorCallback) {

			var sPath = "Get_dataSet(IvCall='" + otabfilter + "',IvGet=' ')";

			_getOData(sPath, null, null, function (objResponse) {
				var oResult = objResponse;

				successCallback(oResult);
			}, function (objResponse) {
				//console.log("Error");
				errorCallback(objResponse);
			});

		},
		getF4helpdata: function (successCallback, errorCallback) {
			var sPath = "Get_dataSet(IvCall='G',IvGet='')";
			_getOData(sPath, null, null, function (objResponse) {
				var oResult = objResponse;
				successCallback(oResult);
			}, function (objResponse) {
				//console.log("Error");
				errorCallback(objResponse);
			});
		},
		getTaskDetails: function (sTaskID, successCallback, errorCallback) {

			var dataToPost = {
				Parent: sTaskID
			};
			dataToPost = JSON.stringify(dataToPost);
			var sPath = "Get_dataSet(IvCall='D',IvGet='" + dataToPost + "')";
			// var sPath = "detail_data_set?$filter=ICall eq 'J' and IBanfn eq '" + sTaskID + "'";

			_getOData(sPath, null, null, function (objResponse) {
				var oResult = objResponse;

				successCallback(oResult);
			}, function (objResponse) {
				//console.log("Error");
				errorCallback(objResponse);
			});

		},
		getprintattachment: function (sTaskID, successCallback, errorCallback) {

			var dataToPost = {
				TID: sTaskID
			};
			dataToPost = JSON.stringify(dataToPost);

			var sPath = "Process_streamSet(IvCall='P',IvGet='" + dataToPost + "')";

			_getOData(sPath, null, null, function (success) {
				var oResult = success;

				successCallback(oResult);
			}, function (error) {
				//console.log("Error");
				errorCallback(error);
			});

		},
		getReassigne: function (sTaskID, successCallback, errorCallback) {

			var dataToPost = sTaskID;

			dataToPost = JSON.stringify(dataToPost);
			var sPath = "Get_dataSet(IvCall='A',IvGet='" + dataToPost + "')";

			_getOData(sPath, null, null, function (objResponse) {
				var oResult = objResponse;

				successCallback(oResult);
			}, function (objResponse) {
				//console.log("Error");
				errorCallback(objResponse);
			});

		}, // origional one
		getComplete: function (sTaskID, percentage, comment, successCallback, errorCallback) {

			var dataToPost = {
				Parent: sTaskID,
				complete: percentage,
				comment: comment
			};
			dataToPost = JSON.stringify(dataToPost);
			var sPath = "Get_dataSet(IvCall='C',IvGet='" + dataToPost + "')";
			// var sPath = "detail_data_set?$filter=ICall eq 'J' and IBanfn eq '" + sTaskID + "'";

			_getOData(sPath, null, null, function (objResponse) {
				var oResult = objResponse;

				successCallback(oResult);
			}, function (objResponse) {
				//console.log("Error");
				errorCallback(objResponse);
			});

		},
		saveTask: function (oObject, sucessCallback, errorCallback) {

			var dataToPost1 = {
				IvGet: JSON.stringify(oObject)
			};
			var sPath = "/Create_taskSet";
			_postData(sPath, dataToPost1,
				function (objResponse) {
					var oResult = objResponse;
					sucessCallback(oResult);
				},
				function (objResponse) {
					errorCallback(objResponse);
				});

		},
		getAttachmentList: function (otaskId, successCallback, errorCallback) {

			var obj = {
				TID: otaskId
			};
			obj = JSON.stringify(obj);
			var sPath = "Process_streamSet(IvCall='L',IvGet='" + obj + "')";

			_getOData(sPath, null, null, function (success) {
				var oResult = success;

				successCallback(oResult);
			}, function (error) {
				//console.log("Error");
				errorCallback(error);
			});

		},
		getAttachment: function (oFileObject, successCallback, errorCallback) {

			oFileObject = JSON.stringify(oFileObject);
			var sPath = "Process_streamSet(IvCall='R',IvGet='" + oFileObject + "')";

			_getOData(sPath, null, null, function (success) {
				var oResult = success;

				successCallback(oResult);
			}, function (error) {
				//console.log("Error");
				errorCallback(error);
			});

		},
		sendattachment: function (fileObject, successCallback, errorCallback) {

			var object = {
				IvCall: "C",
				IvGet: JSON.stringify(fileObject)
			};
			var sPath = "/Process_streamSet";
			// var array = [];
			// array.push(object);
			_postData(sPath, object,
				function (objResponse) {
					var oResult = objResponse;
					successCallback(oResult);
				},
				function (objResponse) {
					errorCallback(objResponse);
				});
		},
		editTask: function (oObject, sucessCallback, errorCallback) {
			var sPath = "/Update_dataSet";
			var obj = {
				IvGet: JSON.stringify(oObject)
			};
			_postData(sPath, obj,
				function (objResponse) {
					var oResult = objResponse;
					sucessCallback(oResult);
				},
				function (objResponse) {
					errorCallback(objResponse);
				});

		},
	};
});