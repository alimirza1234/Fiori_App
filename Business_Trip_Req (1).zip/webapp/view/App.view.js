sap.ui.jsview("Business_Trip.Business_Trip_Req.view.App", {

	getControllerName: function () {
		return "Business_Trip.Business_Trip_Req.controller.App";
	},

	createContent: function (oController) {

		// to avoid scroll bars on desktop the root view must be set to block display
		this.setDisplayBlock(true);

		// create app
		// For Single Page
		// this.app = new sap.m.App();
		// For Split App
		this.app = new sap.m.SplitApp("App");
		
		// load the master page
		var master = sap.ui.xmlview("Master", "Business_Trip.Business_Trip_Req.view.Master");
		master.getController().nav = this.getController();
		this.app.addPage(master, true);

		// load the empty page
		var Empty = sap.ui.xmlview("Empty", "Business_Trip.Business_Trip_Req.view.Empty");
		Empty.getController().nav = this.getController();
		this.app.addPage(Empty, false);
		
		var Detail = sap.ui.xmlview("Detail", "Business_Trip.Business_Trip_Req.view.Detail");
		Detail.getController().nav = this.getController();
		this.app.addPage(Detail, false);
		
		var Create = sap.ui.xmlview("Create", "Business_Trip.Business_Trip_Req.view.Create");
		Create.getController().nav = this.getController();
		this.app.addPage(Create, false);

		// wrap app with shell
		return new sap.m.Shell("Shell", {
			title: "{i18n>title}",
			showLogout: false,
			app: this.app
		});
	}
});