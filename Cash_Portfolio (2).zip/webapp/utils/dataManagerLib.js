sap.ui.define([
	"sap/ui/model/json/JSONModel"
], function (JSONModel) {
	"use strict";

	var _modelBase = null;

	function _getOData(sPath, oContext, oUrlParams, successCallback, errorCallback) {
		_modelBase.read(sPath, oContext, oUrlParams, true, function (response) {

			successCallback(response);
		}, function (response) {

			errorCallback(response);
		});
	}

	function _postData(sPath, oContext, sucessCallback, errorCallback) {
		_modelBase.create(sPath, oContext, null, sucessCallback, errorCallback);
	}

	return {

		init: function (oDataModel) {
			debugger;
			_modelBase = oDataModel;
			_modelBase.setCountSupported(false);
		},

		getoDataModel: function () {
			return _modelBase;
		},

		oModelRefresh: function () {
			_modelBase.refresh(true, false);
		},

		GetData: function (successCallback, errorCallback) {
			var sPath = "totalSetSet(Bukrs='',Rfha='')";
			_getOData(sPath, null, null, function (objResponse) {
				var oResult = objResponse;

				successCallback(oResult);
			}, function (objResponse) {
				//console.log("Error");
				errorCallback(objResponse);
			});

		},
		GetReportData: function (successCallback, errorCallback) {
			debugger;
			// 	var paginationPrams = {
			// 	Max_R: sTaskID
			// };
			var sPath = "/cashSetSet";

			_getOData(sPath, null, null, function (objResponse) {
				var oResult = objResponse;

				successCallback(oResult);
			}, function (objResponse) {
				//console.log("Error");
				errorCallback(objResponse);
			});

		}
		
		// Region: function (successCallback, errorCallback) {
		// 	// 	var paginationPrams = {
		// 	// 	Max_R: sTaskID
		// 	// };
		// 	var sPath = "CountryValhelpSet('IN')/NavCountryToCity?$format=json";

		// 	_getOData(sPath, null, null, function (objResponse) {
		// 		var oResult = objResponse;

		// 		successCallback(oResult);
		// 	}, function (objResponse) {
		// 		//console.log("Error");
		// 		errorCallback(objResponse);
		// 	});

		// },
		// GetTripListData: function (successCallback, errorCallback) {
		// 	var sPath = "TripInfoSet";
		// 	_getOData(sPath, null, null, function (objResponse) {
		// 		var oResult = objResponse;
		// 		successCallback(oResult);
		// 	}, function (objResponse) {
		// 		errorCallback(objResponse);
		// 	});

		// },
		// GetEmployeeData: function (successCallback, errorCallback) {

		// 	var sPath = "TripInfoSet('00002344')?$format=json";

		// 	_getOData(sPath, null, null, function (objResponse) {
		// 		var oResult = objResponse;

		// 		successCallback(oResult);
		// 	}, function (objResponse) {
		// 		//console.log("Error");
		// 		errorCallback(objResponse);
		// 	});

		// },
		// get_assigneto_filterlist: function (otabfilter, successCallback, errorCallback) {

		// 	var sPath = "Get_dataSet(IvCall='" + otabfilter + "',IvGet=' ')";

		// 	_getOData(sPath, null, null, function (objResponse) {
		// 		var oResult = objResponse;

		// 		successCallback(oResult);
		// 	}, function (objResponse) {
		// 		//console.log("Error");
		// 		errorCallback(objResponse);
		// 	});

		// },
		// get_assigneby_filterlist: function (otabfilter, successCallback, errorCallback) {

		// 	var sPath = "Get_dataSet(IvCall='" + otabfilter + "',IvGet=' ')";

		// 	_getOData(sPath, null, null, function (objResponse) {
		// 		var oResult = objResponse;

		// 		successCallback(oResult);
		// 	}, function (objResponse) {
		// 		//console.log("Error");
		// 		errorCallback(objResponse);
		// 	});

		// },
		// getF4helpdata: function (successCallback, errorCallback) {
		// 	var sPath = "Get_dataSet(IvCall='G',IvGet='')";
		// 	_getOData(sPath, null, null, function (objResponse) {
		// 		var oResult = objResponse;
		// 		successCallback(oResult);
		// 	}, function (objResponse) {
		// 		//console.log("Error");
		// 		errorCallback(objResponse);
		// 	});
		// },
		// getTaskDetails: function (sTaskID, successCallback, errorCallback) {

		// 	var dataToPost = {
		// 		Parent: sTaskID
		// 	};
		// 	dataToPost = JSON.stringify(dataToPost);
		// 	var sPath = "Get_dataSet(IvCall='D',IvGet='" + dataToPost + "')";
		// 	// var sPath = "detail_data_set?$filter=ICall eq 'J' and IBanfn eq '" + sTaskID + "'";

		// 	_getOData(sPath, null, null, function (objResponse) {
		// 		var oResult = objResponse;

		// 		successCallback(oResult);
		// 	}, function (objResponse) {
		// 		//console.log("Error");
		// 		errorCallback(objResponse);
		// 	});

		// },
		// getprintattachment: function (sTaskID, successCallback, errorCallback) {

		// 	var dataToPost = {
		// 		TID: sTaskID
		// 	};
		// 	dataToPost = JSON.stringify(dataToPost);

		// 	var sPath = "Process_streamSet(IvCall='P',IvGet='" + dataToPost + "')";

		// 	_getOData(sPath, null, null, function (success) {
		// 		var oResult = success;

		// 		successCallback(oResult);
		// 	}, function (error) {
		// 		//console.log("Error");
		// 		errorCallback(error);
		// 	});

		// },
		// getReassigne: function (sTaskID, successCallback, errorCallback) {

		// 	var dataToPost = sTaskID;

		// 	dataToPost = JSON.stringify(dataToPost);
		// 	var sPath = "Get_dataSet(IvCall='A',IvGet='" + dataToPost + "')";

		// 	_getOData(sPath, null, null, function (objResponse) {
		// 		var oResult = objResponse;

		// 		successCallback(oResult);
		// 	}, function (objResponse) {
		// 		//console.log("Error");
		// 		errorCallback(objResponse);
		// 	});

		// }, // origional one
		// getComplete: function (sTaskID, percentage, comment, successCallback, errorCallback) {

		// 	var dataToPost = {
		// 		Parent: sTaskID,
		// 		complete: percentage,
		// 		comment: comment
		// 	};
		// 	dataToPost = JSON.stringify(dataToPost);
		// 	var sPath = "Get_dataSet(IvCall='C',IvGet='" + dataToPost + "')";
		// 	// var sPath = "detail_data_set?$filter=ICall eq 'J' and IBanfn eq '" + sTaskID + "'";

		// 	_getOData(sPath, null, null, function (objResponse) {
		// 		var oResult = objResponse;

		// 		successCallback(oResult);
		// 	}, function (objResponse) {
		// 		//console.log("Error");
		// 		errorCallback(objResponse);
		// 	});

		// },

	};
});