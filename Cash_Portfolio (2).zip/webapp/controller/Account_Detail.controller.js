sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device",
	"Cash_Portal/Cash_Portfolio/utils/dataManagerLib",
	"sap/m/MessageBox",
	"sap/m/MessageToast"
], function (Controller, JSONModel, Device, dataManagerLib, MessageBox, MessageToast) {
	"use strict";

	var banktext = "";
	return Controller.extend("Cash_Portal.Cash_Portfolio.controller.Account_Detail", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf Cash_Portal.Cash_Portfolio.view.Account_Detail
		 */
		onInit: function (oEvent) {

			// this.getOwnerComponent().getRouter().getRoute("Detail").attachMatched(this.onNavToCurrentPage, this);
			var that = this;
			// banktext = oEvent.getParameter("arguments").banktext;
			// that.getOwnerComponent().getRouter().getRoute("Detail").attachMatched(that.onNavToCurrentPage, that);
			that.getView().setModel(new JSONModel({
				width: (Device.system.phone) ? "50em" : "100em"
			}));

			// dataManagerLib.GetReportData(function (response) {
			// 	var result = [];
			// 	var gettext = sap.ui.getCore().byId('Shell').getModel('banktext').oData;
			// 	that.oBankList = (response.results);
			// 	that.oBankList.forEach(function (o) {
			// 		if (o.Bankl == gettext.banktext)
			// 			result.push(o);
			// 	});
			// 	var oBankModel = new JSONModel(result);
			// 	that.getView().setModel(oBankModel, "oBankModel");
			// 	that.getView().getMoel('oBankModel').refresh();
			// }, function (error) {
			// 	MessageToast.show("Error");
			// });

		},

		onNavBack: function (oEvent) {
			// debugger;
			// var oModel = sap.ui.getCore().byId('Shell').getModel('banktext') //Get Hold of the Model
			// oModel.setData(null);
			// sap.ui.getCore().byId('Shell').getModel('banktext').setData(null);
			// sap.ui.getCore().byId('Shell').getModel('banktext').refresh();
			this.nav.to('Detail');
		},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf Cash_Portal.Cash_Portfolio.view.Account_Detail
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf Cash_Portal.Cash_Portfolio.view.Account_Detail
		 */
		onAfterRendering: function () {
			var that = this;

			// dataManagerLib.GetReportData(function (response) {
			// 	var result = [];
			// 	var gettext = sap.ui.getCore().byId('Shell').getModel('banktext').oData;
			// 	that.oBankList = (response.results);
			// 	that.oBankList.forEach(function (o) {
			// 		if (o.Bankl == gettext.banktext)
			// 			result.push(o);
			// 	});
			// 	var oBankModel = new JSONModel(result);
			// 	that.getView().setModel(oBankModel, "oBankModel");
			// 	that.getView().getModel('oBankModel').refresh();
			// }, function (error) {
			// 	MessageToast.show("Error");
			// });
		},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf Cash_Portal.Cash_Portfolio.view.Account_Detail
		 */
		//	onExit: function() {
		//
		//	}

	});

});