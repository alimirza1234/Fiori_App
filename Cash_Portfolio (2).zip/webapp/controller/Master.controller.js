sap.ui.define([
	"sap/ui/core/mvc/Controller",
	'sap/ui/model/json/JSONModel',
	'sap/ui/core/Fragment',
	"sap/ui/core/routing/History",
	"Cash_Portal/Cash_Portfolio/utils/dataManagerLib",
	"sap/m/MessageBox",
	"sap/m/MessageToast"
], function (Controller, JSONModel, Fragment, History, dataManagerLib, MessageBox, MessageToast) {
	"use strict";

	return Controller.extend("Cash_Portal.Cash_Portfolio.controller.Master", {
		oChartData: {},

		onInit: function (oEvent) {
			var that = this;
			var oShell = sap.ui.getCore().byId('Shell');
			var oVizFrame = this.getView().byId("idVizFrame_1");
			dataManagerLib.GetData(function (response) {
				that.oChartData = (response);
				var oChartModel = new JSONModel(that.oChartData);
				that.getView().setModel(oChartModel, "oChartModel");
				var Alldata = oChartModel.getData();

				// that.getView().setModel(oTasksListModel, "TaskListModel");
				var oModel = new sap.ui.model.json.JSONModel();
				// var data = {
				var BankTotal = [
					// 	{
					// 	"Model": "Total",
					// 	"Value": Alldata.AllTotal

					// },
					{
						"Model": "Cash Position", //Cash Position
						"Value": Alldata.TotalCash

					}, {
						"Model": "DEBT AND INVESTMENT",
						"Value": Alldata.TotalCash

					}
				];
				// };
				oModel.setData(BankTotal);

				var oDataSet = new sap.viz.ui5.data.FlattenedDataset({
					//horizontal
					dimensions: [{

						name: 'Bank',
						value: "{Model}"
					}],
					measures: [{
						//vertical
						name: 'Amount',
						value: "{Value}",

					}],

					data: {
						path: "/"

					}

				});
				oVizFrame.setDataset(oDataSet);
				oVizFrame.setModel(oModel);
				oVizFrame.setVizType('bar');

				oVizFrame.setVizProperties({
					plotArea: {
						colorPalette: d3.scale.category20().range(),
						title: 'Bank total'

					}
				});
				var feedValueAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
						'uid': "valueAxis",
						'type': "Measure",
						'values': ["Amount"]
					}),
					feedCategoryAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
						'uid': "categoryAxis",
						'type': "Dimension",
						'values': ["Bank"]
					});

				oVizFrame.addFeed(feedValueAxis);
				oVizFrame.addFeed(feedCategoryAxis);

				var oPopOver = that.getView().byId("idPopOver");

				oPopOver.connect(oVizFrame.getVizUid());

				oPopOver.setActionItems([
					// 	{

					// 	type: 'action',
					// 	text: 'TOTAL',
					// 	press: function (oEvent) {
					// 		that.press01(oEvent);

					// 	}
					// },
					{

						type: 'action',
						text: 'CASH POTION', //CASH POTION
						press: function (oEvent) {
							that.press03(oEvent);
							// that.press02(oEvent);
						}
					}, {

						type: 'action',
						text: 'DEBT AND INVESTMENT',
						press: function (oEvent) {
							that.press02(oEvent);
						}
					}
				]);

			}, function (error) {
				MessageToast.show("Data load Complete");
			});
		},

		onNavToCurrentPage: function (oEvent) {

		},

		press02: function (oEvent) {
	
			this.oCrossAppNav = sap.ushell.Container.getService("CrossApplicationNavigation");
			// trigger navigation
			this.oCrossAppNav.toExternal({
				target: {
					semanticObject: "BankAccount",
					action: "analyzeCashPosition"
				},
				params: {
					"EvaluationId": ".SFIN.CASHMGR.CASHPOSITIONVAR"
				}
			});
			// var href2 = this.oCrossAppNav.toExternal({
			// 	target: {
			// 		shellHash: "#"
			// 	}
			// });

			// var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
			// oCrossAppNavigator.toExternal({
			// 	target: {
			// 		semanticObject: "BankAccount",
			// 		action: "analyzeCashPosition"
			// 		// BankAccount-analyzeCashPosition
			// 	}

			// });

		},

		press03: function (oEvent) {

			this.nav.to('Detail');
		},

		getBankData: function (oEvent) {
			if (!this.newBankDialog) {
				this.newBankDialog = sap.ui.xmlfragment("Cash_Portal.Cash_Portfolio.fragments.BankList", this);
				var oModel = new sap.ui.model.json.JSONModel();
				this.newBankDialog.setModel(oModel);
			}

			this.newBankDialog.open();
		},

		Exchange_rate: function (oEvent) {

			if (!this.newExchangeDialog) {
				this.newExchangeDialog = sap.ui.xmlfragment("Cash_Portal.Cash_Portfolio.fragments.ExchangeRate", this);
				var oModel = new sap.ui.model.json.JSONModel();
				this.newExchangeDialog.setModel(oModel);
			}
			this.newExchangeDialog.open();
		},

		onAfterRendering: function () {

		},

		//	onExit: function() {
		//
		//	}

	});

});