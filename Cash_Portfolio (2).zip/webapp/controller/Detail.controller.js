sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device",
	"Cash_Portal/Cash_Portfolio/utils/dataManagerLib",
	"sap/m/MessageBox",
	"sap/m/MessageToast"
], function (Controller, JSONModel, Device, dataManagerLib, MessageBox, MessageToast) {
	"use strict";

	return Controller.extend("Cash_Portal.Cash_Portfolio.controller.Detail", {

		oBankList: [],
		onInit: function () {
			var that = this;
			that.getView().setModel(new JSONModel({
				width: (Device.system.phone) ? "50em" : "100em"
			}));
			var oVizFrame = this.getView().byId("idVizFrame");
			dataManagerLib.GetReportData(function (response) {
				that.oBankList = (response.results);
				const mapper = {};

				that.oBankList.forEach(bank => {
					const bankName = bank.Bankl; // Bankl

					if (mapper[bankName]) {
						mapper[bankName] = mapper[bankName] + Number(bank.Closing)
					} else {
						mapper[bankName] = Number(bank.Closing)
					}

				});

				const mappedBanks = Object.keys(mapper).map(bankName => {
					return {
						Bankl: bankName,
						Closing: mapper[bankName]
					}
				})
				var oBankModel = new JSONModel(mappedBanks);
				var Bankdata = oBankModel.getData();
				var oModel = new sap.ui.model.json.JSONModel();
				var data = {
					"Cars": [{
						"Model": "SABB",
						"Value": Bankdata[0].Closing

					}, {
						"Model": "SNB", //Cash Position
						"Value": Bankdata[1].Closing

					}, {
						"Model": "RIYADH",
						"Value": Bankdata[2].Closing

					}, {
						"Model": "RJHI",
						"Value": Bankdata[3].Closing

					}, {
						"Model": "GIB",
						"Value": Bankdata[4].Closing

					}, {
						"Model": "INMA'",
						"Value": Bankdata[5].Closing

					}]
				};
				oModel.setData(data);

				var oDataSet = new sap.viz.ui5.data.FlattenedDataset({
					//horizontal
					dimensions: [{

						name: 'Bank',
						value: "{Model}"
					}],
					measures: [{
						//vertical
						name: 'Amount',
						value: "{Value}",

					}],

					data: {
						path: "/Cars"
					}

				});
				oVizFrame.setDataset(oDataSet);
				oVizFrame.setModel(oModel);
				oVizFrame.setVizType('bar');

				oVizFrame.setVizProperties({
					plotArea: {
						colorPalette: d3.scale.category20().range()

					}
				});
				var feedValueAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
						'uid': "valueAxis",
						'type': "Measure",
						'values': ["Amount"]
					}),
					feedCategoryAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
						'uid': "categoryAxis",
						'type': "Dimension",
						'values': ["Bank"]
					});

				oVizFrame.addFeed(feedValueAxis);
				oVizFrame.addFeed(feedCategoryAxis);

				var oPopOver = that.getView().byId("idPopOver");
				oPopOver.connect(oVizFrame.getVizUid());
				oPopOver.setActionItems([{

					type: 'action',
					text: 'SABB',
					press: function (oEvent) {
						that.press03(oEvent);

					}
				}, {

					type: 'action',
					text: 'SNB', //CASH POTION
					press: function (oEvent) {

						that.press03(oEvent);
					}
				}, {

					type: 'action',
					text: 'RIYADH',
					press: function (oEvent) {
						that.press03(oEvent);
					}
				}, {

					type: 'action',
					text: 'RJHI',
					press: function (oEvent) {
						that.press03(oEvent);
					}
				}, {

					type: 'action',
					text: 'GIB',
					press: function (oEvent) {
						that.press03(oEvent);
					}
				}, {

					type: 'action',
					text: 'INMA',
					press: function (oEvent) {
						that.press03(oEvent);
					}
				}]);
				// var Alldata = oChartModel.getData();

			}, function (error) {
				MessageToast.show("Error");
			});

		},

		press03: function (oEvent) {
			var that = this;
			var oShell = sap.ui.getCore().byId('Shell');
			var banktext = oEvent.getSource().mProperties.text
			var data = {
				"banktext": banktext
			};
			var getbanktext = new JSONModel(data);
			oShell.setModel(getbanktext, "banktext");
			oShell.getModel('banktext').refresh();
			var that = this;
			dataManagerLib.GetReportData(function (response) {
				var result = [];
				var gettext = sap.ui.getCore().byId('Shell').getModel('banktext').oData;
				that.oBankList = (response.results);
				that.oBankList.forEach(function (o) {
					if (o.Bankl == gettext.banktext)
						result.push(o);
				});
				var oBankModel = new JSONModel(result);
				oShell.setModel(oBankModel, "oBankModel");
				oShell.getModel('oBankModel').refresh();
			}, function (error) {
				MessageToast.show("Error");
			});

			this.nav.to('Account_Detail')
		},

		// onNavToCurrentPage: function(oEvent){
		// 	debugger;
		// },

		onNavBack: function (oEvent) {
			this.nav.to('Master');
		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf Cash_Portal.Cash_Portfolio.view.Detail
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf Cash_Portal.Cash_Portfolio.view.Detail
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf Cash_Portal.Cash_Portfolio.view.Detail
		 */
		//	onExit: function() {
		//
		//	}

	});

});