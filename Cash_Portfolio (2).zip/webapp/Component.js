sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"Cash_Portal/Cash_Portfolio/model/models",
	"sap/ui/model/odata/ODataModel",
	"Cash_Portal/Cash_Portfolio/utils/dataManagerLib"
], function (UIComponent, Device, models, ODataModel, dataManagerLib) {
	"use strict";

	return UIComponent.extend("Cash_Portal.Cash_Portfolio.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function () {
			debugger;
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// enable routing
			this.getRouter().initialize();
			// var oHashChanger = new sap.ui.core.routing.HashChanger();
			// var sHash = oHashChanger.getHash();

			// set the device model
			this.setModel(models.createDeviceModel(), "device");

			var sUrl = "/sap/opu/odata/sap/ZFI_CASH_SRV_SRV/";
			var oModel = new ODataModel(sUrl, true);
			sap.ui.getCore().setModel(oModel);
			dataManagerLib.init(oModel);
		}
	});
});