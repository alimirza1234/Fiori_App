sap.ui.define([
	"zqc_ins_sf_slt/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"zqc_ins_sf_slt/model/formatter",
	'sap/m/MessageToast'
], function(BaseController, JSONModel, formatter, MessageToast) {
	"use strict";

	return BaseController.extend("zqc_ins_sf_slt.controller.Detail", {

		formatter: formatter,

		onInit: function() {

			var oViewModel = new JSONModel({
				busy: false,
				delay: 0
			});

			this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);

			this.setModel(oViewModel, "detailView");

			this.getOwnerComponent().oWhenMetadataIsLoaded.then(this._onMetadataLoaded.bind(this));
		},
		onAfterRendering: function() {
			debugger
			var that = this;
			var sUrl4 = "/sap/opu/odata/sap/ZSN_GOOD_APP_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(sUrl4, true);
			var sPathInquire = "initial_set(IvCall='I')";
			var oItem = [];
			oItem.splice(0, 0, "");

			oModel.read(sPathInquire, null, null, true, function(success) {
				var user_id = JSON.parse(success.EvJson);
				user_id.forEach(function(obj) {
					if (obj.ZZGROUP === "GROUP D") {

						oItem.push(obj);

					}
				});
				var userModel = new JSONModel(oItem);
				that.getView().setModel(userModel, "userModel");
			}, function(error) {
				MessageToast.show("Users not found");
			});
		},

		onNavBack: function() {

			this.getOwnerComponent().getRouter().getTargets().display("master");

		},

		onSharePress: function() {
			var oShareSheet = this.byId("shareSheet");
			oShareSheet.addStyleClass(this.getOwnerComponent().getContentDensityClass());
			oShareSheet.openBy(this.byId("shareButton"));
		},

		onShareEmailPress: function() {
			var oViewModel = this.getModel("detailView");

			sap.m.URLHelper.triggerEmail(
				null,
				oViewModel.getProperty("/shareSendEmailSubject"),
				oViewModel.getProperty("/shareSendEmailMessage")
			);
		},

		onShareInJamPress: function() {
			var oViewModel = this.getModel("detailView"),
				oShareDialog = sap.ui.getCore().createComponent({
					name: "sap.collaboration.components.fiori.sharing.dialog",
					settings: {
						object: {
							id: location.href,
							share: oViewModel.getProperty("/shareOnJamTitle")
						}
					}
				});

			oShareDialog.open();
		},

		_onObjectMatched: function(oEvent) {
			var sObjectId = oEvent.getParameter("arguments").objectId;
			this.getOwnerComponent().oWhenMetadataIsLoaded.then(function() {
				var sObjectPath = this.getModel().createKey("ZQC_INS_SF_SLT_TSet", { //ZTB_QM_IP_PKL_BTLSet  ZTB_QM_IP_MMPSet
					INSPECTION_ID: sObjectId
				});
				this._bindView("/" + sObjectPath);
			}.bind(this));

			this.BindWeitTableData(sObjectId);
			this.BindImageTableData(sObjectId);

		},

		_bindView: function(sObjectPath) {

			var oViewModel = this.getModel("detailView");

			oViewModel.setProperty("/busy", false);

			this.getView().bindElement({
				path: sObjectPath,
				events: {
					change: this._onBindingChange.bind(this),
					dataRequested: function() {
						oViewModel.setProperty("/busy", true);
					},
					dataReceived: function() {
						oViewModel.setProperty("/busy", false);
					}
				}
			});
		},

		_onBindingChange: function() {
			var oView = this.getView(),
				oElementBinding = oView.getElementBinding();

			if (!oElementBinding.getBoundContext()) {
				this.getRouter().getTargets().display("detailObjectNotFound");

				this.getOwnerComponent().oListSelector.clearMasterListSelection();
				return;
			}

			var sPath = oElementBinding.getPath(),
				oResourceBundle = this.getResourceBundle(),
				oObject = oView.getModel().getObject(sPath),
				sObjectId = oObject.INSPECTION_ID,
				sObjectName = oObject.PRODUCTION_ORDER_NO,
				oViewModel = this.getModel("detailView");

			this.getOwnerComponent().oListSelector.selectAListItem(sPath);

			oViewModel.setProperty("/saveAsTileTitle", oResourceBundle.getText("shareSaveTileAppTitle", [sObjectName]));
			oViewModel.setProperty("/shareOnJamTitle", sObjectName);
			oViewModel.setProperty("/shareSendEmailSubject",
				oResourceBundle.getText("shareSendEmailObjectSubject", [sObjectId]));
			oViewModel.setProperty("/shareSendEmailMessage",
				oResourceBundle.getText("shareSendEmailObjectMessage", [sObjectName, sObjectId, location.href]));
		},

		_onMetadataLoaded: function() {

			var iOriginalViewBusyDelay = this.getView().getBusyIndicatorDelay(),
				oViewModel = this.getModel("detailView");

			oViewModel.setProperty("/delay", 0);

			oViewModel.setProperty("/busy", true);

			oViewModel.setProperty("/delay", iOriginalViewBusyDelay);
		},
		fPackageChange: function(oEvent) {
			var sValue = this.getView().byId("ddl_PACKAGE_TYPE").getSelectedKey();
			var oInput = this.getView().byId("PACKAGE_TYPE");
			oInput.setValue(sValue);
			var newItem;
			if (sValue === "Carton") {
				newItem = new sap.ui.core.Item({
					key: "KG",
					text: "KG"
				});
				this.byId("ddl_Unit").removeAllItems();
				this.byId("ddl_Unit").addItem(newItem);
			} else {
				this.byId("ddl_Unit").removeAllItems();
				newItem = new sap.ui.core.Item({
					key: "GM",
					text: "GM"
				});
				this.byId("ddl_Unit").removeAllItems();
				this.byId("ddl_Unit").addItem(newItem);
			}
		},
		fnSaveWeightSet: function(oEvent) {
			// var that = this;
			var InsID = this.getView().byId("INSPECTION_ID_ID").getValue();
			var WeightID = this.getView().byId("Weight_id").getValue();
			var Package = this.getView().byId("PACKAGE_TYPE").getValue();

			var Unit = this.getView().byId("ddl_Unit").getSelectedItem().getText();
			if (InsID === "" || WeightID === "" || Unit === "" || Package === "") {
				sap.m.MessageBox.alert("All fields are mandatory");
			} else {
				var userRequestBody = {
					properties: {
						Inspection_Id: InsID,
						Weight: WeightID,
						Unit: Unit,
						Process_Id: '21', //01
						PACKAGE_TYPE: Package
					}
				};
				var oModel = this.getModel();
				var oContext = oModel.createEntry("/ZTB_QM_IPI_WEITSet", userRequestBody); // Give previous name as
				this.getView().setBindingContext(oContext);

				oModel.submitChanges();
				oModel.setRefreshAfterChange(true);
				var oMaterial = this.byId("Weight_id");

				oMaterial.setValue("");

			}
		},

		onSubmit: function() {
			var that = this;
			var InsID = this.getView().byId("INSPECTION_ID").getValue();
			var inspection_text = this.getView().byId("SUBMIT_BY").getValue();
			var getModel = this.getView().getModel("userModel").oData;

			//*************************************************************//
			var dialog = new sap.m.Dialog({
				title: 'Confirm',
				type: 'Message',
				content: [new sap.m.Text({
						// text: 'Are you sure you want to submit your inspection ' + InsID + ' ?'
						text: 'To submit your inspection, please enter the Pin Code.'
					}),
					new sap.m.Panel({
						height: "10px"
					}),
					new sap.m.Label({
						text: 'Pin Code',
						width: "100px",
						required: true

					}),
					new sap.m.Input('event', {
						liveChange: function(evt) {
							let eventName = evt.getParameter('value');
							var parent = evt.getSource().getParent();

							parent.getBeginButton().setEnabled(eventName.length > 0);
						},
						width: '50%',
						title: 'PIN CODE',
						placeholder: 'Enter User Pin Code'
					})
				],
				beginButton: new sap.m.Button({
					text: 'Submit',
					press: function() {

						getModel.forEach(function(obj) {
							if (obj.ZZUNAME === inspection_text) {
								var pincode = sap.ui.getCore().byId('event').mProperties.value;
								var pin_code = Number(pincode);
								if (obj.ZZPIN === pin_code) {
									var ServiceUrl = "/sap/opu/odata/sap/ZQC_IPI_INS_UNIT_SRV_01/";
									var oModel = new sap.ui.model.odata.ODataModel(ServiceUrl);
									sap.ui.getCore().setModel(oModel, "Main");

									var uriL = "ZSF_SUBMIT?&INSPECTION_ID='" + InsID + "'" + "&STATUS='2'&TBL='ZQC_INS_SF_SLT_T'";
									oModel.read(uriL, null, [], false, function(Odata, response) {

									});
									dialog.close();
									oModel.setRefreshAfterChange(true);

									that.getView().getModel().refresh();

								} else {
									MessageToast.show("Enter Correct Pin Code");
								}
							}
						});
					}
				}),
				endButton: new sap.m.Button({
					text: 'Cancel',
					press: function() {
						dialog.close();
					}
				}),
				afterClose: function() {

					dialog.destroy();
				}
			});

			dialog.open();

		},

		onSubmitInvalid: function() {
			var that = this;
			var InsID = this.getView().byId("INSPECTION_ID").getValue();
			var inspection_text = this.getView().byId("SUBMIT_BY").getValue();
			var getModel = this.getView().getModel("userModel").oData;

			var dialog = new sap.m.Dialog({
				title: 'Confirm',
				type: 'Message',
				content: [new sap.m.Text({
						text: 'Are you sure you want to ignore the inspection ' + InsID + ' ?'
					}),
					new sap.m.Panel({
						height: "10px"
					}),
					new sap.m.Label({
						text: 'Pin Code',
						width: "100px",
						required: true

					}),
					new sap.m.Input('event', {
						liveChange: function(evt) {
							let eventName = evt.getParameter('value');
							var parent = evt.getSource().getParent();

							parent.getBeginButton().setEnabled(eventName.length > 0);
						},
						width: '50%',
						placeholder: 'Enter User Pin Code'
					})
				],
				beginButton: new sap.m.Button({
					text: 'Ignore',
					press: function() {

						getModel.forEach(function(obj) {
							if (obj.ZZUNAME === inspection_text) {
								var pincode = sap.ui.getCore().byId('event').mProperties.value;
								var pin_code = Number(pincode);
								if (obj.ZZPIN === pin_code) {
									var ServiceUrl = "/sap/opu/odata/sap/ZQC_IPI_INS_UNIT_SRV_01/";
									var oModel = new sap.ui.model.odata.ODataModel(ServiceUrl);
									sap.ui.getCore().setModel(oModel, "Main");

									var uriL = "ZSF_SUBMIT?&INSPECTION_ID='" + InsID + "'" + "&STATUS='3'&TBL='ZQC_INS_SF_SLT_T'";
									oModel.read(uriL, null, [], false, function(Odata, response) {

									});
									dialog.close();
									oModel.setRefreshAfterChange(true);

									that.getView().getModel().refresh();
								} else {
									MessageToast.show("Enter Correct Pin Code");
								}
							}
						});
					}
				}),
				endButton: new sap.m.Button({
					text: 'Cancel',
					press: function() {
						dialog.close();
					}
				}),
				afterClose: function() {

					dialog.destroy();
				}
			});

			dialog.open();

		},

		onUploadComplete: function(oEvent) {

			var uc = this.getView().byId("UploadCollection");
			var oData = uc.getModel().getData();

			var aItems = uc.aItems;

			var oItem = {};

			var sUploadedFile = oEvent.getParameter("files")[0].fileName;

			if (!sUploadedFile) {
				var aUploadedFile = (oEvent.getParameters().getSource().getProperty("value")).split(/\" "/);
				sUploadedFile = aUploadedFile[0];
			}
			var InsID = this.getView().byId("INSPECTION_ID").getValue();
			oItem = {
				"fileName": sUploadedFile,
				"documentId": jQuery.now().toString(),
				"uploadedDate": new Date(jQuery.now()).toLocaleDateString(),
				"url": "/sap/opu/odata/sap/ZQC_IPI_INS_UNIT_SRV_01/",
				"Mimetype": "",
				"ProcessId": '21',
				"InspectionId": InsID,

				"fileSize": "505000" // TODO get file size

			};
			aItems.unshift(oItem);

			var that = this;

			setTimeout(function() {
					that.getView().getModel().refresh();
					sap.m.MessageToast.show("UploadComplete event triggered.");
				},
				4000);

		},
		onChange: function(oEvent) {

			var oModel = this.getView().getModel();
			oModel.refreshSecurityToken();
			var oHeaders = oModel.oHeaders;

			var sToken = oHeaders['x-csrf-token'];
			var oUploadCollection = oEvent.getSource();
			var oCustomerHeaderToken = new sap.m.UploadCollectionParameter({
				name: "x-csrf-token",
				value: sToken
			});
			oUploadCollection.addHeaderParameter(oCustomerHeaderToken);
			var InsID = this.getView().byId("INSPECTION_ID").getValue();
			var PrcsID = "21";

			// var inputslug = oEvent.getParameter("fileName");
			var inputslug = InsID + "/" + PrcsID;
			// inputslug = inputslug + "/" + "01";
			var oCustomerHeaderSlug = new sap.m.UploadCollectionParameter({
				name: "slug",
				value: inputslug

			});
			oUploadCollection.addHeaderParameter(oCustomerHeaderSlug);

		},

		onbtnclicked: function() {
			// var oModel = this.getModel();
			var InsID = this.getView().byId("INSPECTION_ID").getValue();
			// sap.m.MessageBox.alert()
			var oFilter = new sap.ui.model.Filter([
				new sap.ui.model.Filter("INSPECTION_ID", sap.ui.model.FilterOperator.EQ, InsID),
				new sap.ui.model.Filter("Process_Id", sap.ui.model.FilterOperator.EQ, '21')
			], true);

			oBinding.filter([oFilter]);

		},

		onTabSelect: function(oEvent) {
			var sKey = oEvent.getParameter("selectedKey");
			if (sKey === "info") {

			} else if (sKey === "attach") {

			} else if (sKey === "picture") {

			} else {

			}
		},

		isNumeric: function(obj) {
			var realStringObj = obj && obj.toString();
			return !jQuery.isArray(obj) && (realStringObj - parseFloat(realStringObj) + 1) >= 0;
		},

		valInput: function() {
			var FillingTemperature = this.getView().byId("Weight_id").getValue();
			var textval = this.byId("Weight_id");
			var oResult = this.isNumeric(FillingTemperature);
			if (!oResult) {
				sap.m.MessageBox.alert("Invalid Input, please input correct data");
				textval.setValue("");
			}
		},

		OnTypeMissmatch: function(oEvent) {
			sap.m.MessageBox.alert("File type invalid, only support jpeg,jpg.");
		},

		BindWeitTableData: function(insID) {

		},

		BindImageTableData: function(insID) {
			var oFilter = new sap.ui.model.Filter([
				new sap.ui.model.Filter("InspectionId", sap.ui.model.FilterOperator.EQ, insID),
				new sap.ui.model.Filter("ProcessId", sap.ui.model.FilterOperator.EQ, '21')
			], true);
			var oBinding = this.byId("UploadCollection").getBinding("items");
			oBinding.filter([oFilter]);
		},

		handleAdd: function() {
			this.getRouter().getTargets().display("create");
		}
	});

});