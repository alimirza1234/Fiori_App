sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	'sap/m/MessageToast'
], function(Controller, JSONModel, MessageToast) {
	"use strict";

	return Controller.extend("zqc_ins_sf_slt.controller.CreateEntity", {

		_oBinding: {},

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		onInit: function() {
			var that = this;
			this._oViewModel = new JSONModel({
				enableCreate: false,
				delay: 0,
				busy: false,
				mode: "create",
				viewTitle: ""
			});

			this._oODataModel = this.getOwnerComponent().getModel();
			this._oODataModel.setSizeLimit(5000);

			sap.ui.getCore().getMessageManager().registerObject(this.getView(), true);
			var oMessagesModel = sap.ui.getCore().getMessageManager().getMessageModel();
			this._oBinding = new sap.ui.model.Binding(oMessagesModel, "/", oMessagesModel.getContext("/"));
			this._oBinding.attachChange(function(oEvent) {
				var aMessages = oEvent.getSource().getModel().getData();
				for (var i = 0; i < aMessages.length; i++) {
					if (aMessages[i].type === "Error" && !aMessages[i].technical) {
						that._oViewModel.setProperty("/enableCreate", false);
					}
				}
			});
			var sUrl4 = "/sap/opu/odata/sap/ZSN_GOOD_APP_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(sUrl4, true);
			var sPathInquire = "initial_set(IvCall='I')";
			var oItem = [];
			oItem.splice(0, 0, "");
			// var obj_item = {name: 'Tom'};
			oModel.read(sPathInquire, null, null, true, function(success) {
				var user_id = JSON.parse(success.EvJson);
				user_id.forEach(function(obj) {
					if (obj.ZZGROUP === "GROUP D") {
						oItem.push(obj);
					}
				});
				var userModel = new JSONModel(oItem);
				that.getView().setModel(userModel, "userModel");
			}, function(error) {
				MessageToast.show("Users not found");
			});
		},
		///////////////// Custom Methods for Data load, approve and upload

		fShiftChange: function(oEvent) {
			var sValue = this.getView().byId("ddl_Shift").getSelectedKey();
			var oInput = this.getView().byId("SHIFT");
			oInput.setValue(sValue);
		},
		fPlantStatChange: function(oEvent) {
			var sValue = this.getView().byId("ddl_PLANT_STAT").getSelectedKey();
			var oInput = this.getView().byId("PLANT_STAT");
			if (sValue === "Ok" || sValue === "Operative") {
				this.getView().byId("ddl_PLANT_REMARKS").setEnabled(false);
				this.getView().byId("ddl_APP_RAW_SLT_STAT").setEnabled(true);
				this.getView().byId("APP_RAW_SLT_REM").setEnabled(true);
				this.getView().byId("ddl_CLEAN_JAWS_STAT").setEnabled(true);
				this.getView().byId("CLEAN_JAWS_REM").setEnabled(true);
				this.getView().byId("ddl_APP_BRN_STAT").setEnabled(true);
				this.getView().byId("APP_BRN_REM").setEnabled(true);
				this.getView().byId("ddl_MAN_SORT_STAT").setEnabled(true);
				this.getView().byId("MAN_SORT_REM").setEnabled(true);
				this.getView().byId("ddl_MAG_CLN_STAT").setEnabled(true);
				this.getView().byId("MAG_CLN_REM").setEnabled(true);
				this.getView().byId("ddl_CURR_WORK_STAT").setEnabled(true);
				this.getView().byId("CURR_WORK_REM").setEnabled(true);
				this.getView().byId("ddl_IODINE_STAT").setEnabled(true);
				this.getView().byId("IODINE_REM").setEnabled(true);
				this.getView().byId("PLANT_SPEED_VAL").setEnabled(true);
				this.getView().byId("PLANT_SPEED_REM").setEnabled(true);
				this.getView().byId("IODINE_FLOW_VAL").setEnabled(true);
				this.getView().byId("IODINE_FLOW_STAT").setEnabled(true);
				this.getView().byId("PART_SIZE_60_VAL").setEnabled(true);
				this.getView().byId("PART_SIZE_60_REM").setEnabled(true);
				this.getView().byId("PART_SIZE_10_VAL").setEnabled(true);
				this.getView().byId("PART_SIZE_10_REM").setEnabled(true);
				this.getView().byId("PART_SIZE_16_VAL").setEnabled(true);
				this.getView().byId("PART_SIZE_16_REM").setEnabled(true);
				this.getView().byId("IODINE2_VAL").setEnabled(true);
				this.getView().byId("IODINE_REM_2").setEnabled(true);
				this.getView().byId("PURITY_VAL").setEnabled(true);
				this.getView().byId("PURITY_REM").setEnabled(true);
				this.getView().byId("ddl_PARTICLE_STAT").setEnabled(true);
				this.getView().byId("PARTICLE_REM").setEnabled(true);
				this.getView().byId("ddl_GMP_COMP_STAT").setEnabled(true);
				this.getView().byId("GMP_COMP_REM").setEnabled(true);
				this.getView().byId("ddl_PROD_APPR_VAL").setEnabled(true);
				this.getView().byId("PROD_APPR_REM").setEnabled(true);
			} else {
				this.getView().byId("ddl_PLANT_REMARKS").setEnabled(true);
				this.getView().byId("ddl_APP_RAW_SLT_STAT").setEnabled(false);
				this.getView().byId("APP_RAW_SLT_REM").setEnabled(false);
				this.getView().byId("ddl_CLEAN_JAWS_STAT").setEnabled(false);
				this.getView().byId("CLEAN_JAWS_REM").setEnabled(false);
				this.getView().byId("ddl_APP_BRN_STAT").setEnabled(false);
				this.getView().byId("APP_BRN_REM").setEnabled(false);
				this.getView().byId("ddl_MAN_SORT_STAT").setEnabled(false);
				this.getView().byId("MAN_SORT_REM").setEnabled(false);
				this.getView().byId("ddl_MAG_CLN_STAT").setEnabled(false);
				this.getView().byId("MAG_CLN_REM").setEnabled(false);
				this.getView().byId("ddl_CURR_WORK_STAT").setEnabled(false);
				this.getView().byId("CURR_WORK_REM").setEnabled(false);
				this.getView().byId("ddl_IODINE_STAT").setEnabled(false);
				this.getView().byId("IODINE_REM").setEnabled(false);
				this.getView().byId("PLANT_SPEED_VAL").setEnabled(false);
				this.getView().byId("PLANT_SPEED_REM").setEnabled(false);
				this.getView().byId("IODINE_FLOW_VAL").setEnabled(false);
				this.getView().byId("IODINE_FLOW_STAT").setEnabled(false);
				this.getView().byId("PART_SIZE_60_VAL").setEnabled(false);
				this.getView().byId("PART_SIZE_60_REM").setEnabled(false);
				this.getView().byId("PART_SIZE_10_VAL").setEnabled(false);
				this.getView().byId("PART_SIZE_10_REM").setEnabled(false);
				this.getView().byId("PART_SIZE_16_VAL").setEnabled(false);
				this.getView().byId("PART_SIZE_16_REM").setEnabled(false);
				this.getView().byId("IODINE2_VAL").setEnabled(false);
				this.getView().byId("IODINE_REM_2").setEnabled(false);
				this.getView().byId("PURITY_VAL").setEnabled(false);
				this.getView().byId("PURITY_REM").setEnabled(false);
				this.getView().byId("ddl_PARTICLE_STAT").setEnabled(false);
				this.getView().byId("PARTICLE_REM").setEnabled(false);
				this.getView().byId("ddl_GMP_COMP_STAT").setEnabled(false);
				this.getView().byId("GMP_COMP_REM").setEnabled(false);
				this.getView().byId("ddl_PROD_APPR_VAL").setEnabled(false);
				this.getView().byId("PROD_APPR_REM").setEnabled(false);
			}
			oInput.setValue(sValue);
		},
		fPlantStatRemChange: function(oEvent) {
			var sValue = this.getView().byId("ddl_PLANT_REMARKS").getSelectedKey();
			var oInput = this.getView().byId("PLANT_REMARKS");
			oInput.setValue(sValue);
		},
		fAppRawSaltChange: function(oEvent) {
			var sValue = this.getView().byId("ddl_APP_RAW_SLT_STAT").getSelectedKey();
			var oInput = this.getView().byId("APP_RAW_SLT_STAT");
			oInput.setValue(sValue);
		},
		fCleanJawChange: function(oEvent) {
			var sValue = this.getView().byId("ddl_CLEAN_JAWS_STAT").getSelectedKey();
			var oInput = this.getView().byId("CLEAN_JAWS_STAT");
			oInput.setValue(sValue);
		},
		fAppBrnSltChange: function(oEvent) {
			var sValue = this.getView().byId("ddl_APP_BRN_STAT").getSelectedKey();
			var oInput = this.getView().byId("APP_BRN_STAT");
			oInput.setValue(sValue);
		},
		fManSortChange: function(oEvent) {
			var sValue = this.getView().byId("ddl_MAN_SORT_STAT").getSelectedKey();
			var oInput = this.getView().byId("MAN_SORT_STAT");
			oInput.setValue(sValue);
		},
		fMagClnChange: function(oEvent) {
			var sValue = this.getView().byId("ddl_MAG_CLN_STAT").getSelectedKey();
			var oInput = this.getView().byId("MAG_CLN_STAT");
			oInput.setValue(sValue);
		},
		fCountCurrChange: function(oEvent) {
			var sValue = this.getView().byId("ddl_CURR_WORK_STAT").getSelectedKey();
			var oInput = this.getView().byId("CURR_WORK_STAT");
			oInput.setValue(sValue);
		},
		fIodSpotTestChange: function(oEvent) {
			var sValue = this.getView().byId("ddl_IODINE_STAT").getSelectedKey();
			var oInput = this.getView().byId("IODINE_STAT");
			oInput.setValue(sValue);
		},
		fProdAppChange: function(oEvent) {
			var sValue = this.getView().byId("ddl_PROD_APPR_VAL").getSelectedKey();
			var oInput = this.getView().byId("PROD_APPR_VAL");
			oInput.setValue(sValue);
		},
		fBlackPartChange: function(oEvent) {
			var sValue = this.getView().byId("ddl_PARTICLE_STAT").getSelectedKey();
			var oInput = this.getView().byId("PARTICLE_STAT");
			oInput.setValue(sValue);
		},
		fGmpCompChange: function(oEvent) {
			var sValue = this.getView().byId("ddl_GMP_COMP_STAT").getSelectedKey();
			var oInput = this.getView().byId("GMP_COMP_STAT");
			oInput.setValue(sValue);
		},
		/**
		 * Event handler (attached declaratively) for the view save button. Saves the changes added by the user.&nbsp;
		 * @function
		 * @public
		 */
		onSave: function() {
			var messagetext = "";
			var Shift = this.getView().byId("SHIFT").getValue();

			if (messagetext !== "") {
				sap.m.MessageBox.show(messagetext + "cannot be null, please fill the values and try again");
			} else {
				var userRequestBody = {
					properties: {
						Shift: Shift
					}
				};

				var oModel = this.getOwnerComponent().getModel();
				var oContext = oModel.createEntry("/ZQC_INS_SF_SLT_TSet", userRequestBody); // ZTB_QM_IPPKL_JRSet
				this.getView().setBindingContext(oContext);
				oModel.setUseBatch(false);
				oModel.submitChanges();
				oModel.setRefreshAfterChange(true);
				this.getOwnerComponent().getRouter().getTargets().display("object");
			}
		},
		onCanel: function(oEvent) {
			var that = this;
			var dialog = new sap.m.Dialog({
				title: 'Confirm',
				type: 'Message',
				content: new sap.m.Text({
					text: 'Are you sure, you want to cancel? You will loose all your noted observations.'
				}),
				beginButton: new sap.m.Button({
					text: 'Ok',
					press: function() {
						// sap.m.MessageToast.show('Submit pressed!');
						that.clearFormdetails();
						dialog.close();
						that.getOwnerComponent().getRouter().getTargets().display("object");
					}
				}),
				endButton: new sap.m.Button({
					text: 'Cancel',
					press: function() {
						dialog.close();
					}
				}),
				afterClose: function() {
					dialog.destroy();
				}
			});

			dialog.open();
		},

		onPress: function(evt) {
			var that = this;
			var messagetext = "";
			var Shift = this.getView().byId("SHIFT").getValue();
			if (Shift === "" || Shift === "0") {
				messagetext = messagetext + "Shift,";
			}

			var BatchNo = this.getView().byId("BATCH_NO_ID").getValue();
			if (BatchNo === "") {
				messagetext = messagetext + " Batch #,";
			}

			var Plant = this.getView().byId("PLANT_ID_ID").getValue();
			if (Plant === "") {
				messagetext = messagetext + " Plant ID,";
			}

			var PlantName = this.getView().byId("PLANT_NAME").getValue();
			if (PlantName === "") {
				messagetext = messagetext + " Plant Name,";
			}

			var WORK_CENTER = this.getView().byId("WORK_CENTER").getValue();
			if (WORK_CENTER === "") {
				messagetext = messagetext + " Work Center,";
			}

			var MatId = this.getView().byId("MATERIAL_ID").getValue();
			if (MatId === "") {
				messagetext = messagetext + " Material ID,";
			}

			var MatDesc = this.getView().byId("MATERIAL_DESC").getValue();
			if (MatDesc === "") {
				messagetext = messagetext + " Material Name,";
			}

			// var SubmitBy = this.getView().byId("SUBMIT_BY").getValue();
			var Submit = this.getView().byId("SUBMIT_BY").getSelectedItem();
			var SubmitBy = Submit.getText();
			if (SubmitBy === "") {
				messagetext = messagetext + " Inspected By,";
			}

			var InspDept = this.getView().byId("INSPECTION_DEPT").getValue();
			if (InspDept === "") {
				messagetext = messagetext + " Inspection Dept,";
			}

			var ProductionOrder = this.getView().byId("PRODUCTION_ORDER_NO").getValue();
			if (ProductionOrder === "") {
				messagetext = messagetext + " Production Order No,";
			}

			var BasicStartDate = new sap.ui.model.type.DateTime();
			BasicStartDate = this.getView().byId("BASIC_START_DATE").getValue();
			if (BasicStartDate === "") {
				messagetext = messagetext + " Basic Start Date,";
			} else {
				var a = BasicStartDate.split(" ");
				var d = a[0].split(".");
				BasicStartDate = d[2] + "-" + d[1] + "-" + d[0];
			}

			var BasicFinishDate = new sap.ui.model.type.DateTime();
			BasicFinishDate = this.getView().byId("BASIC_FINISH_DATE").getValue();
			if (BasicFinishDate === "") {
				messagetext = messagetext + " Basic Finish Date,";
			} else {
				var a = BasicFinishDate.split(" ");
				var d = a[0].split(".");
				BasicFinishDate = d[2] + "-" + d[1] + "-" + d[0];
			}

			var CnfQty = this.getView().byId("TOTAL_CNF_QTY").getValue();
			if (CnfQty === "") {
				messagetext = messagetext + " Total Confirm Qty,";
			}

			var DlvQty = this.getView().byId("TOTAL_DLV_QTY").getValue();
			if (DlvQty === "") {
				messagetext = messagetext + " Total Delv Qty,";
			}

			var PlantStat = this.getView().byId("PLANT_STAT").getValue();
			if (PlantStat === "" || PlantStat === "0") {
				messagetext = messagetext + " Plant Status,";
			}

			var sVal = "0.00";

			var PLANT_REMARKS = this.getView().byId("PLANT_REMARKS").getValue();
			var APP_RAW_SLT_STAT = this.getView().byId("APP_RAW_SLT_STAT").getValue();
			var APP_RAW_SLT_REM = this.getView().byId("APP_RAW_SLT_REM").getValue();
			var CLEAN_JAWS_STAT = this.getView().byId("CLEAN_JAWS_STAT").getValue();
			var CLEAN_JAWS_REM = this.getView().byId("CLEAN_JAWS_REM").getValue();
			var APP_BRN_STAT = this.getView().byId("APP_BRN_STAT").getValue();
			var APP_BRN_REM = this.getView().byId("APP_BRN_REM").getValue();
			var MAN_SORT_STAT = this.getView().byId("MAN_SORT_STAT").getValue();
			var MAN_SORT_REM = this.getView().byId("MAN_SORT_REM").getValue();
			var MAG_CLN_STAT = this.getView().byId("MAG_CLN_STAT").getValue();
			var MAG_CLN_REM = this.getView().byId("MAG_CLN_REM").getValue();
			var CURR_WORK_STAT = this.getView().byId("CURR_WORK_STAT").getValue();
			var CURR_WORK_REM = this.getView().byId("CURR_WORK_REM").getValue();
			var IODINE_STAT = this.getView().byId("IODINE_STAT").getValue();
			if ((IODINE_STAT === "" || IODINE_STAT === "0") && (PlantStat === "Ok" || PlantStat === "Operative")) {
				messagetext = messagetext + "Iodine Spot";
			}
			var IODINE_REM = this.getView().byId("IODINE_REM").getValue();
			var PLANT_SPEED_VAL = this.getView().byId("PLANT_SPEED_VAL").getValue();
			if (PLANT_SPEED_VAL === "") {
				PLANT_SPEED_VAL = "0.00";
			}
			var PLANT_SPEED_REM = this.getView().byId("PLANT_SPEED_REM").getValue();
			var IODINE_FLOW_VAL = this.getView().byId("IODINE_FLOW_VAL").getValue();
			if (IODINE_FLOW_VAL === "") {
				IODINE_FLOW_VAL = "0.00";
			}
			var IODINE_FLOW_STAT = this.getView().byId("IODINE_FLOW_STAT").getValue();
			var PART_SIZE_60_VAL = this.getView().byId("PART_SIZE_60_VAL").getValue();
			if (PART_SIZE_60_VAL === "") {
				PART_SIZE_60_VAL = "0.00";
			}
			var PART_SIZE_60_REM = this.getView().byId("PART_SIZE_60_REM").getValue();
			var PART_SIZE_10_VAL = this.getView().byId("PART_SIZE_10_VAL").getValue();
			if (PART_SIZE_10_VAL === "") {
				PART_SIZE_10_VAL = "0.00";
			}
			var PART_SIZE_10_REM = this.getView().byId("PART_SIZE_10_REM").getValue();
			var PART_SIZE_16_VAL = this.getView().byId("PART_SIZE_16_VAL").getValue();
			if (PART_SIZE_16_VAL === "") {
				PART_SIZE_16_VAL = "0.00";
			}
			var PART_SIZE_16_REM = this.getView().byId("PART_SIZE_16_REM").getValue();
			var IODINE2_VAL = this.getView().byId("IODINE2_VAL").getValue();
			if (IODINE2_VAL === "") {
				IODINE2_VAL = "0.00";
			}
			var IODINE2_REM = this.getView().byId("IODINE_REM_2").getValue();
			var PURITY_VAL = this.getView().byId("PURITY_VAL").getValue();
			if (PURITY_VAL === "") {
				PURITY_VAL = "0.00";
			}
			var PURITY_REM = this.getView().byId("PURITY_REM").getValue();
			var PROD_APPR_VAL = this.getView().byId("PROD_APPR_VAL").getValue();
			if ((PROD_APPR_VAL === "" || PROD_APPR_VAL === "0") && (PlantStat === "Ok" || PlantStat === "Operative")) {
				messagetext = messagetext + " Product Appearance,";
			}
			var PROD_APPR_REM = this.getView().byId("PROD_APPR_REM").getValue();
			var PARTICLE_STAT = this.getView().byId("PARTICLE_STAT").getValue();
			var PARTICLE_REM = this.getView().byId("PARTICLE_REM").getValue();
			var GMP_COMP_STAT = this.getView().byId("GMP_COMP_STAT").getValue();
			if ((GMP_COMP_STAT === "" || GMP_COMP_STAT === "0") && (PlantStat === "Ok" || PlantStat === "Operative")) {
				messagetext = messagetext + " GMP Compliance,";
			}
			var GMP_COMP_REM = this.getView().byId("GMP_COMP_REM").getValue();
			var OVERALL_REM = this.getView().byId("OVERALL_REM").getValue();
			var DEPT_TYP = this.getView().byId("DEPT_TYP").getValue();
			if (messagetext !== "") {
				sap.m.MessageBox.alert(messagetext + "cannot be null, please fill the values and try again");
			} else {
				//***************************************************************//
				var dialog = new sap.m.Dialog({
					title: 'Confirm',
					type: 'Message',
					content: [new sap.m.Text({
						text: "Are you sure, you want to save your inspection  ?"
					})],
					beginButton: new sap.m.Button({
						text: 'Save',
						press: function() {
							//*******************************************//

							//****************************************************************//

							var userRequestBody = {
								properties: {
									SHIFT: Shift,
									BATCH_NO: BatchNo,
									PLANT_ID: Plant,
									PLANT_NAME: PlantName,
									WORK_CENTER: WORK_CENTER,
									MATERIAL_ID: MatId,
									MATERIAL_DESC: MatDesc,
									SUBMIT_BY: SubmitBy,
									INSPECTION_DEPT: InspDept,
									PRODUCTION_ORDER_NO: ProductionOrder,
									BASIC_START_DATE: new Date(BasicStartDate + " 11:13:00"),
									BASIC_FINISH_DATE: new Date(BasicFinishDate + " 11:13:00"),
									TOTAL_CNF_QTY: CnfQty,
									TOTAL_DLV_QTY: DlvQty,
									PLANT_STAT: PlantStat,
									PLANT_REMARKS: PLANT_REMARKS,
									APP_RAW_SLT_STAT: APP_RAW_SLT_STAT,
									APP_RAW_SLT_REM: APP_RAW_SLT_REM,
									CLEAN_JAWS_STAT: CLEAN_JAWS_STAT,
									CLEAN_JAWS_REM: CLEAN_JAWS_REM,
									APP_BRN_STAT: APP_BRN_STAT,
									APP_BRN_REM: APP_BRN_REM,
									MAN_SORT_STAT: MAN_SORT_STAT,
									MAN_SORT_REM: MAN_SORT_REM,
									MAG_CLN_STAT: MAG_CLN_STAT,
									MAG_CLN_REM: MAG_CLN_REM,
									CURR_WORK_STAT: CURR_WORK_STAT,
									CURR_WORK_REM: CURR_WORK_REM,
									IODINE_STAT: IODINE_STAT,
									IODINE_REM: IODINE_REM,
									PLANT_SPEED_VAL: PLANT_SPEED_VAL,
									PLANT_SPEED_REM: PLANT_SPEED_REM,
									IODINE_FLOW_VAL: IODINE_FLOW_VAL,
									IODINE_FLOW_STAT: IODINE_FLOW_STAT,
									PART_SIZE_60_VAL: PART_SIZE_60_VAL,
									PART_SIZE_60_REM: PART_SIZE_60_REM,
									PART_SIZE_10_VAL: PART_SIZE_10_VAL,
									PART_SIZE_10_REM: PART_SIZE_10_REM,
									PART_SIZE_16_VAL: PART_SIZE_16_VAL,
									PART_SIZE_16_REM: PART_SIZE_16_REM,
									IODINE2_VAL: IODINE2_VAL,
									IODINE2_REM: IODINE2_REM,
									PURITY_VAL: PURITY_VAL,
									PURITY_REM: PURITY_REM,
									PROD_APPR_VAL: PROD_APPR_VAL,
									PROD_APPR_REM: PROD_APPR_REM,
									PARTICLE_STAT: PARTICLE_STAT,
									PARTICLE_REM: PARTICLE_REM,
									GMP_COMP_STAT: GMP_COMP_STAT,
									GMP_COMP_REM: GMP_COMP_REM,
									OVERALL_REM: OVERALL_REM,
									DEPT_TYP: DEPT_TYP
								}
							};
							var oModel = that.getOwnerComponent().getModel();
							var oContext = oModel.createEntry("/ZQC_INS_SF_SLT_TSet", userRequestBody); //ZTB_QM_IPPKL_JRSet
							that.getView().setBindingContext(oContext);
							oModel.submitChanges();
							that.clearFormdetails();
							dialog.close();
							that.getOwnerComponent().getRouter().getTargets().display("object");

						}
					}),
					endButton: new sap.m.Button({
						text: 'Cancel',
						press: function() {
							dialog.close();
						}
					}),
					afterClose: function() {
						dialog.destroy();
					}
				});
				dialog.open();
			}

		},

		clearFormdetails: function() {
			var sVal = "";
			var oInput;

			oInput = this.getView().byId("SUBMIT_BY");
			oInput.setSelectedKey("0");
			oInput.setValue(sVal);

			oInput = this.getView().byId("ddl_Shift");
			oInput.setSelectedKey("0");
			oInput = this.getView().byId("SHIFT");
			oInput.setValue(sVal);

			oInput = this.getView().byId("ddl_PLANT_STAT");
			oInput.setSelectedKey("0");
			oInput = this.getView().byId("PLANT_STAT");
			oInput.setValue(sVal);

			oInput = this.getView().byId("PLANT_ID_ID");
			oInput.setValue(sVal);
			oInput = this.getView().byId("PLANT_NAME");
			oInput.setValue(sVal);
			oInput = this.getView().byId("BASIC_START_DATE");
			oInput.setValue(sVal);
			oInput = this.getView().byId("BASIC_FINISH_DATE");
			oInput.setValue(sVal);
			oInput = this.getView().byId("MATERIAL_ID");
			oInput.setValue(sVal);
			oInput = this.getView().byId("TOTAL_CNF_QTY");
			oInput.setValue(sVal);
			oInput = this.getView().byId("MATERIAL_DESC");
			oInput.setValue(sVal);
			oInput = this.getView().byId("TOTAL_DLV_QTY");
			oInput.setValue(sVal);
			oInput = this.getView().byId("PRODUCTION_ORDER_NO");
			oInput.setValue(sVal);
			oInput = this.getView().byId("BATCH_NO_ID");
			oInput.setValue(sVal);
			oInput = this.getView().byId("INSPECTION_DEPT");
			oInput.setValue(sVal);
			oInput = this.getView().byId("SUBMIT_BY");
			oInput.setValue(sVal);
			oInput = this.getView().byId("WORK_CENTER");
			oInput.setValue(sVal);
			oInput = this.getView().byId("ddl_PLANT_REMARKS");
			oInput.setSelectedKey("0");
			oInput = this.getView().byId("PLANT_REMARKS");
			oInput.setValue(sVal);

			oInput  =  this.getView().byId("ddl_APP_RAW_SLT_STAT");
			oInput.setSelectedKey("0");
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("APP_RAW_SLT_STAT");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("APP_RAW_SLT_REM");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("ddl_CLEAN_JAWS_STAT");
			oInput.setSelectedKey("0");
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("CLEAN_JAWS_STAT");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("CLEAN_JAWS_REM");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("ddl_APP_BRN_STAT");
			oInput.setSelectedKey("0");
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("APP_BRN_STAT");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("APP_BRN_REM");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("ddl_MAN_SORT_STAT");
			oInput.setSelectedKey("0");
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("MAN_SORT_STAT");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("MAN_SORT_REM");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("ddl_MAG_CLN_STAT");
			oInput.setSelectedKey("0");
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("MAG_CLN_STAT");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("MAG_CLN_REM");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("ddl_CURR_WORK_STAT");
			oInput.setSelectedKey("0");
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("CURR_WORK_STAT");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("CURR_WORK_REM");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("ddl_IODINE_STAT");
			oInput.setSelectedKey("0");
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("IODINE_STAT");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("IODINE_REM");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("PLANT_SPEED_VAL");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("PLANT_SPEED_REM");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("IODINE_FLOW_VAL");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("IODINE_FLOW_STAT");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("PART_SIZE_60_VAL");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("PART_SIZE_60_REM");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("PART_SIZE_10_VAL");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("PART_SIZE_10_REM");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("PART_SIZE_16_VAL");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("PART_SIZE_16_REM");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("IODINE2_VAL");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("IODINE_REM_2");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("PURITY_VAL");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("PURITY_REM");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("ddl_PARTICLE_STAT");
			oInput.setSelectedKey("0");
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("PARTICLE_STAT");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("PARTICLE_REM");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("ddl_GMP_COMP_STAT");
			oInput.setSelectedKey("0");
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("GMP_COMP_STAT");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("GMP_COMP_REM");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("ddl_PROD_APPR_VAL");
			oInput.setSelectedKey("0");
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("PROD_APPR_VAL");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("PROD_APPR_REM");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("OVERALL_REM");
			oInput.setValue(sVal);

		},
		/////////////////////////////////
		formatDate: function(_date, _format, _delimiter) {
			var formatLowerCase = _format.toLowerCase();
			var formatItems = formatLowerCase.split(_delimiter);
			var dateItems = _date.split(_delimiter);
			var monthIndex = formatItems.indexOf("mm");
			var dayIndex = formatItems.indexOf("dd");
			var yearIndex = formatItems.indexOf("yyyy");
			var month = parseInt(dateItems[monthIndex]);
			month -= 1;

			var formatedDate = new Date(dateItems[yearIndex], month, dateItems[dayIndex], '10', '10', '10', '10');
			return formatedDate;
		},

		fBatchChange: function(oEvent) {
			var that = this;
			this.byId("PLANT_ID_ID").setValue("");
			this.byId("PLANT_NAME").setValue("");
			this.byId("MATERIAL_ID").setValue("");
			this.byId("MATERIAL_DESC").setValue("");
			this.byId("INSPECTION_DEPT").setValue("");
			this.byId("PRODUCTION_ORDER_NO").setValue("");
			this.byId("BASIC_START_DATE").setValue("");
			this.byId("BASIC_FINISH_DATE").setValue("");
			this.byId("TOTAL_CNF_QTY").setValue("");
			this.byId("TOTAL_DLV_QTY").setValue("");
			this.byId("DEPT_TYP").setValue("");
			this.byId("WORK_CENTER").setValue("");

			var sVal = this.getView().byId("BATCH_NO_ID").getValue();

			if ((sVal !== "Select") || (sVal !== "")) {

				var oInput = this.getView().byId("BATCH_NO_ID");
				oInput.setValue(sVal);
				var oModel = this.getOwnerComponent().getModel();
				var sValue = this.getView().byId("BATCH_NO_ID").getValue();
				var readstring = "/ZST_AFPO_BATCHSet(CHARG='" + sValue + "|0010|Y')";
				// oModel.setRefreshAfterChange(false);

				oModel.read(readstring, {
					success: function(oData) {

						if (oData.CHARG === "") {
							sap.m.MessageBox.show("Invalid Batch #", {
								icon: sap.m.MessageBox.Icon.ERROR, // default
								title: "Error", // default
								actions: sap.m.MessageBox.Action.OK, // default
								onClose: null, // default
								styleClass: "", // default
								initialFocus: null, // default
								textDirection: sap.ui.core.TextDirection.Inherit // default
							});
						} else {
							var mResult = oData.Matnr;
							var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
								pattern: "dd.MM.yyyy"
							});
							var DEPT_TYP = "QM";
							that.byId("PLANT_ID_ID").setValue(oData.WERKS);
							that.byId("PLANT_NAME").setValue(oData.NAME1);
							that.byId("WORK_CENTER").setValue(oData.KTEXT);
							that.byId("MATERIAL_ID").setValue(oData.MATNR);
							that.byId("MATERIAL_DESC").setValue(oData.MAKTX);
							that.byId("INSPECTION_DEPT").setValue(oData.INSPECTION_DEPT);
							that.byId("PRODUCTION_ORDER_NO").setValue(oData.AUFNR);
							that.byId("TOTAL_CNF_QTY").setValue(oData.IGMNG);
							that.byId("TOTAL_DLV_QTY").setValue(oData.WEMNG);
							that.getView().byId("DEPT_TYP").setValue(DEPT_TYP);

							mResult = oData.GSTRP;
							var dateStr = dateFormat.format(mResult);
							that.byId("BASIC_START_DATE").setValue(dateStr);
							mResult = oData.GLTRP;
							dateStr = dateFormat.format(mResult);
							that.byId("BASIC_FINISH_DATE").setValue(dateStr);
						}

					},
					error: function(oError) {
						// Error handling on failed response
					}
				});
			}

		},
		//end

		//////////////////////////////////////////////////////////////////////////
		isNumeric: function(obj) {
			var realStringObj = obj && obj.toString();
			return !jQuery.isArray(obj) && (realStringObj - parseFloat(realStringObj) + 1) >= 0;
		},

		valInput_60: function() {
			var val = this.getView().byId("PART_SIZE_60_VAL").getValue();

			if (val !== '') {
				var oResult = this.isNumeric(val);
				if (!oResult) {
					sap.m.MessageBox.alert("Invalid Input: Particle size passing 60, please input correct data");
					var textval = this.byId("PART_SIZE_60_VAL");
					textval.setValue("");
				}
			}
		},
		valInput_10: function() {
			var val = this.getView().byId("PART_SIZE_10_VAL").getValue();

			if (val !== '') {
				var oResult = this.isNumeric(val);
				if (!oResult) {
					sap.m.MessageBox.alert("Invalid Input: Particle size passing 10, please input correct data");
					var textval = this.byId("PART_SIZE_10_VAL");
					textval.setValue("");
				}
			}
		},
		valInput_16: function() {
			var val = this.getView().byId("PART_SIZE_16_VAL").getValue();

			if (val !== '') {
				var oResult = this.isNumeric(val);
				if (!oResult) {
					sap.m.MessageBox.alert("Invalid Input: Particle size passing 16, please input correct data");
					var textval = this.byId("PART_SIZE_16_VAL");
					textval.setValue("");
				}
			}
		},
		valInput_IO: function() {
			var val = this.getView().byId("IODINE2_VAL").getValue();

			if (val !== '') {
				var oResult = this.isNumeric(val);
				if (!oResult) {
					sap.m.MessageBox.alert("Invalid Input: Iodine value, please input correct data");
					var textval = this.byId("IODINE2_VAL");
					textval.setValue("");
				}
			}
		},
		valInput_PR: function() {
			var val = this.getView().byId("PURITY_VAL").getValue();

			if (val !== '') {
				var oResult = this.isNumeric(val);
				if (!oResult) {
					sap.m.MessageBox.alert("Invalid Input: Purity value, please input correct data");
					var textval = this.byId("PURITY_VAL");
					textval.setValue("");
				}
			}
		},

		valInput_plant: function() {
			var val = this.getView().byId("PLANT_SPEED_VAL").getValue();
			if (val !== '') {
				var oResult = this.isNumeric(val);
				if (!oResult) {
					sap.m.MessageBox.alert("Invalid Input: Plant speed, please input correct data");
					var textval = this.byId("PLANT_SPEED_VAL");
					textval.setValue("");
				}
			}
		},
		valInput_iod: function() {
			var val = this.getView().byId("IODINE_FLOW_VAL").getValue();
			if (val !== '') {
				var oResult = this.isNumeric(val);
				if (!oResult) {
					sap.m.MessageBox.alert("Invalid Input: Iodine flow rate, please input correct data");
					var textval = this.byId("IODINE_FLOW_VAL");
					textval.setValue("");
				}
			}
		},
		onNavBack: function() {
			this.getOwnerComponent().getRouter().getTargets().display("object");
		}

	});

});