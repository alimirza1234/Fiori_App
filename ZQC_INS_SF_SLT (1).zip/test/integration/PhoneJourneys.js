jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
jQuery.sap.require("sap.ui.test.opaQunit");
jQuery.sap.require("sap.ui.test.Opa5");

jQuery.sap.require("znflbtl15.test.integration.pages.Common");
jQuery.sap.require("znflbtl15.test.integration.pages.App");
jQuery.sap.require("znflbtl15.test.integration.pages.Browser");
jQuery.sap.require("znflbtl15.test.integration.pages.Master");
jQuery.sap.require("znflbtl15.test.integration.pages.Detail");
jQuery.sap.require("znflbtl15.test.integration.pages.NotFound");

sap.ui.test.Opa5.extendConfig({
	arrangements: new znflbtl15.test.integration.pages.Common(),
	viewNamespace: "znflbtl15.view."
});

jQuery.sap.require("znflbtl15.test.integration.NavigationJourneyPhone");
jQuery.sap.require("znflbtl15.test.integration.NotFoundJourneyPhone");
jQuery.sap.require("znflbtl15.test.integration.BusyJourneyPhone");