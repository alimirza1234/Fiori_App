sap.ui.define([
	"zfiori/zmaterial_master/test/unit/controller/App.controller"
], function () {
	"use strict";
});