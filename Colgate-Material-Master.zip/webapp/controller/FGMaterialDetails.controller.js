sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"zfiori/zmaterial_master/utils/dataManagerLib",
	"sap/m/Button",
	"sap/m/Dialog",
	"sap/m/DialogType",
	"sap/m/Text",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/Fragment",
	"sap/ui/model/Filter",
	'sap/m/MessageToast'
], function (Controller, History, dataManagerLib, Button, Dialog, DialogType, Text, JSONModel, Fragment, Filter, MessageToast) {
	"use strict";

	return Controller.extend("zfiori.zmaterial_master.controller.FGMaterialDetails", {
		page: {
			Create: false,
			Approve: false
		},
		oFormID: null,
		pageSections: [],
		materialObj: {
			creationData: null,
			materialno: null,
			materialType: null,
			nationExport: null,
			baseUnitMeasure: "CAR",
			netWeight: 0.000,
			pm_pal: 0,
			no_Of_Carton: 1,
			no_Of_Pcs: 0,
			barCode_Sku: null,
			retailerMargin: 0.00,
			minRem: 0,
			mmFormNumber: null,
			materialText: null,
			materialGrp: null,
			// materialGrp2: null,
			// materialGrp5: null,
			mrpGrp: null,
			valuationtype: null,
			salesunit: "CAR",
			grossWeight: "0.000",
			pm_plr: 0,
			noofkg: 0,
			noofdz_bp_hg: 0,
			weightOfKg: "KG",
			distributorMargin: 0.00,
			total_self: 0.00,
			batch: true
		},
		serviceErrorDialog: null,
		serviceSuccessDialog: null,
		initData: {
			ERSDA: null, //creation date
			FORMNO: null, //form number
			MAKTX: null, // material description
			MATKL: null, //material group
			MATNR: null, //material number
			MEINS: null, //base unit of measure
			MTART: null, //material type
			NTGEW: "0.001", //Net Weight
			BRGEW: "0.001", //Gross Weight
			SPART: null, // national export
			XCHPF: null //Batch
		},
		SDVIEW: {
			AVAILABLITY_CHECK: null,
			CLASS_NAME: null,
			CLASS_TYPE: null,
			DIVISION: null,
			FORM_NO: null,
			GEN_ITEM_CAT_GRP: null,
			LOADING_GRP: null,
			MATERIAL_STATICS_GRP: null,
			PROD_HIER: null,
			STORAGE_CONDITION: null,
			TAX_VALUE_MWST: null,
			TAX_VALUE_ZFX1: null,
			TAX_VALUE_ZSED: null,
			TAX_VALUE_ZWHT: null,
			TRANS_GRP: null,
		},
		CMVIEW: {
			FORM_NO: null,
			MATL_GRP_1: null,
			MATL_GRP_2: null,
			MATL_GRP_5: null,
		},
		PURCHDATA: {},
		PPVIEWDATA: {
			COVPROFILE: null,
			FORM_NO: null,
			LOT_SIZE: null,
			MAX_STOCK_LEVEL: 0,
			MRP_CONTROLLER: null,
			MRP_DEP_REQ: null,
			MRP_GROUP: null,
			MRP_TYPE: null,
			PERIOD_IND: null,
			PROCUREMENT_TYPE: null,
			PRODPROFILE: null,
			PROD_SCHEDULER: null,
			PROD_ST_LOCATION: null,
			QUOTAUSAGE: null,
			REM_PROFILE_FG: null,
			REORDER_POINT: 0,
			REPEATATIVE_MANF: null,
			REP_MANUF_FG: null,
			SAFETYTIME: 0,
			SAFTY_T_ID: null,
			SELECTION_METHOD: null,
			SEL_METH_FG: null,
			SPPROCTYPE: null,
			STRATEGYGRP_FG: null,
		},
		QMVIEW: {
			INSPECTION_TYP: null,
			ACTIVE: null,
			PREFERRED_INSP_TYPE: null,
			FORM_NO: null
		},
		FIVIEWDATA: {
			VAL_CLASS: null,
			PRICE_CTRL: null,
			PRICE_UNIT: 0,
			VARIANCE_KEY: null,
			COST_LOT_SIZE: 0,
			HS_CODE: null,
			QTY_STRUCTURE: null,
			MATERIAL_ORIGIN: null,
			FORM_NO: null,
			CO_AREA_PC: null,
			PROFIT_CTR: null,
			VALIDFROM: "0000-00-00",
			VALIDTO: "0000-00-00",
			LONG_TEXT: null,
			PRCTR_NAME: null,
			PERS_RESPONSIBLE: null,
			DEPARTMENT_PC: null,
			PC_GROUP: null,
			COSTCENTER: null,
			DESCRIPTION: null,
			CCNAME: null,
			CO_AREA_CC: null,
			VALID_FROM: "0000-00-00",
			VALID_TO: "0000-00-00",
			PERSON_IN_CHARGE: null,
			DEPARTMENT_CC: null,
			COSTCENTER_TYPE: null,
			COSTCTR_HIER_GRP: null,
			PROFIT_CTR_CC: null

		},
		TopWorkitem: null,
		Workitem: null,
		StorageLocationRowId: {
			id: ""
		},
		SLOC: [],
		PLANTXYZ: [],
		footerBtn: {
			Submit: true,
			Approve: false,
			Reject: false
		},
		f4helps: {
			MaterialGroup: [],
			MaterialGroup1: [],
			MaterialGroup2: [],
			MaterialGroup5: [],
			PlantData: [],
			NationalExport: []
		},
		Approvers: [],

		onInit: function () {
			this.getOwnerComponent().getRouter().getRoute("FGMaterialDetails").attachMatched(this.onNavToCurrentPage, this);
		},

		onNavToCurrentPage: function (oEvent) {
			var that = this;
			var PlantGrid = this.getView().byId("PlantCheckB");
			PlantGrid.destroyContent();
			that.oFormID = oEvent.getParameter("arguments").formId;

			var footerModel = new JSONModel();
			var f4HelpsModel = new JSONModel();

			that.getView().setModel(f4HelpsModel, "f4helps");
			that.materialObj.creationData = new Date().toLocaleDateString();

			that.pageSections = [{
					View: "INITVIEW",
					Visible: false,
					Enable: false,
					OtherData: {},
					oModel: (function () {
						var dataModel = new JSONModel();
						that.getView().setModel(dataModel, "dataModel");
					})()
				}, {
					View: "CMVIEW",
					Visible: false,
					Enable: false,
					OtherData: {},
					oModel: (function () {
						var dataModel = new JSONModel();
						that.getView().setModel(dataModel, "CMVIEWModel");
					})()
				}, {
					View: "SDVIEW",
					Visible: false,
					Enable: false,
					OtherData: {},
					oModel: (function () {
						var dataModel = new JSONModel();
						that.getView().setModel(dataModel, "SDVIEWModel");
					})()
				},
				// {
				// 	View: "PURCHVIEW",
				// 	Visible: false,
				// 	Enable: false,
				// 	OtherData: {},
				// 	oModel: (function () {
				// 		var dataModel = new JSONModel();
				// 		that.getView().setModel(dataModel, "PURCHVIEWModel");
				// 	})()
				// },
				{
					View: "PPVIEW",
					Visible: false,
					Enable: false,
					OtherData: {},
					oModel: (function () {
						var dataModel = new JSONModel();
						that.getView().setModel(dataModel, "PPVIEWModel");
					})()
				}, {
					View: "QMVIEW",
					Visible: false,
					Enable: false,
					OtherData: {},
					oModel: (function () {
						var dataModel = new JSONModel();
						that.getView().setModel(dataModel, "QMVIEWModel");
					})()
				}, {
					View: "FIVIEW",
					Visible: false,
					Enable: false,
					OtherData: {},
					oModel: (function () {
						var dataModel = new JSONModel();
						that.getView().setModel(dataModel, "FIVIEWModel");
					})()
				}, {
					View: "PCVIEW",
					Visible: false,
					Enable: false,
					OtherData: {},
					oModel: (function () {
						var dataModel = new JSONModel();
						that.getView().setModel(dataModel, "PCVIEWModel");
					})()
				}, {
					View: "CCVIEW",
					Visible: false,
					Enable: false,
					OtherData: {},
					oModel: (function () {
						var dataModel = new JSONModel();
						that.getView().setModel(dataModel, "CCVIEWModel");
					})()
				}

			];
			//that.oFormID = "0000000217";
			if (that.oFormID) {
				that.page.Approve = true;
				that.page.Create = false;
				that.getView().byId("FGMatDet").setShowNavButton(false);
				that.footerBtn.Submit = false;
				that.footerBtn.Approve = true;
				that.footerBtn.Reject = true;
				footerModel.setData(that.footerBtn);
				var approverModel = new JSONModel();
				that.getView().setModel(approverModel, "ApproversModel");
				dataManagerLib.getFormData("01", that.oFormID, function (response) {
					debugger;
					if (response.results.length > 0) {
						response.results.forEach(function (obj) {
							if (obj.Key === "INITIALVIEWDATA") {
								that.initData = JSON.parse(obj.Value);
							}
							if (obj.Key === "MaterialGroup") {
								that.f4helps.MaterialGroup = JSON.parse(obj.Value);
							}
							if (obj.Key === "MaterialGroup") {
								that.f4helps.MaterialGroup1 = JSON.parse(obj.Value);
							}
							if (obj.Key === "MaterialGroup") {
								that.f4helps.MaterialGroup2 = JSON.parse(obj.Value);
							}
							if (obj.Key === "MaterialGroup") {
								that.f4helps.MaterialGroup5 = JSON.parse(obj.Value);
							}
							if (obj.Key === "NExport") {
								that.f4helps.NationalExport = JSON.parse(obj.Value);
							}
							if (obj.Key === "PLANTDATA") {
								that.f4helps.PlantData = JSON.parse(obj.Value);
							}
							if (obj.Key === "PurchasingGroup") {
								that.f4helps.PurchasingGroup = JSON.parse(obj.Value);
							}
							if (obj.Key === "Variancekey") {
								that.f4helps.Variancekey = JSON.parse(obj.Value);
							}
							if (obj.Key === "HSCode") {
								that.f4helps.HSCode = JSON.parse(obj.Value);
							}
							if (obj.Key === "SpecialPprocurementT") {
								that.f4helps.SpecialPprocurementT = JSON.parse(obj.Value);
							}
							if (obj.Key === "UnitofMeasurement") {
								that.f4helps.UnitofMeasurement = JSON.parse(obj.Value);
							}
							if (obj.Key === "PurchaseValueKey") {
								that.f4helps.PurchaseValueKey = JSON.parse(obj.Value);
							}
							if (obj.Key === "MrpTypes") {
								that.f4helps.MrpTypes = JSON.parse(obj.Value);
							}
							if (obj.Key === "PPStorageLocation") {
								that.f4helps.PPStorageLocation = JSON.parse(obj.Value);
							}
							if (obj.Key === "ProdSupervisor") {
								that.f4helps.ProdSupervisor = JSON.parse(obj.Value);
							}
							if (obj.Key === "MRP_group") {
								that.f4helps.MRP_GROUP = JSON.parse(obj.Value);
							}
							if (obj.Key === "MRPController") {
								that.f4helps.MRPController = JSON.parse(obj.Value);
							}
							if (obj.Key === "Lotsize") {
								that.f4helps.Lotsize = JSON.parse(obj.Value);
							}
							if (obj.Key === "SLOCDATA") {
								that.SLOC = JSON.parse(obj.Value);
							}
							if (obj.Key === "CMVIEWDATA") {
								that.CMVIEW = JSON.parse(obj.Value);
							}
							if (obj.Key === "SDVIEWDATA") {
								that.SDVIEW = JSON.parse(obj.Value);
							}
							if (obj.Key === "PURCHVIEWDATA") {
								that.PURCHDATA = JSON.parse(obj.Value);
							}
							if (obj.Key === "PPVIEWDATA") {
								that.PPVIEWDATA = JSON.parse(obj.Value);
							}
							if (obj.Key === "QMVIEWDATA") {
								that.QMVIEW = JSON.parse(obj.Value);
							}
							if (obj.Key === "FIVIEWDATA") {
								that.FIVIEWDATA = JSON.parse(obj.Value);
							}
							if (obj.Key === "Workitem") {
								that.Workitem = obj.Value;
							}
							if (obj.Key === "TopWorkitem") {
								that.TopWorkitem = obj.Value;
							}
							if (obj.Key === "approvers") {
								that.Approvers = JSON.parse(obj.Value);
							}
						});
						f4HelpsModel.setData(that.f4helps);
						f4HelpsModel.refresh();
						// that.createPlantBoxs(that.f4helps.PlantData, "A");
						that.materialObj = {
							//extra
							pm_pal: that.initData.PAL,
							pm_plr: that.initData.PLR,
							no_Of_Carton: that.initData.NO_KG,
							no_Of_Pcs: that.initData.PAC,
							barCode_Sku: that.initData.BARCODE,
							retailerMargin: that.initData.RETMARGIN,
							minRem: that.initData.MHDRZ,
							valuationtype: that.initData.BWTAR_D,
							salesunit: that.initData.VRKME,
							noofkg: that.initData.NO_KG,
							noofdz_bp_hg: that.initData.CARTONS,
							weightOfKg: that.initData.GEWEI,
							distributorMargin: that.initData.DISMARGIN,
							total_self: that.initData.MHDHB,
							mrpGrp: that.initData,
							materialType: that.initData.MTART,
							nationExport: that.initData.SPART,
							creationData: new Date(that.initData.ERSDA).toLocaleDateString(),
							mmFormNumber: that.initData.FORMNO,
							baseUnitMeasure: that.initData.MEINS,
							materialNo: that.initData.MATNR,
							materialGrp: that.initData.MATKL,
							netWeight: that.initData.NTGEW,
							grossWeight: that.initData.BRGEW,
							materialText: that.initData.MAKTX,
							batch: that.initData.XCHPF === "X" ? true : false
						};
						that.CMVIEW = {
							FORM_NO: that.initData.FORMNO,
							MATL_GRP_1: that.CMVIEW.MATL_GRP_1,
							MATL_GRP_2: that.CMVIEW.MATL_GRP_2,
							MATL_GRP_5: that.CMVIEW.MATL_GRP_5,
						};
						that.SDVIEW = {
							AVAILABLITY_CHECK: that.SDVIEW.AVAILABLITY_CHECK,
							CLASS_NAME: that.SDVIEW.CLASS_NAME,
							CLASS_TYPE: that.SDVIEW.CLASS_TYPE,
							DIVISION: that.SDVIEW.DIVISION,
							FORM_NO: that.initData.FORMNO,
							GEN_ITEM_CAT_GRP: that.SDVIEW.GEN_ITEM_CAT_GRP,
							LOADING_GRP: that.SDVIEW.LOADING_GRP,
							MATERIAL_STATICS_GRP: that.SDVIEW.MATERIAL_STATICS_GRP,
							PROD_HIER: that.SDVIEW.PROD_HIER,
							STORAGE_CONDITION: that.SDVIEW.STORAGE_CONDITION,
							TAX_VALUE_MWST: that.SDVIEW.TAX_VALUE_MWST,
							TAX_VALUE_ZFX1: that.SDVIEW.TAX_VALUE_ZFX1,
							TAX_VALUE_ZSED: that.SDVIEW.TAX_VALUE_ZSED,
							TAX_VALUE_ZWHT: that.SDVIEW.TAX_VALUE_ZWHT,
							TRANS_GRP: that.SDVIEW.TRANS_GRP
						};

						that.PPVIEWDATA = {
							COVPROFILE: that.PPVIEWDATA.COVPROFILE,
							FORM_NO: that.initData.FORMNO,
							LOT_SIZE: that.PPVIEWDATA.LOT_SIZE,
							MAX_STOCK_LEVEL: that.PPVIEWDATA.MAX_STOCK_LEVEL,
							MRP_CONTROLLER: that.PPVIEWDATA.MRP_CONTROLLER,
							MRP_DEP_REQ: that.PPVIEWDATA.MRP_DEP_REQ,
							MRP_GROUP: that.PPVIEWDATA.MRP_GROUP,
							MRP_TYPE: that.PPVIEWDATA.MRP_TYPE,
							PERIOD_IND: that.PPVIEWDATA.PERIOD_IND,
							PROCUREMENT_TYPE: that.PPVIEWDATA,
							PRODPROFILE: that.PPVIEWDATA.PRODPROFILE,
							PROD_SCHEDULER: that.PPVIEWDATA.PROD_SCHEDULER,
							PROD_ST_LOCATION: that.PPVIEWDATA,
							QUOTAUSAGE: that.PPVIEWDATA.QUOTAUSAGE,
							REM_PROFILE_FG: that.PPVIEWDATA.REM_PROFILE_FG,
							REORDER_POINT: that.PPVIEWDATA.REORDER_POINT,
							REPEATATIVE_MANF: that.PPVIEWDATA.REPEATATIVE_MANF,
							REP_MANUF_FG: that.PPVIEWDATA.REP_MANUF_FG,
							SAFETYTIME: that.PPVIEWDATA.SAFETYTIME,
							SAFTY_T_ID: that.PPVIEWDATA.SAFTY_T_ID,
							SELECTION_METHOD: that.PPVIEWDATA.SELECTION_METHOD,
							SEL_METH_FG: that.PPVIEWDATA.SEL_METH_FG,
							SPPROCTYPE: that.PPVIEWDATA.SPPROCTYPE,
							STRATEGYGRP_FG: that.PPVIEWDATA.STRATEGYGRP_FG
						};
						that.QMVIEW = {
							INSPECTION_TYPE: that.QMVIEW.INSPECTION_TYPE,
							ACTIVE: that.QMVIEW.ACTIVE,
							PREFERRED_INSP_TYPE: that.QMVIEW.PREFERRED_INSP_TYPE,
							FORM_NO: that.initData.FORMNO,
						};
						that.FIVIEWDATA = {
							VAL_CLASS: that.FIVIEWDATA.VAL_CLASS,
							PRICE_CTRL: that.FIVIEWDATA.PRICE_CTRL,
							PRICE_UNIT: that.FIVIEWDATA.PRICE_UNIT,
							VARIANCE_KEY: that.FIVIEWDATA.VARIANCE_KEY,
							COST_LOT_SIZE: that.FIVIEWDATA.COST_LOT_SIZE,
							HS_CODE: that.FIVIEWDATA.HS_CODE,
							QTY_STRUCTURE: that.FIVIEWDATA.QTY_STRUCTURE,
							MATERIAL_ORIGIN: that.FIVIEWDATA.MATERIAL_ORIGIN,
							FORM_NO: that.initData.FORMNO,
							CO_AREA_PC: that.FIVIEWDATA.CO_AREA_PC,
							PROFIT_CTR: that.FIVIEWDATA.PROFIT_CTR,
							VALIDFROM: that.FIVIEWDATA.VALIDFROM,
							VALIDTO: that.FIVIEWDATA.VALIDTO,
							LONG_TEXT: that.FIVIEWDATA.LONG_TEXT,
							PRCTR_NAME: that.FIVIEWDATA.PRCTR_NAME,
							PERS_RESPONSIBLE: that.FIVIEWDATA.PERS_RESPONSIBLE,
							DEPARTMENT_PC: that.FIVIEWDATA.DEPARTMENT_PC,
							PC_GROUP: that.FIVIEWDATA.PC_GROUP,
							COSTCENTER: that.FIVIEWDATA.COSTCENTER,
							DESCRIPTION: that.FIVIEWDATA.DESCRIPTION,
							CCNAME: that.FIVIEWDATA.CCNAME,
							CO_AREA_CC: that.FIVIEWDATA.CO_AREA_CC,
							VALID_FROM: that.FIVIEWDATA.VALID_FROM,
							VALID_TO: that.FIVIEWDATA.VALID_TO,
							PERSON_IN_CHARGE: that.FIVIEWDATA.PERSON_IN_CHARGE,
							DEPARTMENT_CC: that.FIVIEWDATA.DEPARTMENT_CC,
							COSTCENTER_TYPE: that.FIVIEWDATA.COSTCENTER_TYPE,
							COSTCTR_HIER_GRP: that.FIVIEWDATA.COSTCTR_HIER_GRP,
							PROFIT_CTR_CC: that.FIVIEWDATA.PROFIT_CTR_CC
						};
						that.enableViews(that.materialObj.materialType, function () {
							that.createPlantBoxs(that.f4helps.PlantData, "A");
							var isInitiator = false;
							pageSections.forEach(function (viewsObj) {
								if (viewsObj.View === "SDVIEW") {
									isInitiator = viewsObj.Enable;
								}
							});

							// that.SLOC.map(function (obj) {
							// 	obj.ACTION = "R";
							// });
							that.SLOC.forEach(function (slocObj) {
								if (slocObj.SLOCX === "X") {
									slocObj.isSelected = true;
								} else {
									slocObj.isSelected = false;
								}
								if (slocObj.ACTION === "E" && isInitiator) {
									slocObj.isEditable = true;
								} else {
									slocObj.isEditable = false;
								}
							});

							var SLOCModel = new JSONModel({
								Locations: that.SLOC
							});
							that.getView().setModel(SLOCModel, "SLoc");
							// that.enableViews(that.materialObj.materialType);
						});
						//For Init View
						var dataModel = that.getView().getModel("dataModel");
						dataModel.setData(that.materialObj);
						dataModel.refresh();

						//For CM View
						var dataModel = that.getView().getModel("CMVIEWModel");
						dataModel.setData(that.CMVIEW);
						dataModel.refresh();

						//For SD View
						var dataModel = that.getView().getModel("SDVIEWModel");
						dataModel.setData(that.SDVIEW);
						dataModel.refresh();

						//For Purchase View
						// var dataModel = that.getView().getModel("PURCHVIEWModel");
						// dataModel.setData(that.PURCHDATA);
						// dataModel.refresh();

						//For PP View
						var dataModel = that.getView().getModel("PPVIEWModel");
						dataModel.setData(that.PPVIEWDATA);
						dataModel.refresh();

						//For QM View
						var dataModel = that.getView().getModel("QMVIEWModel");
						dataModel.setData(that.QMVIEW);
						dataModel.refresh();

						//For FI View
						var dataModel = that.getView().getModel("FIVIEWModel");
						dataModel.setData(that.FIVIEWDATA);
						dataModel.refresh();

						//For Approvers
						var dataModel = that.getView().getModel("ApproversModel");
						dataModel.setData({
							Approvers: that.Approvers
						});
						dataModel.refresh();
					}
				}.bind(this), function (error) {
					if (!this.serviceErrorDialog) {
						this.serviceErrorDialog = new Dialog({
							title: "Error",
							type: "Message",
							state: "Error",
							content: new Text({
								text: "HTTP request failed."
							}),
							beginButton: new Button({
								text: "OK",
								press: function () {
									this.serviceErrorDialog.close();
								}.bind(this)
							})
						});
					}
					this.serviceErrorDialog.open();
				}.bind(this));
			} else {
				debugger;
				that.page.Create = true;
				that.page.Approve = false;
				that.getView().byId("FGMatDet").setShowNavButton(true);
				that.footerBtn.Submit = true;
				that.footerBtn.Approve = false;
				that.footerBtn.Reject = false;
				footerModel.setData(that.footerBtn);
				var selectedModel = this.getView().getParent().getModel("selectedModel");
				var selectedData = selectedModel.getData();
				if (selectedData.copyFromRadio.selected) {
					var matnr = selectedData.copyFromRadio.materialNumber;
					// var Mtart = selectedData.copyFromRadio.selectedMaterialType;
					dataManagerLib.FGcopyMatnr(matnr, function (response) {
						if (response.results.length > 0) {
							debugger;
							response.results.forEach(function (obj) {
								if (obj.Key === "INITVIEWHDRDATA") {
									that.initData = JSON.parse(obj.Value);
								}
								if (obj.Key === "MaterialGroup") {
									that.f4helps.MaterialGroup = JSON.parse(obj.Value);
								}
								if (obj.Key === "MaterialGroup") {
									that.f4helps.MaterialGroup1 = JSON.parse(obj.Value);
								}
								if (obj.Key === "MaterialGroup") {
									that.f4helps.MaterialGroup2 = JSON.parse(obj.Value);
								}
								if (obj.Key === "MaterialGroup") {
									that.f4helps.MaterialGroup5 = JSON.parse(obj.Value);
								}
								if (obj.Key === "NExport") {
									that.f4helps.NationalExport = JSON.parse(obj.Value);
								}
								if (obj.Key === "PlantData") {
									that.f4helps.PlantData = JSON.parse(obj.Value);
								}
								if (obj.Key === "PurchasingGroup") {
									that.f4helps.PurchasingGroup = JSON.parse(obj.Value);
								}
								if (obj.Key === "Variancekey") {
									that.f4helps.Variancekey = JSON.parse(obj.Value);
								}
								if (obj.Key === "HSCode") {
									that.f4helps.HSCode = JSON.parse(obj.Value);
								}
								if (obj.Key === "SpecialPprocurementT") {
									that.f4helps.SpecialPprocurementT = JSON.parse(obj.Value);
								}
								if (obj.Key === "UnitofMeasurement") {
									that.f4helps.UnitofMeasurement = JSON.parse(obj.Value);
								}
								if (obj.Key === "PurchaseValueKey") {
									that.f4helps.PurchaseValueKey = JSON.parse(obj.Value);
								}
								if (obj.Key === "MrpTypes") {
									that.f4helps.MrpTypes = JSON.parse(obj.Value);
								}
								if (obj.Key === "PPStorageLocation") {
									that.f4helps.PPStorageLocation = JSON.parse(obj.Value);
								}
								if (obj.Key === "ProdSupervisor") {
									that.f4helps.ProdSupervisor = JSON.parse(obj.Value);
								}
								if (obj.Key === "MRP_group") {
									that.f4helps.MRP_GROUP = JSON.parse(obj.Value);
								}
								if (obj.Key === "MRPController") {
									that.f4helps.MRPController = JSON.parse(obj.Value);
								}
								if (obj.Key === "Lotsize") {
									that.f4helps.Lotsize = JSON.parse(obj.Value);
								}
								if (obj.Key === "SLOCDATA") {
									that.SLOC = JSON.parse(obj.Value);
								}
								if (obj.Key === "CMVIEWDATA") {
									that.CMVIEW = JSON.parse(obj.Value);
								}
								if (obj.Key === "SDVIEWDATA") {
									that.SDVIEW = JSON.parse(obj.Value);
								}
								if (obj.Key === "PURCHVIEWDATA") {
									that.PURCHDATA = JSON.parse(obj.Value);
								}
								if (obj.Key === "PPVIEWDATA") {
									that.PPVIEWDATA = JSON.parse(obj.Value);
								}
								if (obj.Key === "QMVIEWDATA") {
									that.QMVIEW = JSON.parse(obj.Value);
								}
								if (obj.Key === "FIVIEWDATA") {
									that.FIVIEWDATA = JSON.parse(obj.Value);
								}
							});
						}
						that.createPlantBoxs(that.f4helps.PlantData, "C");
						f4HelpsModel.setData(that.f4helps);
						f4HelpsModel.refresh();

						var SLOCModel = new JSONModel({
							Locations: []
						});
						that.getView().setModel(SLOCModel, "SLoc");
						that.materialObj = {

							pm_pal: that.initData.PAL,
							pm_plr: that.initData.PLR,
							no_Of_Carton: that.initData.NO_KG,
							no_Of_Pcs: that.initData.PAC,
							barCode_Sku: that.initData.BARCODE,
							retailerMargin: that.initData.RETMARGIN,
							minRem: that.initData.MHDRZ,

							valuationtype: that.initData.BWTAR_D,

							salesunit: that.initData.VRKME,

							noofkg: that.initData.NO_KG,
							noofdz_bp_hg: that.initData.CARTONS,

							weightOfKg: that.initData.GEWEI,

							distributorMargin: that.initData.DISMARGIN,
							total_self: that.initData.MHDHB,

							materialType: that.initData.MTART,
							nationExport: that.initData.SPART,
							creationData: new Date(that.initData.ERSDA).toLocaleDateString(),
							mmFormNumber: that.initData.FORMNO,
							baseUnitMeasure: that.initData.MEINS,
							materialNo: that.initData.MATNR,
							materialGrp: that.initData.MATKL,
							netWeight: that.initData.NTGEW,
							grossWeight: that.initData.BRGEW,
							materialText: that.initData.MAKTX,
							batch: that.initData.XCHPF === "X" ? true : false
						};
						that.enableViews(that.materialObj.materialType);
						if (that.page.Create) {
							//Check to enable values in specific material type.
							if (that.materialObj.materialType === "ZPOP" || that.materialObj.materialType === "ZGFN" || that.materialObj.materialType ===
								"ZGFT") {
								//nation export (98 and enable)
								that.getView().byId("NEInput").setEnabled(true);
								//Material number disable
								that.getView().byId("MaterialNum").setEnabled(false);
							}
							if (that.materialObj.materialType === "ZRAW" || that.materialObj.materialType === "ZSFG") {
								//nation export (98 and disable)
								that.getView().byId("NEInput").setEnabled(false);
								//Material number enable
								that.getView().byId("MaterialNum").setEnabled(true);
							}
							if (that.materialObj.materialType === "ZPKG" || that.materialObj.materialType === "ZSPR") {
								//nation export (98 and disable)
								that.getView().byId("NEInput").setEnabled(false);
								//Material number enable
								that.getView().byId("MaterialNum").setEnabled(true);
							}
						}

						//For Init View
						var dataModel = that.getView().getModel("dataModel");
						dataModel.setData(that.materialObj);
						dataModel.refresh();

						//For CM View
						var dataModel = that.getView().getModel("CMVIEWModel");
						dataModel.setData(that.CMVIEW);
						dataModel.refresh();

						//For SD View
						var dataModel = that.getView().getModel("SDVIEWModel");
						dataModel.setData(that.SDVIEW);
						dataModel.refresh();

						//For Purchase View
						// var dataModel = that.getView().getModel("PURCHVIEWModel");
						// dataModel.setData(that.PURCHDATA);
						// dataModel.refresh();

						//For PP View
						var dataModel = that.getView().getModel("PPVIEWModel");
						dataModel.setData(that.PPVIEWDATA);
						dataModel.refresh();

						//For QM View
						var dataModel = that.getView().getModel("QMVIEWModel");
						dataModel.setData(that.QMVIEW);
						dataModel.refresh();

						//For FI View
						var dataModel = that.getView().getModel("FIVIEWModel");
						dataModel.setData(that.FIVIEWDATA);
						dataModel.refresh();

					}.bind(this), function (error) {
						if (!this.serviceErrorDialog) {
							this.serviceErrorDialog = new Dialog({
								title: "Error",
								type: "Message",
								state: "Error",
								content: new Text({
									text: "HTTP request failed."
								}),
								beginButton: new Button({
									text: "OK",
									press: function () {
										this.serviceErrorDialog.close();
									}.bind(this)
								})
							});
						}
						this.serviceErrorDialog.open();
					}.bind(this));
				} else {
					that.materialObj.materialType = selectedData.materialTypeRadio.materialType;

					dataManagerLib.FGinitMatnr(that.materialObj.materialType, function (response) {
							if (response.results.length > 0) {
								response.results.forEach(function (obj) {
									if (obj.Key === "INITVIEWHDRDATA") {
										that.initData = JSON.parse(obj.Value);
									}
									if (obj.Key === "MaterialGroup") {
										that.f4helps.MaterialGroup = JSON.parse(obj.Value);
									}
									if (obj.Key === "MaterialGroup") {
										that.f4helps.MaterialGroup1 = JSON.parse(obj.Value);
									}
									if (obj.Key === "MaterialGroup") {
										that.f4helps.MaterialGroup2 = JSON.parse(obj.Value);
									}
									if (obj.Key === "MaterialGroup") {
										that.f4helps.MaterialGroup5 = JSON.parse(obj.Value);
									}
									if (obj.Key === "NExport") {
										that.f4helps.NationalExport = JSON.parse(obj.Value);
									}
									if (obj.Key === "PlantData") {
										that.f4helps.PlantData = JSON.parse(obj.Value);
									}
									if (obj.Key === "PurchasingGroup") {
										that.f4helps.PurchasingGroup = JSON.parse(obj.Value);
									}
									if (obj.Key === "Variancekey") {
										that.f4helps.Variancekey = JSON.parse(obj.Value);
									}
									if (obj.Key === "HSCode") {
										that.f4helps.HSCode = JSON.parse(obj.Value);
									}
									if (obj.Key === "SpecialPprocurementT") {
										that.f4helps.SpecialPprocurementT = JSON.parse(obj.Value);
									}
									if (obj.Key === "UnitofMeasurement") {
										that.f4helps.UnitofMeasurement = JSON.parse(obj.Value);
									}
									if (obj.Key === "PurchaseValueKey") {
										that.f4helps.PurchaseValueKey = JSON.parse(obj.Value);
									}
									if (obj.Key === "MrpTypes") {
										that.f4helps.MrpTypes = JSON.parse(obj.Value);
									}
									if (obj.Key === "PPStorageLocation") {
										that.f4helps.PPStorageLocation = JSON.parse(obj.Value);
									}
									if (obj.Key === "ProdSupervisor") {
										that.f4helps.ProdSupervisor = JSON.parse(obj.Value);
									}
									if (obj.Key === "MRP_group") {
										that.f4helps.MRP_GROUP = JSON.parse(obj.Value);
									}
									if (obj.Key === "MRPController") {
										that.f4helps.MRPController = JSON.parse(obj.Value);
									}
									if (obj.Key === "Lotsize") {
										that.f4helps.Lotsize = JSON.parse(obj.Value);
									}
									if (obj.Key === "SLOCDATA") {
										that.SLOC = JSON.parse(obj.Value);
									}
									if (obj.Key === "CMVIEWDATA") {
										that.CMVIEW = JSON.parse(obj.Value);
									}
									if (obj.Key === "SDVIEWDATA") {
										that.SDVIEW = JSON.parse(obj.Value);
									}
									if (obj.Key === "PURCHVIEWDATA") {
										that.PURCHDATA = JSON.parse(obj.Value);
									}
									if (obj.Key === "PPVIEWDATA") {
										that.PPVIEWDATA = JSON.parse(obj.Value);
									}
									if (obj.Key === "QMVIEWDATA") {
										that.QMVIEW = JSON.parse(obj.Value);
									}
									if (obj.Key === "FIVIEWDATA") {
										that.FIVIEWDATA = JSON.parse(obj.Value);
									}

								});
							}
							that.enableViews(that.materialObj.materialType);
							that.createPlantBoxs(that.f4helps.PlantData, "C");
							f4HelpsModel.setData(that.f4helps);
							f4HelpsModel.refresh();

							var SLOCModel = new JSONModel({
								Locations: []
							});
							that.getView().setModel(SLOCModel, "SLoc");

							if (that.page.Create) {
								//Check to enable values in specific material type.
								if (that.materialObj.materialType === "ZPOP" || that.materialObj.materialType === "ZGFN" || that.materialObj.materialType ===
									"ZGFT") {
									//Batch true
									that.materialObj.batch = true;
									//nation export (98 and enable)
									that.materialObj.nationExport = "98";
									that.getView().byId("NEInput").setEnabled(true);
									//Material number disable
									that.getView().byId("MaterialNum").setEnabled(false);
								}
								if (that.materialObj.materialType === "ZRAW" || that.materialObj.materialType === "ZSFG") {
									//Batch true
									that.materialObj.batch = true;
									//nation export (98 and disable)
									that.materialObj.nationExport = "98";
									that.getView().byId("NEInput").setEnabled(false);
									//Material number enable
									that.getView().byId("MaterialNum").setEnabled(true);
								}
								if (that.materialObj.materialType === "ZPKG" || that.materialObj.materialType === "ZSPR") {
									//Batch false
									that.materialObj.batch = false;
									//nation export (98 and disable)
									that.materialObj.nationExport = "98";
									that.getView().byId("NEInput").setEnabled(false);
									//Material number enable
									that.getView().byId("MaterialNum").setEnabled(true);
								}
							}
							that.materialObj.creationData = new Date().toLocaleDateString();
							that.materialObj.mmFormNumber = null;
							that.materialObj.baseUnitMeasure = "EA";
							that.materialObj.materialNo = null;
							that.materialObj.materialGrp = null;
							that.materialObj.netWeight = "0.000";
							that.materialObj.grossWeight = "0.000";
							that.materialObj.materialText = null;

							//For Init View
							var dataModel = that.getView().getModel("dataModel");
							dataModel.setData(that.materialObj);
							dataModel.refresh();

							//For CM View
							var dataModel = that.getView().getModel("CMVIEWModel");
							dataModel.setData(that.CMVIEW);
							dataModel.refresh();

							//For SD View
							var dataModel = that.getView().getModel("SDVIEWModel");
							dataModel.setData(that.SDVIEW);
							dataModel.refresh();

							//For Purchase View
							// var dataModel = that.getView().getModel("PURCHVIEWModel");
							// dataModel.setData(that.PURCHDATA);
							// dataModel.refresh();

							//For PP View
							var dataModel = that.getView().getModel("PPVIEWModel");
							dataModel.setData(that.PPVIEWDATA);
							dataModel.refresh();

							//For QM View
							var dataModel = that.getView().getModel("QMVIEWModel");
							dataModel.setData(that.QMVIEW);
							dataModel.refresh();

							//For FI View
							var dataModel = that.getView().getModel("FIVIEWModel");
							dataModel.setData(that.FIVIEWDATA);
							dataModel.refresh();

						}.bind(this),
						function (error) {
							if (!this.serviceErrorDialog) {
								this.serviceErrorDialog = new Dialog({
									title: "Error",
									type: "Message",
									state: "Error",
									content: new Text({
										text: "HTTP request failed."
									}),
									beginButton: new Button({
										text: "OK",
										press: function () {
											this.serviceErrorDialog.close();
										}.bind(this)
									})
								});
							}
							this.serviceErrorDialog.open();
						}.bind(this));
				}
			}
			that.getView().setModel(footerModel, "footerModel");
		},

		handleValueHelpFGMG: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();

			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._valueHelpDialogFGMG) {
				this._valueHelpDialogFGMG = sap.ui.xmlfragment(
					"zfiori.zmaterial_master.fragments.FGMaterialGroup",
					this
				);
				this.getView().addDependent(this._valueHelpDialogFGMG);
			}

			// create a filter for the binding
			this._valueHelpDialogFGMG.getBinding("items").filter([new Filter(
				"MATKL",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);

			// open value help dialog filtered by the input value
			this._valueHelpDialogFGMG.open(sInputValue);
		},

		_handleValueHelpSearchFGMG: function (evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter(
				"MATKL",
				sap.ui.model.FilterOperator.Contains, sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},

		_handleValueHelpCloseFGMG: function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
		},

		handleValueHelpPGRP: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();

			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._valueHelpDialogPGRP) {
				this._valueHelpDialogPGRP = sap.ui.xmlfragment(
					"zfiori.zmaterial_master.fragments.PurchasingGroup",
					this
				);
				this.getView().addDependent(this._valueHelpDialogPGRP);
			}

			// create a filter for the binding
			this._valueHelpDialogPGRP.getBinding("items").filter([new Filter(
				"EKGRP",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);

			// open value help dialog filtered by the input value
			this._valueHelpDialogPGRP.open(sInputValue);
		},

		_handleValueHelpSearchPGRP: function (evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter(
				"EKGRP",
				sap.ui.model.FilterOperator.Contains, sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},

		_handleValueHelpClosePGRP: function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
		},

		handleValueHelpFGNE: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();

			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._valueHelpDialogFGNE) {
				this._valueHelpDialogFGNE = sap.ui.xmlfragment(
					"zfiori.zmaterial_master.fragments.FGNationalExport",
					this
				);
				this.getView().addDependent(this._valueHelpDialogFGNE);
			}

			// create a filter for the binding
			this._valueHelpDialogFGNE.getBinding("items").filter([new Filter(
				"VTWEG",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);

			// open value help dialog filtered by the input value
			this._valueHelpDialogFGNE.open(sInputValue);
		},

		_handleValueHelpSearchFGNE: function (evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter(
				"VTWEG",
				sap.ui.model.FilterOperator.Contains, sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},

		_handleValueHelpCloseFGNE: function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
		},

		handleValueHelFGPPMRP: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();

			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._valueHelpDialogFGPPMRP) {
				this._valueHelpDialogFGPPMRP = sap.ui.xmlfragment(
					"zfiori.zmaterial_master.fragments.FGPPMRP",
					this
				);
				this.getView().addDependent(this._valueHelpDialogFGPPMRP);
			}

			// create a filter for the binding
			this._valueHelpDialogFGPPMRP.getBinding("items").filter([new Filter(
				"DISPO",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);

			// open value help dialog filtered by the input value
			this._valueHelpDialogFGPPMRP.open(sInputValue);
		},
		_handleValueHelpSearchFGPPMRP: function (evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter(
				"DISPO",
				sap.ui.model.FilterOperator.Contains, sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},
		_handleValueHelpCloseFGPPMRP: function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
		},

		handleValueHelFGPPMRPG: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();
			//debugger;
			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._valueHelpDialogFGPPMRPG) {
				this._valueHelpDialogFGPPMRPG = sap.ui.xmlfragment(
					"zfiori.zmaterial_master.fragments.FGPPMRPG",
					this
				);
				this.getView().addDependent(this._valueHelpDialogFGPPMRPG);
			}

			// create a filter for the binding
			this._valueHelpDialogFGPPMRPG.getBinding("items").filter([new Filter(
				"DISGR",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);

			// open value help dialog filtered by the input value
			this._valueHelpDialogFGPPMRPG.open(sInputValue);
		},
		_handleValueHelpSearchFGPPMRPG: function (evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter(
				"DISGR",
				sap.ui.model.FilterOperator.Contains, sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},
		_handleValueHelpCloseFGPPMRPG: function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
		},

		handleValueHelpFGPPPSL: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();

			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._valueHelpDialogFGPPPSL) {
				this._valueHelpDialogFGPPPSL = sap.ui.xmlfragment(
					"zfiori.zmaterial_master.fragments.FGPPProductionStorageloc",
					this
				);
				this.getView().addDependent(this._valueHelpDialogFGPPPSL);
			}

			// create a filter for the binding
			this._valueHelpDialogFGPPPSL.getBinding("items").filter([new Filter(
				"LGOBE",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);

			// open value help dialog filtered by the input value
			this._valueHelpDialogFGPPPSL.open(sInputValue);
		},
		_handleValueHelpSearchFGPPPSL: function (evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter(
				"LGOBE",
				sap.ui.model.FilterOperator.Contains, sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},
		_handleValueHelpCloseFGPPPSL: function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
		},

		handleValueHelpFGPPPS: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();

			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._valueHelpDialogFGPPPS) {
				this._valueHelpDialogFGPPPS = sap.ui.xmlfragment(
					"zfiori.zmaterial_master.fragments.FGPPProductionScheduler",
					this
				);
				this.getView().addDependent(this._valueHelpDialogFGPPPS);
			}

			// create a filter for the binding
			this._valueHelpDialogFGPPPS.getBinding("items").filter([new Filter(
				"FEVOR",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);

			// open value help dialog filtered by the input value
			this._valueHelpDialogFGPPPS.open(sInputValue);
		},
		_handleValueHelpSearchFGPPPS: function (evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter(
				"FEVOR",
				sap.ui.model.FilterOperator.Contains, sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},
		_handleValueHelpCloseFGPPPS: function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
		},

		handleValueHelpFGCM1: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();

			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._valueHelpDialogFGCM1) {
				this._valueHelpDialogFGCM1 = sap.ui.xmlfragment(
					"zfiori.zmaterial_master.fragments.FGCM1",
					this
				);
				this.getView().addDependent(this._valueHelpDialogFGCM1);
			}

			// create a filter for the binding
			this._valueHelpDialogFGCM1.getBinding("items").filter([new Filter(
				"MATKL",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);

			// open value help dialog filtered by the input value
			this._valueHelpDialogFGCM1.open(sInputValue);
		},

		_handleValueHelpSearchFGCM1: function (evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter(
				"MATKL",
				sap.ui.model.FilterOperator.Contains, sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},

		_handleValueHelpCloseFGCM1: function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
		},

		handleValueHelpFGCM2: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();

			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._valueHelpDialogFGCM2) {
				this._valueHelpDialogFGCM2 = sap.ui.xmlfragment(
					"zfiori.zmaterial_master.fragments.FGCM2",
					this
				);
				this.getView().addDependent(this._valueHelpDialogFGCM2);
			}

			// create a filter for the binding
			this._valueHelpDialogFGCM2.getBinding("items").filter([new Filter(
				"MATKL",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);

			// open value help dialog filtered by the input value
			this._valueHelpDialogFGCM2.open(sInputValue);
		},

		_handleValueHelpSearchFGCM2: function (evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter(
				"MATKL",
				sap.ui.model.FilterOperator.Contains, sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},

		_handleValueHelpCloseFGCM2: function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
		},

		handleValueHelpFGCM3: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();

			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._valueHelpDialogFGCM3) {
				this._valueHelpDialogFGCM3 = sap.ui.xmlfragment(
					"zfiori.zmaterial_master.fragments.FGCM3",
					this
				);
				this.getView().addDependent(this._valueHelpDialogFGCM3);
			}

			// create a filter for the binding
			this._valueHelpDialogFGCM3.getBinding("items").filter([new Filter(
				"MATKL",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);

			// open value help dialog filtered by the input value
			this._valueHelpDialogFGCM3.open(sInputValue);
		},

		_handleValueHelpSearchFGCM3: function (evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter(
				"MATKL",
				sap.ui.model.FilterOperator.Contains, sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},

		_handleValueHelpCloseFGCM3: function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
		},

		handleValueHelpFGDIV: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();

			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._valueHelpDialogFGDIV) {
				this._valueHelpDialogFGDIV = sap.ui.xmlfragment(
					"zfiori.zmaterial_master.fragments.FGDivision",
					this
				);
				this.getView().addDependent(this._valueHelpDialogFGDIV);
			}

			// create a filter for the binding
			this._valueHelpDialogFGDIV.getBinding("items").filter([new Filter(
				"DISMM",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);

			// open value help dialog filtered by the input value
			this._valueHelpDialogFGDIV.open(sInputValue);
		},
		_handleValueHelpSearchFGDIV: function (evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter(
				"DISMM",
				sap.ui.model.FilterOperator.Contains, sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},
		_handleValueHelpCloseFGDIV: function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
		},

		handleValueHelpFGPH: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();

			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._valueHelpDialogFGPH) {
				this._valueHelpDialogFGPH = sap.ui.xmlfragment(
					"zfiori.zmaterial_master.fragments.FGProdH",
					this
				);
				this.getView().addDependent(this._valueHelpDialogFGPH);
			}

			// create a filter for the binding
			this._valueHelpDialogFGPH.getBinding("items").filter([new Filter(
				"DISMM",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);

			// open value help dialog filtered by the input value
			this._valueHelpDialogFGPH.open(sInputValue);
		},
		_handleValueHelpSearchFGPH: function (evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter(
				"DISMM",
				sap.ui.model.FilterOperator.Contains, sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},
		_handleValueHelpCloseFGPH: function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
		},

		handleValueHelpFGT: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();

			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._valueHelpDialogFGT) {
				this._valueHelpDialogFGT = sap.ui.xmlfragment(
					"zfiori.zmaterial_master.fragments.FGType",
					this
				);
				this.getView().addDependent(this._valueHelpDialogFGT);
			}

			// create a filter for the binding
			this._valueHelpDialogFGT.getBinding("items").filter([new Filter(
				"DISMM",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);

			// open value help dialog filtered by the input value
			this._valueHelpDialogFGT.open(sInputValue);
		},
		_handleValueHelpSearchFGT: function (evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter(
				"DISMM",
				sap.ui.model.FilterOperator.Contains, sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},
		_handleValueHelpCloseFGT: function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
		},

		handleValueHelpFGPPLS: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();

			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._valueHelpDialogFGPPLS) {
				this._valueHelpDialogFGPPLS = sap.ui.xmlfragment(
					"zfiori.zmaterial_master.fragments.FGPPLotSize",
					this
				);
				this.getView().addDependent(this._valueHelpDialogFGPPLS);
			}

			// create a filter for the binding
			this._valueHelpDialogFGPPLS.getBinding("items").filter([new Filter(
				"DISLS",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);

			// open value help dialog filtered by the input value
			this._valueHelpDialogFGPPLS.open(sInputValue);
		},
		_handleValueHelpSearchFGPPLS: function (evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter(
				"DISLS",
				sap.ui.model.FilterOperator.Contains, sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},
		_handleValueHelpCloseFGPPLS: function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
		},

		handleValueHelpFGPT: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();

			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._valueHelpDialogFGPT) {
				this._valueHelpDialogFGPT = sap.ui.xmlfragment(
					"zfiori.zmaterial_master.fragments.FGProcurementType",
					this
				);
				this.getView().addDependent(this._valueHelpDialogFGPT);
			}

			// create a filter for the binding
			this._valueHelpDialogFGPT.getBinding("items").filter([new Filter(
				"SOBSL",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);

			// open value help dialog filtered by the input value
			this._valueHelpDialogFGPT.open(sInputValue);
		},
		_handleValueHelpSearchFGPT: function (evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter(
				"SOBSL",
				sap.ui.model.FilterOperator.Contains, sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},
		_handleValueHelpCloseFGPT: function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
		},

		handleValueHelpFGSC: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();

			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._valueHelpDialogFGSC) {
				this._valueHelpDialogFGSC = sap.ui.xmlfragment(
					"zfiori.zmaterial_master.fragments.FGSDSelectCare",
					this
				);
				this.getView().addDependent(this._valueHelpDialogFGSC);
			}

			// create a filter for the binding
			this._valueHelpDialogFGSC.getBinding("items").filter([new Filter(
				"MSEHI",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);

			// open value help dialog filtered by the input value
			this._valueHelpDialogFGSC.open(sInputValue);
		},
		_handleValueHelpSearchFGSC: function (evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter(
				"MSEHI",
				sap.ui.model.FilterOperator.Contains, sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},
		_handleValueHelpCloseFGSC: function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
		},

		handleValueHelpFGPH: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();

			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._valueHelpDialogFGPH) {
				this._valueHelpDialogFGPH = sap.ui.xmlfragment(
					"zfiori.zmaterial_master.fragments.FGProdH",
					this
				);
				this.getView().addDependent(this._valueHelpDialogFGPH);
			}

			// create a filter for the binding
			this._valueHelpDialogFGPH.getBinding("items").filter([new Filter(
				"EKWSL",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);

			// open value help dialog filtered by the input value
			this._valueHelpDialogFGPH.open(sInputValue);
		},
		_handleValueHelpSearchFGPH: function (evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter(
				"EKWSL",
				sap.ui.model.FilterOperator.Contains, sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},
		_handleValueHelpCloseFGPH: function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
		},

		handleValueHelpBUVK: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();

			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._valueHelpDialogBUVK) {
				this._valueHelpDialogBUVK = sap.ui.xmlfragment(
					"zfiori.zmaterial_master.fragments.BUVarianceKey",
					this
				);
				this.getView().addDependent(this._valueHelpDialogBUVK);
			}

			// create a filter for the binding
			this._valueHelpDialogBUVK.getBinding("items").filter([new Filter(
				"AWSLS",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);

			// open value help dialog filtered by the input value
			this._valueHelpDialogBUVK.open(sInputValue);
		},
		_handleValueHelpSearchBUVK: function (evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter(
				"AWSLS",
				sap.ui.model.FilterOperator.Contains, sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},
		_handleValueHelpCloseBUVK: function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
		},

		handleValueHelpFGDR: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();

			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._valueHelpDialogFGDR) {
				this._valueHelpDialogFGDR = sap.ui.xmlfragment(
					"zfiori.zmaterial_master.fragments.FGPPDepartReq",
					this
				);
				this.getView().addDependent(this._valueHelpDialogFGDR);
			}

			// create a filter for the binding
			this._valueHelpDialogFGDR.getBinding("items").filter([new Filter(
				"STAWN",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);

			// open value help dialog filtered by the input value
			this._valueHelpDialogFGDR.open(sInputValue);
		},
		_handleValueHelpSearchFGDR: function (evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter(
				"STAWN",
				sap.ui.model.FilterOperator.Contains, sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},
		_handleValueHelpCloseFGDR: function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
		},

		handleValueHelpFGPPMRPTYPE: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();

			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._valueHelpDialogFGPPMRPTYPE) {
				this._valueHelpDialogFGPPMRPTYPE = sap.ui.xmlfragment(
					"zfiori.zmaterial_master.fragments.FGPPMrpType",
					this
				);
				this.getView().addDependent(this._valueHelpDialogFGPPMRPTYPE);
			}

			// create a filter for the binding
			this._valueHelpDialogFGPPMRPTYPE.getBinding("items").filter([new Filter(
				"DIBEZ",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);

			// open value help dialog filtered by the input value
			this._valueHelpDialogFGPPMRPTYPE.open(sInputValue);
		},
		_handleValueHelpSearchFGPPMRPTYPE: function (evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter(
				"DIBEZ",
				sap.ui.model.FilterOperator.Contains, sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},
		_handleValueHelpCloseFGPPMRPTYPE: function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
		},

		handleValueHelpFGSPTYPE: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();

			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._valueHelpDialogFGSPT) {
				this._valueHelpDialogFGSPT = sap.ui.xmlfragment(
					"zfiori.zmaterial_master.fragments.FGspecialpretype",
					this
				);
				this.getView().addDependent(this._valueHelpDialogFGSPT);
			}

			// create a filter for the binding
			this._valueHelpDialogFGSPT.getBinding("items").filter([new Filter(
				"SOBSL",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);

			// open value help dialog filtered by the input value
			this._valueHelpDialogFGSPT.open(sInputValue);
		},
		_handleValueHelpSearchFGSPT: function (evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter(
				"SOBSL",
				sap.ui.model.FilterOperator.Contains, sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},
		_handleValueHelpCloseFGSPT: function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
		},

		handleValueHelpFGHC: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();

			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._valueHelpDialogFGHC) {
				this._valueHelpDialogFGHC = sap.ui.xmlfragment(
					"zfiori.zmaterial_master.fragments.FGHSCode",
					this
				);
				this.getView().addDependent(this._valueHelpDialogFGHC);
			}

			// create a filter for the binding
			this._valueHelpDialogFGHC.getBinding("items").filter([new Filter(
				"STAWN",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);

			// open value help dialog filtered by the input value
			this._valueHelpDialogFGHC.open(sInputValue);
		},
		_handleValueHelpSearchFGHC: function (evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter(
				"STAWN",
				sap.ui.model.FilterOperator.Contains, sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},
		_handleValueHelpCloseFGHC: function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
		},

		createPlantBoxs: function (plants, View) {
			debugger;
			var PlantGrid = this.getView().byId("PlantCheckB");
			var allNewPlants = [];

			//new logic
			var isInitiator = false;
			this.pageSections.forEach(function (viewsObj) {
				if (viewsObj.View === "SDVIEW") {
					isInitiator = viewsObj.Enable;
				}
			});
			plants.forEach(function (oPlant) {
				var isEditable = null;
				if (oPlant.ACTION === "E" && isInitiator) {
					isEditable = true;
				} else {
					isEditable = false;
				}
				var isSelected = null;
				if (oPlant.PLANTX === "X") {
					isSelected = true;
				} else {
					isSelected = false;
				}
				allNewPlants.push(new sap.m.CheckBox(oPlant.WERKS, {
					enabled: isEditable,
					selected: isSelected,
					text: oPlant.WERKS
				}));
			});
			// old logic
			// plants.forEach(function (oPlant) {
			// 	allNewPlants.push(new sap.m.CheckBox(oPlant.WERKS, {
			// 		enabled: View === "A" ? (oPlant.ACTION === "E" ? true : false) : false,
			// 		selected: oPlant.ACTION === "R" || oPlant.PLANTX === "X" ? true : false,
			// 		text: oPlant.WERKS
			// 	}));
			// });

			allNewPlants.forEach(function (obj) {
				PlantGrid.addContent(obj);
			});

		},

		onFGSLOCSync: function (oEvent) {
			var that = this;
			var currentData = this.getView().getModel("dataModel").getData();
			if (this.f4helps.PlantData.length > 0) {
				this.f4helps.PlantData.forEach(function (plantObj) {
					plantObj.PLANTX = sap.ui.getCore().byId(plantObj.WERKS).getSelected() === true ? "X" : "";
				});
			}
			var plantJSON = JSON.stringify(this.f4helps.PlantData);
			dataManagerLib.FGfetchSLOC(currentData.materialType, currentData.materialGrp, plantJSON, function (response) {
				that.SLOC = JSON.parse(response.Value);
				that.SLOC.forEach(function (slocObj) {
					if (slocObj.SLOCX === "X") {
						slocObj.isSelected = true;
					} else {
						slocObj.isSelected = false;
					}
					if (slocObj.ACTION === "E") {
						slocObj.isEditable = true;
					} else {
						slocObj.isEditable = false;
					}
				});
				//console.log(that.SLOC);
				var SLOCModel = new JSONModel({
					Locations: that.SLOC
				});
				that.getView().setModel(SLOCModel, "SLoc");
			}.bind(this), function (error) {
				if (!this.serviceErrorDialog) {
					this.serviceErrorDialog = new Dialog({
						title: "Error",
						type: "Message",
						state: "Error",
						content: new Text({
							text: "HTTP request failed."
						}),
						beginButton: new Button({
							text: "OK",
							press: function () {
								this.serviceErrorDialog.close();
							}.bind(this)
						})
					});
				}
				this.serviceErrorDialog.open();
			}.bind(this));
		},

		onNavBack: function (oEvent) {
			var oHistory, sPreviousHash;
			oHistory = History.getInstance();
			sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				this.getOwnerComponent().getRouter().navTo("MaterialType", {}, true /*no history*/ );
			}
		},

		enableViews: function (Mtart) {
			var that = this;
			var viewsModel = new JSONModel();
			viewsModel.setData({
				pageSections: that.pageSections
			});
			that.getView().setModel(viewsModel, "isEnabledModel");
			dataManagerLib.getViews("01", that.page, Mtart, that.oFormID, function (response) {
				if (response.results.length > 0) {
					var ViewsCanEdit = [];
					response.results.forEach(function (obj) {
						if (obj.Key === "Views") {
							ViewsCanEdit = JSON.parse(obj.Value);
						}
					});

					ViewsCanEdit.forEach(function (objAPIView) {
						that.pageSections.forEach(function (objAppView) {
							// objAppView.Visible = true;
							// objAppView.Enable = true;
							if (objAppView.View === objAPIView.VIEWID) {
								objAppView.Visible = true;
								objAppView.Enable = objAPIView.EDITABLE === "X" ? true : false;
								objAppView.OtherData = objAPIView;
							}
						});
					});
					var isEnabledModel = that.getView().getModel("isEnabledModel");
					isEnabledModel.setData({
						pageSections: that.pageSections
					});
					isEnabledModel.refresh();
				}
			}.bind(this), function (error) {
				if (!this.serviceErrorDialog) {
					this.serviceErrorDialog = new Dialog({
						title: "Error",
						type: "Message",
						state: "Error",
						content: new Text({
							text: "HTTP request failed."
						}),
						beginButton: new Button({
							text: "OK",
							press: function () {
								this.serviceErrorDialog.close();
							}.bind(this)
						})
					});
				}
				this.serviceErrorDialog.open();
			}.bind(this));
		},

		onSubmit: function () {
			debugger;
			//var that = this;
			var currentData = this.getView().getModel("dataModel").getData();

			// var SDVIEWData = this.getView().getModel("SDVIEWModel").getData();
			// var CMVIEWData = this.getView().getModel("CMVIEWModel").getData();
			// var PURCHVIEWData = this.getView().getModel("PURCHVIEWModel").getData();
			// var PPVIEWData = this.getView().getModel("PPVIEWModel").getData();
			// var QMVIEWData = this.getView().getModel("QMVIEWModel").getData();
			// var FIVIEWData = this.getView().getModel("FIVIEWModel").getData();

			// var storageLOCTab = this.getView().byId("tableForSLOC");
			// var SLocItems = storageLOCTab.getItems();
			// SLocItems.forEach(function (obj, index) {
			// 	this.SLOC[index].SLOCX = obj.getAggregation("cells")[2].getProperty("selected") === true ? "X" : "";
			// }.bind(this));

			// if (this.f4helps.PlantData.length > 0) {
			// 	this.f4helps.PlantData.forEach(function (plantObj) {
			// 		plantObj.PLANTX = sap.ui.getCore().byId(plantObj.WERKS).getSelected() === true ? "X" : "";
			// 	});
			// }
			// if (currentData.materialGrp !== "" || currentData.materialText !== "" || currentData.baseUnitMeasure !== "" || currentData.netWeight !==
			// 	"" || currentData.grossWeight !== "") {
			// 	MessageToast.show("Fill all mandatory fields.");

			// } else {
			var INITVIEWHDRDATA_obj = {
				PAL: currentData.pm_pal,
				PLR: currentData.pm_plr,
				NO_KG: currentData.no_Of_Carton,
				PAC: currentData.no_Of_Pcs,
				BARCODE: currentData.barCode_Sku,
				RETMARGIN: currentData.retailerMargin,
				MHDRZ: currentData.minRem,

				BWTAR_D: currentData.valuationtype,

				VRKME: currentData.salesunit,

				NO_KG: currentData.noofkg,
				CARTONS: currentData.noofdz_bp_hg,

				GEWEI: currentData.weightOfKg,

				DISMARGIN: currentData.distributorMargin,
				MHDHB: currentData.total_self,

				MTART: currentData.initData,

				ERSDA: currentData.creationData, //creation date
				FORMNO: currentData.mmFormNumber, //form number
				MAKTX: currentData.materialText, // material description
				MATKL: currentData.materialGrp, //material group
				MATNR: currentData.materialNo, //material number
				MEINS: currentData.baseUnitMeasure, //base unit of measure
				MTART: currentData.materialType, //material type
				NTGEW: currentData.netWeight, //Net Weight
				BRGEW: currentData.grossWeight, //Gross Weight
				SPART: currentData.nationExport, // national export
				XCHPF: currentData.batch === true ? "X" : "" //Batch
			};

			dataManagerLib.FGSubmitObjData(currentData.materialType, INITVIEWHDRDATA_obj, this.f4helps.PlantData, this.SLOC,
				this.PPVIEWDATA, this.FIVIEWDATA, this.QMVIEW, this.SDVIEW, this.CMVIEW,

				function (response) {
					var resultObj = JSON.parse(response.Return);
					if (resultObj[0].TYPE === "S") {
						this.serviceSuccessDialog = new Dialog({
							title: "Information",
							type: "Message",
							state: "None",
							content: new Text({
								text: resultObj[0].MESSAGE
							}),
							beginButton: new Button({
								text: "OK",
								press: function () {
									this.serviceSuccessDialog.close();
									this.onNavBack();
								}.bind(this)
							})
						});
					} else {
						this.serviceSuccessDialog = new Dialog({
							title: "Information",
							type: "Message",
							state: "None",
							content: new Text({
								text: resultObj[0].MESSAGE
							}),
							beginButton: new Button({
								text: "OK",
								press: function () {
									this.serviceSuccessDialog.close();
								}.bind(this)
							})
						});
					}
					this.serviceSuccessDialog.open();
				}.bind(this),
				function (error) {
					if (!this.serviceErrorDialog) {
						this.serviceErrorDialog = new Dialog({
							title: "Error",
							type: "Message",
							state: "Error",
							content: new Text({
								text: "HTTP request failed."
							}),
							beginButton: new Button({
								text: "OK",
								press: function () {
									this.serviceErrorDialog.close();
								}.bind(this)
							})
						});
					}
					this.serviceErrorDialog.open();
				}.bind(this));

			// }
		},

		onApprove: function () {
			if (this.Workitem === null || this.TopWorkitem === null) {
				if (!this.noApproversDialog) {
					this.noApproversDialog = new Dialog({
						title: "Information",
						type: "Message",
						state: "None",
						content: new Text({
							text: "User cann't reject this request."
						}),
						beginButton: new Button({
							text: "OK",
							press: function () {
								this.noApproversDialog.close();
							}.bind(this)
						})
					});
				}
				this.noApproversDialog.open();
			} else {
				var currentData = this.getView().getModel("dataModel").getData();
				var SDVIEWData = this.getView().getModel("SDVIEWModel").getData();
				var CMVIEWData = this.getView().getModel("CMVIEWModel").getData();
				// var PURCHVIEWData = this.getView().getModel("PURCHVIEWModel").getData();

				this.PPVIEWDATA.REPEATATIVE_MANF = this.getView().byId('RepetativeFg').mProperties.enabled === true ? "X" : "";
				var PPVIEWData = this.getView().getModel("PPVIEWModel").getData();

				this.QMVIEW.ACTIVE = this.getView().byId('ACTIVE').mProperties.enabled === true ? "X" : "";
				this.QMVIEW.PREFERRED_INSP_TYPE = this.getView().byId('PREFERRED_INSP_TYPE').mProperties.enabled === true ? "X" : "";
				var QMVIEWData = this.getView().getModel("QMVIEWModel").getData();

				this.FIVIEWDATA.QTY_STRUCTURE = this.getView().byId('Qty').mProperties.enabled === true ? "X" : "";
				this.FIVIEWDATA.MATERIAL_ORIGIN = this.getView().byId('material_origin').mProperties.enabled === true ? "X" : "";
				var FIVIEWData = this.getView().getModel("FIVIEWModel").getData();

				var storageLOCTab = this.getView().byId("tableForSLOC");
				var SLocItems = storageLOCTab.getItems();
				SLocItems.forEach(function (obj, index) {
					this.SLOC[index].SLOCX = obj.getAggregation("cells")[4].getProperty("selected") === true ? "X" : "";
				}.bind(this));

				if (this.f4helps.PlantData.length > 0) {
					this.f4helps.PlantData.forEach(function (plantObj) {
						plantObj.PLANTX = sap.ui.getCore().byId(plantObj.WERKS).getSelected() === true ? "X" : "";
					});
				}

				//var QMVIEWData = {

				//}

				var INITVIEWHDRDATA_obj = {
					ERSDA: currentData.creationData, //creation date
					FORMNO: currentData.mmFormNumber, //form number
					MAKTX: currentData.materialText, // material description
					MATKL: currentData.materialGrp, //material group
					MATNR: currentData.materialNo, //material number
					MEINS: currentData.baseUnitMeasure, //base unit of measure
					MTART: currentData.materialType, //material type
					NTGEW: currentData.netWeight, //Net Weight
					BRGEW: currentData.grossWeight, //Gross Weight
					SPART: currentData.nationExport, // national export
					XCHPF: currentData.batch === true ? "X" : "" //Batch
				};

				dataManagerLib.FGApproveREQ(
					currentData.materialType,
					INITVIEWHDRDATA_obj,
					CMVIEWData,
					SDVIEWData,
					// PURCHVIEWData,
					PPVIEWData,
					QMVIEWData,
					FIVIEWData,
					this.f4helps.PlantData,
					this.SLOC,
					this.Workitem.toString(),
					this.TopWorkitem.toString(),
					"001",
					function (response) {
						var resultObj = JSON.parse(response.Return);
						if (resultObj[0].TYPE === "S") {
							this.serviceSuccessDialog = new Dialog({
								title: "Information",
								type: "Message",
								state: "None",
								content: new Text({
									text: resultObj[0].MESSAGE
								}),
								beginButton: new Button({
									text: "OK",
									press: function () {
										window.close();
									}.bind(this)
								})
							});
						} else {
							this.serviceSuccessDialog = new Dialog({
								title: "Information",
								type: "Message",
								state: "None",
								content: new Text({
									text: resultObj[0].MESSAGE
								}),
								beginButton: new Button({
									text: "OK",
									press: function () {
										this.serviceSuccessDialog.close();
									}.bind(this)
								})
							});
						}
						this.serviceSuccessDialog.open();
					}.bind(this),
					function (error) {
						if (!this.serviceErrorDialog) {
							this.serviceErrorDialog = new Dialog({
								title: "Error",
								type: "Message",
								state: "Error",
								content: new Text({
									text: "HTTP request failed."
								}),
								beginButton: new Button({
									text: "OK",
									press: function () {
										this.serviceErrorDialog.close();
									}.bind(this)
								})
							});
						}
						this.serviceErrorDialog.open();
					}.bind(this));
			}
		},

		onFGReject: function (oEvent) {
			if (this.Approvers.length < 1 || this.Workitem === null || this.TopWorkitem === null) {
				if (!this.noApproversDialog) {
					this.noApproversDialog = new Dialog({
						title: "Information",
						type: "Message",
						state: "None",
						content: new Text({
							text: "User cann't reject this request."
						}),
						beginButton: new Button({
							text: "OK",
							press: function () {
								this.noApproversDialog.close();
							}.bind(this)
						})
					});
				}
				this.noApproversDialog.open();
			} else {
				var Reject = {
					rejectLevel: 0,
					rejectText: ""
				};
				var RejectModel = new JSONModel(Reject);
				this.getView().setModel(RejectModel, "RejectModel");
				// create value help dialog
				if (!this.RejectDialog) {
					this.RejectDialog = sap.ui.xmlfragment(
						"zfiori.zmaterial_master.fragments.FG_RejectForm",
						this
					);
					this.getView().addDependent(this.RejectDialog);
				}
				// open value help dialog filtered by the input value
				this.RejectDialog.open();
			}
		},

		onOkFGReject: function (oEvent) {

			//var that = this;
			var RejectModel = this.getView().getModel("RejectModel").getData();
			var RejectText = RejectModel.rejectText;
			var RejectLevel = {};
			this.Approvers.forEach(function (apvObj) {
				if (apvObj.ORGEH === parseInt(RejectModel.rejectLevel, 0)) {
					RejectLevel = apvObj;
				}
			});
			var currentData = this.getView().getModel("dataModel").getData();
			var SDVIEWData = this.getView().getModel("SDVIEWModel").getData();
			var CMVIEWData = this.getView().getModel("CMVIEWModel").getData();
			// var PURCHVIEWData = this.getView().getModel("PURCHVIEWModel").getData();
			this.PPVIEWDATA.REPEATATIVE_MANF = this.getView().byId('RepetativeFg').mProperties.enabled === true ? "X" : "";
			var PPVIEWData = this.getView().getModel("PPVIEWModel").getData();

			this.QMVIEW.ACTIVE = this.getView().byId('ACTIVE').mProperties.enabled === true ? "X" : "";
			this.QMVIEW.PREFERRED_INSP_TYPE = this.getView().byId('PREFERRED_INSP_TYPE').mProperties.enabled === true ? "X" : "";
			var QMVIEWData = this.getView().getModel("QMVIEWModel").getData();

			this.FIVIEWDATA.QTY_STRUCTURE = this.getView().byId('Qty').mProperties.enabled === true ? "X" : "";
			this.FIVIEWDATA.MATERIAL_ORIGIN = this.getView().byId('material_origin').mProperties.enabled === true ? "X" : "";
			var FIVIEWData = this.getView().getModel("FIVIEWModel").getData();

			var storageLOCTab = this.getView().byId("tableForSLOC");
			var SLocItems = storageLOCTab.getItems();
			SLocItems.forEach(function (obj, index) {
				this.SLOC[index].SLOCX = obj.getAggregation("cells")[2].getProperty("selected") === true ? "X" : "";
			}.bind(this));

			var INITVIEWHDRDATA_obj = {
				ERSDA: currentData.creationData, //creation date
				FORMNO: currentData.mmFormNumber, //form number
				MAKTX: currentData.materialText, // material description
				MATKL: currentData.materialGrp, //material group
				MATNR: currentData.materialNo, //material number
				MEINS: currentData.baseUnitMeasure, //base unit of measure
				MTART: currentData.materialType, //material type
				NTGEW: currentData.netWeight, //Net Weight
				BRGEW: currentData.grossWeight, //Gross Weight
				SPART: currentData.nationExport, // national export
				XCHPF: currentData.batch === true ? "X" : "" //Batch
			};

			dataManagerLib.FGRejectREQ(
				currentData.materialType,
				INITVIEWHDRDATA_obj,
				CMVIEWData,
				SDVIEWData,
				// PURCHVIEWData,
				PPVIEWData,
				QMVIEWData,
				FIVIEWData,
				this.f4helps.PlantData,
				this.SLOC,
				this.Workitem.toString(),
				this.TopWorkitem.toString(),
				"001",
				RejectLevel,
				RejectText,
				function (response) {
					var resultObj = JSON.parse(response.Return);
					if (resultObj[0].TYPE === "S") {
						this.serviceSuccessDialog = new Dialog({
							title: "Information",
							type: "Message",
							state: "None",
							content: new Text({
								text: resultObj[0].MESSAGE
							}),
							beginButton: new Button({
								text: "OK",
								press: function () {
									window.close();
								}.bind(this)
							})
						});
					} else {
						this.serviceSuccessDialog = new Dialog({
							title: "Information",
							type: "Message",
							state: "None",
							content: new Text({
								text: resultObj[0].MESSAGE
							}),
							beginButton: new Button({
								text: "OK",
								press: function () {
									this.serviceSuccessDialog.close();
								}.bind(this)
							})
						});
					}
					this.serviceSuccessDialog.open();
				}.bind(this),
				function (error) {
					if (!this.serviceErrorDialog) {
						this.serviceErrorDialog = new Dialog({
							title: "Error",
							type: "Message",
							state: "Error",
							content: new Text({
								text: "HTTP request failed."
							}),
							beginButton: new Button({
								text: "OK",
								press: function () {
									this.serviceErrorDialog.close();
								}.bind(this)
							})
						});
					}
					this.serviceErrorDialog.open();
				}.bind(this));

		},

		onCloseReject: function (oEvent) {
			this.RejectDialog.close();
		},

		onBeforeRendering: function () {

		},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf zfiori.zmaterial_master.view.MaterialDetails
		 */
		onAfterRendering: function () {

		},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf zfiori.zmaterial_master.view.MaterialDetails
		 */
		onExit: function () {

		}

	});

});