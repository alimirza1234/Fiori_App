sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/Button",
	"sap/m/Dialog",
	"sap/m/DialogType",
	"sap/m/Text",
	"sap/ui/layout/HorizontalLayout",
	"sap/ui/layout/VerticalLayout",
	"sap/m/TextArea",
	"sap/ui/core/UIComponent",
	"sap/ui/model/Filter",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/Fragment",
	"sap/m/MessageToast",
	"zfiori/zmaterial_master/utils/dataManagerLib"
], function (Controller, Button, Dialog, DialogType, Text, HorizontalLayout, VerticalLayout, TextArea, UIComponent, Filter,
	JSONModel, Fragment, MessageToast, dataManagerLib) {
	"use strict";

	return Controller.extend("zfiori.zmaterial_master.controller.MaterialType", {

		escapePreventDialog: null,
		serviceErrorDialog: null,
		confirmEscapePreventDialog: null,
		oSelectedData: {
			materialTypeRadio: {
				selected: false,
				materialTypes: [],
				materialType: null
			},
			copyFromRadio: {
				selected: true,
				materials: [],
				materialNumber: null,
				selectedMaterialType: null
			}
		},
		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf zfiori.zmaterial_master.view.MaterialType
		 */
		onInit: function () {
			var oView = this.getView().byId("MatTyp");
			oView.destroyContent();
			this.getOwnerComponent().getRouter().getRoute("MaterialType").attachMatched(this.onNavToCurrentPage, this);
		},

		onNavToCurrentPage: function (oEvent) {
			var that = this;
			dataManagerLib.getf4Help(function (response) {
				if (response.results.length > 0) {
					response.results.forEach(function (obj) {
						if (obj.Key === "MatTypes") {
							that.oSelectedData.materialTypeRadio.materialTypes = JSON.parse(obj.Value);
						}
						if (obj.Key === "Materials") {
							that.oSelectedData.copyFromRadio.materials = JSON.parse(obj.Value);
						}
					});
				}
				if (!this.escapePreventDialog) {
					var FormNoRadio;
					if (!sap.ui.getCore().byId("FormNoRadio")) {
						FormNoRadio = new sap.m.RadioButton("FormNoRadio", {
							text: "Copy From Material #",
							selected: this.oSelectedData.copyFromRadio.selected,
							select: function (rEvent) {
								this.oSelectedData.copyFromRadio.selected = rEvent.getParameter("selected");
								sap.ui.getCore().byId("FormNoSelect").setEnabled(rEvent.getParameter("selected"));
								sap.ui.getCore().byId("MatTypeSelect").setSelectedKey("");
								this.oSelectedData.materialTypeRadio.materialType = null;
							}.bind(this)
						});
					} else {
						FormNoRadio = sap.ui.getCore().byId("FormNoRadio");
					}

					var suggestionColumnsTemp = [];
					suggestionColumnsTemp.push(
						new sap.m.Column({
							header: new sap.m.Label({
								text: "Material"
							})
						}),
						new sap.m.Column({
							hAlign: "Center",
							popinDisplay: "Inline",
							demandPopin: true,
							minScreenWidth: "3840px",
							header: new sap.m.Label({
								text: "Description"
							})
						}),
						new sap.m.Column({
							header: new sap.m.Label({
								text: "Material Type"
							})
						})
					);
					var suggestionRowsTemp = [];
					if (this.oSelectedData.copyFromRadio.materials.length > 0) {
						this.oSelectedData.copyFromRadio.materials.forEach(function (matnrObj) {
							suggestionRowsTemp.push(
								new sap.m.ColumnListItem({
									cells: [
										new sap.m.Label({
											text: matnrObj.MATNR
										}),
										new sap.m.Label({
											text: matnrObj.MAKTG
										}),
										new sap.m.Label({
											text: matnrObj.MTART
										})
									]
								})
							);
						});
					}
					var fSelect;
					if (!sap.ui.getCore().byId("FormNoSelect")) {
						fSelect = new sap.m.Input("FormNoSelect", {
							showSuggestion: true,
							showTableSuggestionValueHelp: false,
							suggestionItemSelected: function (sisEvt) {
								var oInput = sap.ui.getCore().byId("FormNoSelect");
								this.oSelectedData.copyFromRadio.materialNumber = oInput.getSelectedKey();
								this.oSelectedData.copyFromRadio.selectedMaterialType = sisEvt.getParameter("selectedRow").getAggregation("cells")[2].getProperty(
									"text");
							}.bind(this),
							width: "100%",
							suggestionColumns: [suggestionColumnsTemp],
							suggestionRows: [suggestionRowsTemp],
							enabled: this.oSelectedData.copyFromRadio.selected
						});
						fSelect.setSuggestionRowValidator(this.suggestionRowValidator);
					} else {
						fSelect = sap.ui.getCore().byId("FormNoSelect");
					}
					var MatTypeRadio;
					if (!sap.ui.getCore().byId("MatTypeRadio")) {
						MatTypeRadio = new sap.m.RadioButton("MatTypeRadio", {
							text: "Select Material Type:",
							selected: this.oSelectedData.materialTypeRadio.selected,
							select: function (rEvent) {
								this.oSelectedData.materialTypeRadio.selected = rEvent.getParameter("selected");
								sap.ui.getCore().byId("MatTypeSelect").setEnabled(rEvent.getParameter("selected"));
								sap.ui.getCore().byId("FormNoSelect").setValue("");
								this.oSelectedData.copyFromRadio.materialNumber = null;
								this.oSelectedData.copyFromRadio.selectedMaterialType = null;
							}.bind(this)
						});
					} else {
						MatTypeRadio = sap.ui.getCore().byId("MatTypeRadio");
					}

					var mItems = [];
					mItems.push(
						new sap.ui.core.ListItem({
							key: "",
							text: "",
							additionalText: ""
						})
					);
					if (this.oSelectedData.materialTypeRadio.materialTypes.length > 0) {
						this.oSelectedData.materialTypeRadio.materialTypes.forEach(function (objMaterialType) {
							mItems.push(
								new sap.ui.core.ListItem({
									key: objMaterialType.MTART,

									text: objMaterialType.MTART,
									additionalText: objMaterialType.MTBEZ
								})
							);
						});
					}
					var mtSelect;
					if (!sap.ui.getCore().byId("MatTypeSelect")) {
						mtSelect = new sap.m.Select("MatTypeSelect", {
							width: "100%",
							items: [mItems],
							showSecondaryValues: true,
							selectedKey: this.oSelectedData.materialTypeRadio.materialType,
							enabled: this.oSelectedData.materialTypeRadio.selected,
							change: function (evt) {
								this.oSelectedData.materialTypeRadio.materialType = evt.getParameters("selectedItem").selectedItem.getProperty("key");
							}.bind(this)
						});
					} else {
						mtSelect = sap.ui.getCore().byId("MatTypeSelect");
					}

					this.escapePreventDialog = new Dialog({
						title: "Please select any one option",
						type: "Message",
						content: [
							FormNoRadio,
							fSelect,
							MatTypeRadio,
							mtSelect
						],
						buttons: [
								new Button({
									text: "Ok",
									press: function () {

										this.getView().getParent().setModel(new JSONModel(this.oSelectedData), "selectedModel");
										this.escapePreventDialog.close();
										var loRouter = UIComponent.getRouterFor(this);

										if (this.oSelectedData.materialTypeRadio.selected && (this.oSelectedData.materialTypeRadio.materialType === "ZFGD" ||
												this.oSelectedData.materialTypeRadio.materialType === "ZFG")) {
											// MessageToast.show("UNDER CONSTRUCTION.");
											loRouter.navTo("FGMaterialDetails");
										} else if (this.oSelectedData.copyFromRadio.selected && (this.oSelectedData.copyFromRadio.selectedMaterialType ===
												'ZFGD' ||
												this.oSelectedData.copyFromRadio.selectedMaterialType === 'ZFG')) {
											loRouter = UIComponent.getRouterFor(this);
											// MessageToast.show("UNDER CONSTRUCTION.");
											loRouter.navTo("FGMaterialDetails");
										} else {
											loRouter.navTo("MaterialDetails");
										}
										// var loRouter = UIComponent.getRouterFor(this);
										// loRouter.navTo("MaterialDetails");
									}.bind(this)
								}),
								new Button({
									text: "Close",
									press: function () {
										this.escapePreventDialog.close();
									}.bind(this)
								})
							]
							// ,
							// escapeHandler: function (oPromise) {
							// 	if (!this.confirmEscapePreventDialog) {
							// 		this.confirmEscapePreventDialog = new Dialog({
							// 			title: "Warning",
							// 			type: "Message",
							// 			state: "Warning",
							// 			content: new Text({
							// 				text: "Please select any one option."
							// 			}),
							// 			beginButton: new Button({
							// 				text: "OK",
							// 				press: function () {
							// 					this.confirmEscapePreventDialog.close();
							// 				}.bind(this)
							// 			})
							// 		});
							// 	}
							// 	this.confirmEscapePreventDialog.open();
							// }.bind(this)
					});
				}
				this.escapePreventDialog.open();
			}.bind(this), function (error) {
				if (!this.serviceErrorDialog) {
					this.serviceErrorDialog = new Dialog({
						title: "Error",
						type: "Message",
						state: "Error",
						content: new Text({
							text: "HTTP request failed."
						}),
						beginButton: new Button({
							text: "OK",
							press: function () {
								this.serviceErrorDialog.close();
							}.bind(this)
						})
					});
				}
				this.serviceErrorDialog.open();
			}.bind(this));

		},

		suggestionRowValidator: function (oColumnListItem) {
			var aCells = oColumnListItem.getCells();
			return new sap.ui.core.Item({
				key: aCells[0].getText(),
				text: aCells[2].getText() + ": " + aCells[1].getText() + " (" + aCells[0].getText() + ")"
			});
		}.bind(this),

		onAdd: function () {
			this.escapePreventDialog.open();
		},

		onBeforeRendering: function () {

		},

		onAfterRendering: function () {

		},

		onExit: function () {

		}

	});

});