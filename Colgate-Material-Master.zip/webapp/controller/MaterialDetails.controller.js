sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"zfiori/zmaterial_master/utils/dataManagerLib",
	"sap/m/Button",
	"sap/m/Dialog",
	"sap/m/DialogType",
	"sap/m/Text",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/Fragment",
	"sap/ui/model/Filter",
	'sap/m/MessageToast'
], function (Controller, History, dataManagerLib, Button, Dialog, DialogType, Text, JSONModel, Fragment, Filter, MessageToast) {
	"use strict";

	return Controller.extend("zfiori.zmaterial_master.controller.MaterialDetails", {
		page: {
			Create: false,
			Approve: false
		},
		oFormID: null,
		pageSections: [],
		materialObj: {
			materialType: null,
			nationExport: null,
			creationData: null,
			mmFormNumber: null,
			baseUnitMeasure: "EA",
			materialNo: null,
			materialGrp: null,
			netWeight: "0.001",
			grossWeight: "0.001",
			materialText: null,
			batch: false
		},
		serviceErrorDialog: null,
		serviceSuccessDialog: null,
		initData: {
			ERSDA: null, //creation date
			FORMNO: null, //form number
			MAKTX: null, // material description
			MATKL: null, //material group
			MATNR: null, //material number
			MEINS: null, //base unit of measure
			MTART: null, //material type
			NTGEW: "0.001", //Net Weight
			BRGEW: "0.001", //Gross Weight
			SPART: null, // national export
			XCHPF: null //Batch
		},
		SDVIEW: {},
		PURCHDATA: {},
		PPVIEWDATA: {},
		QMVIEW: {},
		FIVIEWDATA: {},
		TopWorkitem: null,
		Workitem: null,
		StorageLocationRowId: {
			id: ""
		},
		SLOC: [],
		PLANTXYZ: [],
		footerBtn: {
			Submit: true,
			Approve: false,
			Reject: false,
			Complete: false
		},
		f4helps: {
			MaterialGroup: [],
			// ValuationClass: [],
			PlantData: [],
			NationalExport: []
		},
		Approvers: [],

		onInit: function () {
			this.getOwnerComponent().getRouter().getRoute("MaterialDetails").attachMatched(this.onNavToCurrentPage, this);
		},

		onNavToCurrentPage: function (oEvent) {
			//debugger;
			var that = this;
			var PlantGrid = this.getView().byId("PlantCheckB");
			PlantGrid.destroyContent();
			that.oFormID = oEvent.getParameter("arguments").formId;

			var footerModel = new JSONModel();
			var f4HelpsModel = new JSONModel();

			that.getView().setModel(f4HelpsModel, "f4helps");
			that.materialObj.creationData = new Date().toLocaleDateString();

			that.pageSections = [{
				View: "INITVIEW",
				Visible: false,
				Enable: false,
				OtherData: {},
				oModel: (function () {
					var dataModel = new JSONModel();
					that.getView().setModel(dataModel, "dataModel");
				})()
			}, {
				View: "SDVIEW",
				Visible: false,
				Enable: false,
				OtherData: {},
				oModel: (function () {
					var dataModel = new JSONModel();
					that.getView().setModel(dataModel, "SDVIEWModel");
				})()
			}, {
				View: "PURCHVIEW",
				Visible: false,
				Enable: false,
				OtherData: {},
				oModel: (function () {
					var dataModel = new JSONModel();
					that.getView().setModel(dataModel, "PURCHVIEWModel");
				})()
			}, {
				View: "PPVIEW",
				Visible: false,
				Enable: false,
				OtherData: {},
				oModel: (function () {
					var dataModel = new JSONModel();
					that.getView().setModel(dataModel, "PPVIEWModel");
				})()
			}, {
				View: "QMVIEW",
				Visible: false,
				Enable: false,
				OtherData: {},
				oModel: (function () {
					var dataModel = new JSONModel();
					that.getView().setModel(dataModel, "QMVIEWModel");
				})()
			}, {
				View: "FIVIEW",
				Visible: false,
				Enable: false,
				OtherData: {},
				oModel: (function () {
					var dataModel = new JSONModel();
					that.getView().setModel(dataModel, "FIVIEWModel");
				})()
			}];
			//that.oFormID = "0000000217";
			if (that.oFormID) {
				that.page.Approve = true;
				that.page.Create = false;
				that.getView().byId("MatDet").setShowNavButton(false);
				that.footerBtn.Submit = false;
				that.footerBtn.Approve = true;
				that.footerBtn.Reject = true;
				that.footerBtn.Complete = true;
				footerModel.setData(that.footerBtn);
				var approverModel = new JSONModel();
				that.getView().setModel(approverModel, "ApproversModel");
				dataManagerLib.getFormData("02", that.oFormID, function (response) {
					if (response.results.length > 0) {
						response.results.forEach(function (obj) {
							if (obj.Key === "INITIALVIEWDATA") {
								that.initData = JSON.parse(obj.Value);
							}
							if (obj.Key === "MaterialGroup") {
								that.f4helps.MaterialGroup = JSON.parse(obj.Value);
							}
							if (obj.Key === "NExport") {
								that.f4helps.NationalExport = JSON.parse(obj.Value);
							}
							if (obj.Key === "PLANTDATA") {
								that.f4helps.PlantData = JSON.parse(obj.Value);
							}
							if (obj.Key === "PurchasingGroup") {
								that.f4helps.PurchasingGroup = JSON.parse(obj.Value);
							}
							if (obj.Key === "Variancekey") {
								that.f4helps.Variancekey = JSON.parse(obj.Value);
							}
							if (obj.Key === "ValuationClass") {
								that.f4helps.ValuationClass = JSON.parse(obj.Value);
							}
							if (obj.Key === "HSCode") {
								that.f4helps.HSCode = JSON.parse(obj.Value);
							}
							if (obj.Key === "SpecialPprocurementT") {
								that.f4helps.SpecialPprocurementT = JSON.parse(obj.Value);
							}
							if (obj.Key === "UnitofMeasurement") {
								that.f4helps.UnitofMeasurement = JSON.parse(obj.Value);
							}
							if (obj.Key === "PurchaseValueKey") {
								that.f4helps.PurchaseValueKey = JSON.parse(obj.Value);
							}
							if (obj.Key === "MrpTypes") {
								that.f4helps.MrpTypes = JSON.parse(obj.Value);
							}
							if (obj.Key === "PPStorageLocation") {
								that.f4helps.PPStorageLocation = JSON.parse(obj.Value);
							}
							if (obj.Key === "ProdSupervisor") {
								that.f4helps.ProdSupervisor = JSON.parse(obj.Value);
							}
							if (obj.Key === "MRP_group") {
								that.f4helps.MRP_GROUP = JSON.parse(obj.Value);
							}
							if (obj.Key === "MRPController") {
								that.f4helps.MRPController = JSON.parse(obj.Value);
							}
							if (obj.Key === "Lotsize") {
								that.f4helps.Lotsize = JSON.parse(obj.Value);
							}
							if (obj.Key === "SLOCDATA") {
								that.SLOC = JSON.parse(obj.Value);
							}
							if (obj.Key === "SDVIEWDATA") {
								that.SDVIEW = JSON.parse(obj.Value);
							}
							if (obj.Key === "PURCHVIEWDATA") {
								that.PURCHDATA = JSON.parse(obj.Value);
							}
							if (obj.Key === "PPVIEWDATA") {
								that.PPVIEWDATA = JSON.parse(obj.Value);
							}
							if (obj.Key === "QMVIEWDATA") {
								that.QMVIEW = JSON.parse(obj.Value);
							}
							if (obj.Key === "FIVIEWDATA") {
								that.FIVIEWDATA = JSON.parse(obj.Value);
							}
							if (obj.Key === "Workitem") {
								that.Workitem = obj.Value;
							}
							if (obj.Key === "TopWorkitem") {
								that.TopWorkitem = obj.Value;
							}
							if (obj.Key === "approvers") {
								that.Approvers = JSON.parse(obj.Value);
							}
						});
						f4HelpsModel.setData(that.f4helps);
						f4HelpsModel.refresh();

						that.materialObj = {
							materialType: that.initData.MTART,
							nationExport: that.initData.SPART,
							creationData: new Date(that.initData.ERSDA).toLocaleDateString(),
							mmFormNumber: that.initData.FORMNO,
							baseUnitMeasure: that.initData.MEINS,
							materialNo: that.initData.MATNR,
							materialGrp: that.initData.MATKL,
							netWeight: that.initData.NTGEW,
							grossWeight: that.initData.BRGEW,
							materialText: that.initData.MAKTX,
							batch: that.initData.XCHPF === "X" ? true : false
						};

						that.enableViews(that.materialObj.materialType, function (pageSections) {
							if (pageSections[3].Enable && that.materialObj.materialType === "ZSPR") {
								that.getView().byId("PPCheckBox").setEnabled(false);
							} else if (pageSections[3].Enable) {
								that.getView().byId("PPCheckBox").setEnabled(true);
							} else {
								that.getView().byId("PPCheckBox").setEnabled(false);
							}
							that.createPlantBoxs(that.f4helps.PlantData, "A");
							var isInitiator = false;
							pageSections.forEach(function (viewsObj) {
								if (viewsObj.View === "INITVIEW") {
									isInitiator = viewsObj.Enable;
								}
							});
							// that.SLOC.map(function (obj) {
							// 	obj.ACTION = "R";
							// });
							that.SLOC.forEach(function (slocObj) {
								if (slocObj.SLOCX === "X") {
									slocObj.isSelected = true;
								} else {
									slocObj.isSelected = false;
								}
								if (slocObj.ACTION === "E" && isInitiator) {
									slocObj.isEditable = true;
								} else {
									slocObj.isEditable = false;
								}
							});
							var SLOCModel = new JSONModel({
								Locations: that.SLOC
							});
							that.getView().setModel(SLOCModel, "SLoc");

						});

						var isViewEnable = that.getView().getModel("isEnabledModel").getData();

						if (isViewEnable.pageSections[0].Enable && that.materialObj.materialType === "ZSPR") {
							that.getView().byId("NEInput").setEnabled(false);
						} else if (isViewEnable.pageSections[0].Enable) {
							that.getView().byId("NEInput").setEnabled(true);
						} else {
							that.getView().byId("NEInput").setEnabled(false);
						}

						//For Init View
						var dataModel = that.getView().getModel("dataModel");
						dataModel.setData(that.materialObj);
						dataModel.refresh();

						//For SD View
						var dataModel = that.getView().getModel("SDVIEWModel");
						dataModel.setData(that.SDVIEW);
						dataModel.refresh();

						//For Purchase View
						var dataModel = that.getView().getModel("PURCHVIEWModel");
						dataModel.setData(that.PURCHDATA);
						dataModel.refresh();

						//For PP View
						var dataModel = that.getView().getModel("PPVIEWModel");
						dataModel.setData(that.PPVIEWDATA);
						dataModel.refresh();

						//For QM View
						var dataModel = that.getView().getModel("QMVIEWModel");
						dataModel.setData(that.QMVIEW);
						dataModel.refresh();

						//For FI View
						var dataModel = that.getView().getModel("FIVIEWModel");
						dataModel.setData(that.FIVIEWDATA);
						dataModel.refresh();

						//For Approvers
						var dataModel = that.getView().getModel("ApproversModel");
						dataModel.setData({
							Approvers: that.Approvers
						});
						dataModel.refresh();
					}
				}.bind(this), function (error) {
					if (!this.serviceErrorDialog) {
						this.serviceErrorDialog = new Dialog({
							title: "Error",
							type: "Message",
							state: "Error",
							content: new Text({
								text: "HTTP request failed."
							}),
							beginButton: new Button({
								text: "OK",
								press: function () {
									this.serviceErrorDialog.close();
								}.bind(this)
							})
						});
					}
					this.serviceErrorDialog.open();
				}.bind(this));
			} else {
				that.page.Create = true;
				that.page.Approve = false;
				that.getView().byId("MatDet").setShowNavButton(true);
				that.footerBtn.Submit = true;
				that.footerBtn.Approve = false;
				that.footerBtn.Reject = false;
				that.footerBtn.Complete = false;
				footerModel.setData(that.footerBtn);
				var selectedModel = this.getView().getParent().getModel("selectedModel");
				var selectedData = selectedModel.getData();
				if (selectedData.copyFromRadio.selected) {
					var matnr = selectedData.copyFromRadio.materialNumber;
					var Mtart = selectedData.copyFromRadio.selectedMaterialType;
					dataManagerLib.copyMatnr(matnr, Mtart, function (response) {
						if (response.results.length > 0) {
							response.results.forEach(function (obj) {
								if (obj.Key === "INITVIEWHDRDATA") {
									that.initData = JSON.parse(obj.Value);
								}
								if (obj.Key === "MaterialGroup") {
									that.f4helps.MaterialGroup = JSON.parse(obj.Value);
								}
								if (obj.Key === "NExport") {
									that.f4helps.NationalExport = JSON.parse(obj.Value);
								}
								if (obj.Key === "PlantData") {
									that.f4helps.PlantData = JSON.parse(obj.Value);
								}
								if (obj.Key === "PurchasingGroup") {
									that.f4helps.PurchasingGroup = JSON.parse(obj.Value);
								}
								if (obj.Key === "Variancekey") {
									that.f4helps.Variancekey = JSON.parse(obj.Value);
								}
								if (obj.Key === "ValuationClass") {
									that.f4helps.ValuationClass = JSON.parse(obj.Value);
								}
								if (obj.Key === "HSCode") {
									that.f4helps.HSCode = JSON.parse(obj.Value);
								}
								if (obj.Key === "SpecialPprocurementT") {
									that.f4helps.SpecialPprocurementT = JSON.parse(obj.Value);
								}
								if (obj.Key === "UnitofMeasurement") {
									that.f4helps.UnitofMeasurement = JSON.parse(obj.Value);
								}
								if (obj.Key === "PurchaseValueKey") {
									that.f4helps.PurchaseValueKey = JSON.parse(obj.Value);
								}
								if (obj.Key === "MrpTypes") {
									that.f4helps.MrpTypes = JSON.parse(obj.Value);
								}
								if (obj.Key === "PPStorageLocation") {
									that.f4helps.PPStorageLocation = JSON.parse(obj.Value);
								}
								if (obj.Key === "ProdSupervisor") {
									that.f4helps.ProdSupervisor = JSON.parse(obj.Value);
								}
								if (obj.Key === "MRP_group") {
									that.f4helps.MRP_GROUP = JSON.parse(obj.Value);
								}
								if (obj.Key === "MRPController") {
									that.f4helps.MRPController = JSON.parse(obj.Value);
								}
								if (obj.Key === "Lotsize") {
									that.f4helps.Lotsize = JSON.parse(obj.Value);
								}
								if (obj.Key === "SLOCDATA") {
									that.SLOC = JSON.parse(obj.Value);
								}
								if (obj.Key === "SDVIEWDATA") {
									that.SDVIEW = JSON.parse(obj.Value);
								}
								if (obj.Key === "PURCHVIEWDATA") {
									that.PURCHDATA = JSON.parse(obj.Value);
								}
								if (obj.Key === "PPVIEWDATA") {
									that.PPVIEWDATA = JSON.parse(obj.Value);
								}
								if (obj.Key === "QMVIEWDATA") {
									that.QMVIEW = JSON.parse(obj.Value);
								}
								if (obj.Key === "FIVIEWDATA") {
									that.FIVIEWDATA = JSON.parse(obj.Value);
								}
							});
						}

						f4HelpsModel.setData(that.f4helps);
						f4HelpsModel.refresh();

						that.materialObj = {
							materialType: that.initData.MTART,
							nationExport: that.initData.SPART,
							creationData: new Date(that.initData.ERSDA).toLocaleDateString(),
							mmFormNumber: that.initData.FORMNO,
							baseUnitMeasure: that.initData.MEINS,
							materialNo: that.initData.MATNR,
							materialGrp: that.initData.MATKL,
							netWeight: that.initData.NTGEW,
							grossWeight: that.initData.BRGEW,
							materialText: that.initData.MAKTX,
							batch: that.initData.XCHPF === "X" ? true : false
						};
						that.enableViews(that.materialObj.materialType, function (pageSections) {
							that.createPlantBoxs(that.f4helps.PlantData, "C");
							var SLOCModel = new JSONModel({
								Locations: []
							});
							that.getView().setModel(SLOCModel, "SLoc");
						});
						if (that.page.Create) {
							//Check to enable values in specific material type.
							if (that.materialObj.materialType === "ZPOP" || that.materialObj.materialType === "ZGFN" || that.materialObj.materialType ===
								"ZGFT") {
								//nation export (98 and enable)
								that.getView().byId("NEInput").setEnabled(true);
								//Material number disable
								that.getView().byId("MaterialNum").setEnabled(false);
							}
							if (that.materialObj.materialType === "ZRAW" || that.materialObj.materialType === "ZSFG") {
								//nation export (98 and disable)
								that.getView().byId("NEInput").setEnabled(false);
								//Material number enable
								that.getView().byId("MaterialNum").setEnabled(true);
							}
							if (that.materialObj.materialType === "ZPKG" || that.materialObj.materialType === "ZSPR") {
								//nation export (98 and disable)
								// that.materialObj.nationExport = "98";
								that.getView().byId("NEInput").setEnabled(false);
								//Material number enable
								that.getView().byId("MaterialNum").setEnabled(true);

								that.getView().byId("NEInput").setEnabled(false);
							}
							if (that.materialObj.materialType === "ZSPR") {
								//nation export (98 and disable)
								// that.materialObj.nationExport = "98";
								that.getView().byId("PPCheckBox").setEnabled(false);
							}
						}

						//For Init View
						var dataModel = that.getView().getModel("dataModel");
						dataModel.setData(that.materialObj);
						dataModel.refresh();

						//For SD View
						var dataModel = that.getView().getModel("SDVIEWModel");
						dataModel.setData(that.SDVIEW);
						dataModel.refresh();

						//For Purchase View
						var dataModel = that.getView().getModel("PURCHVIEWModel");
						dataModel.setData(that.PURCHDATA);
						dataModel.refresh();

						//For PP View
						var dataModel = that.getView().getModel("PPVIEWModel");
						dataModel.setData(that.PPVIEWDATA);
						dataModel.refresh();

						//For QM View
						var dataModel = that.getView().getModel("QMVIEWModel");
						dataModel.setData(that.QMVIEW);
						dataModel.refresh();

						//For FI View
						var dataModel = that.getView().getModel("FIVIEWModel");
						dataModel.setData(that.FIVIEWDATA);
						dataModel.refresh();

					}.bind(this), function (error) {
						if (!this.serviceErrorDialog) {
							this.serviceErrorDialog = new Dialog({
								title: "Error",
								type: "Message",
								state: "Error",
								content: new Text({
									text: "HTTP request failed."
								}),
								beginButton: new Button({
									text: "OK",
									press: function () {
										this.serviceErrorDialog.close();
									}.bind(this)
								})
							});
						}
						this.serviceErrorDialog.open();
					}.bind(this));
				} else {
					that.materialObj.materialType = selectedData.materialTypeRadio.materialType;

					dataManagerLib.initMatnr(that.materialObj.materialType, function (response) {
						if (response.results.length > 0) {
							response.results.forEach(function (obj) {
								if (obj.Key === "INITVIEWHDRDATA") {
									that.initData = JSON.parse(obj.Value);
								}
								if (obj.Key === "MaterialGroup") {
									that.f4helps.MaterialGroup = JSON.parse(obj.Value);
								}
								if (obj.Key === "NExport") {
									that.f4helps.NationalExport = JSON.parse(obj.Value);
								}
								if (obj.Key === "PlantData") {
									that.f4helps.PlantData = JSON.parse(obj.Value);
								}
								if (obj.Key === "PurchasingGroup") {
									that.f4helps.PurchasingGroup = JSON.parse(obj.Value);
								}
								if (obj.Key === "Variancekey") {
									that.f4helps.Variancekey = JSON.parse(obj.Value);
								}
								if (obj.Key === "ValuationClass") {
									that.f4helps.ValuationClass = JSON.parse(obj.Value);
								}
								if (obj.Key === "HSCode") {
									that.f4helps.HSCode = JSON.parse(obj.Value);
								}
								if (obj.Key === "SpecialPprocurementT") {
									that.f4helps.SpecialPprocurementT = JSON.parse(obj.Value);
								}
								if (obj.Key === "UnitofMeasurement") {
									that.f4helps.UnitofMeasurement = JSON.parse(obj.Value);
								}
								if (obj.Key === "PurchaseValueKey") {
									that.f4helps.PurchaseValueKey = JSON.parse(obj.Value);
								}
								if (obj.Key === "MrpTypes") {
									that.f4helps.MrpTypes = JSON.parse(obj.Value);
								}
								if (obj.Key === "PPStorageLocation") {
									that.f4helps.PPStorageLocation = JSON.parse(obj.Value);
								}
								if (obj.Key === "ProdSupervisor") {
									that.f4helps.ProdSupervisor = JSON.parse(obj.Value);
								}
								if (obj.Key === "MRP_group") {
									that.f4helps.MRP_GROUP = JSON.parse(obj.Value);
								}
								if (obj.Key === "MRPController") {
									that.f4helps.MRPController = JSON.parse(obj.Value);
								}
								if (obj.Key === "Lotsize") {
									that.f4helps.Lotsize = JSON.parse(obj.Value);
								}
								if (obj.Key === "SLOCDATA") {
									that.SLOC = JSON.parse(obj.Value);
								}
								if (obj.Key === "SDVIEWDATA") {
									that.SDVIEW = JSON.parse(obj.Value);
								}
								if (obj.Key === "PURCHVIEWDATA") {
									that.PURCHDATA = JSON.parse(obj.Value);
								}
								if (obj.Key === "PPVIEWDATA") {
									that.PPVIEWDATA = JSON.parse(obj.Value);
								}
								if (obj.Key === "QMVIEWDATA") {
									that.QMVIEW = JSON.parse(obj.Value);
								}
								if (obj.Key === "FIVIEWDATA") {
									that.FIVIEWDATA = JSON.parse(obj.Value);
								}
							});
						}
						that.enableViews(that.materialObj.materialType, function (pageSections) {
							that.createPlantBoxs(that.f4helps.PlantData, "C");
							var SLOCModel = new JSONModel({
								Locations: []
							});
							that.getView().setModel(SLOCModel, "SLoc");
						});
						f4HelpsModel.setData(that.f4helps);
						f4HelpsModel.refresh();

						if (that.page.Create) {
							//Check to enable values in specific material type.
							if (that.materialObj.materialType === "ZPOP" || that.materialObj.materialType === "ZGFN" || that.materialObj.materialType ===
								"ZGFT") {
								//Batch true
								that.materialObj.batch = true;
								//nation export (98 and enable)
								that.materialObj.nationExport = "98";
								that.getView().byId("NEInput").setEnabled(true);
								//Material number disable
								that.getView().byId("MaterialNum").setEnabled(false);
							}
							if (that.materialObj.materialType === "ZRAW" || that.materialObj.materialType === "ZSFG") {
								//Batch true
								that.materialObj.batch = true;
								//nation export (98 and disable)
								that.materialObj.nationExport = "98";
								that.getView().byId("NEInput").setEnabled(false);
								//Material number enable
								that.getView().byId("MaterialNum").setEnabled(true);
							}
							if (that.materialObj.materialType === "ZPKG") {
								//Batch false
								that.materialObj.batch = false;
								//nation export (98 and disable)
								that.materialObj.nationExport = "98";
								that.getView().byId("NEInput").setEnabled(false);
								//Material number enable
								that.getView().byId("MaterialNum").setEnabled(true);
							}
							if (that.materialObj.materialType === "ZSPR") {
								//Batch false
								that.materialObj.batch = false;
								//nation export (98 and disable)
								//that.materialObj.nationExport = "98";
								that.getView().byId("NEInput").setEnabled(false);
								//Material number enable
								that.getView().byId("MaterialNum").setEnabled(true);
							}
						}
						that.materialObj.creationData = new Date().toLocaleDateString();
						that.materialObj.mmFormNumber = null;
						that.materialObj.baseUnitMeasure = "EA";
						that.materialObj.materialNo = null;
						that.materialObj.materialGrp = null;
						that.materialObj.netWeight = "0.000";
						that.materialObj.grossWeight = "0.000";
						that.materialObj.materialText = null;

						//For Init View
						var dataModel = that.getView().getModel("dataModel");
						dataModel.setData(that.materialObj);
						dataModel.refresh();

						//For SD View
						var dataModel = that.getView().getModel("SDVIEWModel");
						dataModel.setData(that.SDVIEW);
						dataModel.refresh();

						//For Purchase View
						var dataModel = that.getView().getModel("PURCHVIEWModel");
						dataModel.setData(that.PURCHDATA);
						dataModel.refresh();

						//For PP View
						var dataModel = that.getView().getModel("PPVIEWModel");
						dataModel.setData(that.PPVIEWDATA);
						dataModel.refresh();

						//For QM View
						var dataModel = that.getView().getModel("QMVIEWModel");
						dataModel.setData(that.QMVIEW);
						dataModel.refresh();

						//For FI View
						var dataModel = that.getView().getModel("FIVIEWModel");
						dataModel.setData(that.FIVIEWDATA);
						dataModel.refresh();

					}.bind(this), function (error) {
						if (!this.serviceErrorDialog) {
							this.serviceErrorDialog = new Dialog({
								title: "Error",
								type: "Message",
								state: "Error",
								content: new Text({
									text: "HTTP request failed."
								}),
								beginButton: new Button({
									text: "OK",
									press: function () {
										this.serviceErrorDialog.close();
									}.bind(this)
								})
							});
						}
						this.serviceErrorDialog.open();
					}.bind(this));
				}
			}
			that.getView().setModel(footerModel, "footerModel");
		},

		handleValueHelpMGRP: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();

			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._valueHelpDialogMGRP) {
				this._valueHelpDialogMGRP = sap.ui.xmlfragment(
					"zfiori.zmaterial_master.fragments.MaterialGroup",
					this
				);
				this.getView().addDependent(this._valueHelpDialogMGRP);
			}

			// create a filter for the binding
			this._valueHelpDialogMGRP.getBinding("items").filter([new Filter(
				"MATKL",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);

			// open value help dialog filtered by the input value
			this._valueHelpDialogMGRP.open(sInputValue);
		},

		_handleValueHelpSearchMGRP: function (evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter(
				"MATKL",
				sap.ui.model.FilterOperator.Contains, sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},

		_handleValueHelpCloseMGRP: function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
		},

		handleValueHelpPGRP: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();

			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._valueHelpDialogPGRP) {
				this._valueHelpDialogPGRP = sap.ui.xmlfragment(
					"zfiori.zmaterial_master.fragments.PurchasingGroup",
					this
				);
				this.getView().addDependent(this._valueHelpDialogPGRP);
			}

			// create a filter for the binding
			this._valueHelpDialogPGRP.getBinding("items").filter([new Filter(
				"EKGRP",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);

			// open value help dialog filtered by the input value
			this._valueHelpDialogPGRP.open(sInputValue);
		},

		_handleValueHelpSearchPGRP: function (evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter(
				"EKGRP",
				sap.ui.model.FilterOperator.Contains, sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},

		_handleValueHelpClosePGRP: function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
		},

		handleValueHelpNE: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();

			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._valueHelpDialogNE) {
				this._valueHelpDialogNE = sap.ui.xmlfragment(
					"zfiori.zmaterial_master.fragments.NationlExport",
					this
				);
				this.getView().addDependent(this._valueHelpDialogNE);
			}

			// create a filter for the binding
			this._valueHelpDialogNE.getBinding("items").filter([new Filter(
				"VTWEG",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);

			// open value help dialog filtered by the input value
			this._valueHelpDialogNE.open(sInputValue);
		},

		_handleValueHelpSearchNE: function (evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter(
				"VTWEG",
				sap.ui.model.FilterOperator.Contains, sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},

		_handleValueHelpCloseNE: function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
		},

		handleValueHelPPMRP: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();

			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._valueHelpDialogPPMRP) {
				this._valueHelpDialogPPMRP = sap.ui.xmlfragment(
					"zfiori.zmaterial_master.fragments.PPMRP",
					this
				);
				this.getView().addDependent(this._valueHelpDialogPPMRP);
			}

			// create a filter for the binding
			this._valueHelpDialogPPMRP.getBinding("items").filter([new Filter(
				"DISPO",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);

			// open value help dialog filtered by the input value
			this._valueHelpDialogPPMRP.open(sInputValue);
		},
		_handleValueHelpSearchPPMRP: function (evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter(
				"DISPO",
				sap.ui.model.FilterOperator.Contains, sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},
		_handleValueHelpClosePPMRP: function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
		},

		handleValueHelPPMRPG: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();
			//debugger;
			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._valueHelpDialogPPMRPG) {
				this._valueHelpDialogPPMRPG = sap.ui.xmlfragment(
					"zfiori.zmaterial_master.fragments.PPMRPG",
					this
				);
				this.getView().addDependent(this._valueHelpDialogPPMRPG);
			}

			// create a filter for the binding
			this._valueHelpDialogPPMRPG.getBinding("items").filter([new Filter(
				"DISGR",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);

			// open value help dialog filtered by the input value
			this._valueHelpDialogPPMRPG.open(sInputValue);
		},
		_handleValueHelpSearchPPMRPG: function (evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter(
				"DISGR",
				sap.ui.model.FilterOperator.Contains, sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},
		_handleValueHelpClosePPMRPG: function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
		},

		handleValueHelpPPPSL: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();

			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._valueHelpDialogPPPSL) {
				this._valueHelpDialogPPPSL = sap.ui.xmlfragment(
					"zfiori.zmaterial_master.fragments.PPProductionStorageloc",
					this
				);
				this.getView().addDependent(this._valueHelpDialogPPPSL);
			}

			// create a filter for the binding
			this._valueHelpDialogPPPSL.getBinding("items").filter([new Filter(
				"LGORT",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);

			// open value help dialog filtered by the input value
			this._valueHelpDialogPPPSL.open(sInputValue);
		},
		_handleValueHelpSearchPPPSL: function (evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter(
				"LGORT",
				sap.ui.model.FilterOperator.Contains, sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},
		_handleValueHelpClosePPPSL: function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
		},

		handleValueHelpPPPS: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();

			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._valueHelpDialogPPPS) {
				this._valueHelpDialogPPPS = sap.ui.xmlfragment(
					"zfiori.zmaterial_master.fragments.PPProductionScheduler",
					this
				);
				this.getView().addDependent(this._valueHelpDialogPPPS);
			}

			// create a filter for the binding
			this._valueHelpDialogPPPS.getBinding("items").filter([new Filter(
				"FEVOR",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);

			// open value help dialog filtered by the input value
			this._valueHelpDialogPPPS.open(sInputValue);
		},
		_handleValueHelpSearchPPPS: function (evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter(
				"FEVOR",
				sap.ui.model.FilterOperator.Contains, sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},
		_handleValueHelpClosePPPS: function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
		},

		handleValueHelpPPPI: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();

			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._valueHelpDialogPPPI) {
				this._valueHelpDialogPPPI = sap.ui.xmlfragment(
					"zfiori.zmaterial_master.fragments.PPPeriodIndicator",
					this
				);
				this.getView().addDependent(this._valueHelpDialogPPPI);
			}

			// create a filter for the binding
			this._valueHelpDialogPPPI.getBinding("items").filter([new Filter(
				"WGBEZ",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);

			// open value help dialog filtered by the input value
			this._valueHelpDialogPPPI.open(sInputValue);
		},
		_handleValueHelpSearchPPPI: function (evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter(
				"MATKL",
				sap.ui.model.FilterOperator.Contains, sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},
		_handleValueHelpClosePPPI: function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
		},

		handleValueHelpPPT: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();

			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._valueHelpDialogPPT) {
				this._valueHelpDialogPPT = sap.ui.xmlfragment(
					"zfiori.zmaterial_master.fragments.PPType",
					this
				);
				this.getView().addDependent(this._valueHelpDialogPPT);
			}

			// create a filter for the binding
			this._valueHelpDialogPPT.getBinding("items").filter([new Filter(
				"DISMM",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);

			// open value help dialog filtered by the input value
			this._valueHelpDialogPPT.open(sInputValue);
		},
		_handleValueHelpSearchPPT: function (evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter(
				"DISMM",
				sap.ui.model.FilterOperator.Contains, sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},
		_handleValueHelpClosePPT: function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
		},

		handleValueHelpPPLS: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();

			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._valueHelpDialogPPLS) {
				this._valueHelpDialogPPLS = sap.ui.xmlfragment(
					"zfiori.zmaterial_master.fragments.PPLotSize",
					this
				);
				this.getView().addDependent(this._valueHelpDialogPPLS);
			}

			// create a filter for the binding
			this._valueHelpDialogPPLS.getBinding("items").filter([new Filter(
				"DISLS",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);

			// open value help dialog filtered by the input value
			this._valueHelpDialogPPLS.open(sInputValue);
		},
		_handleValueHelpSearchPPLS: function (evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter(
				"DISLS",
				sap.ui.model.FilterOperator.Contains, sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},
		_handleValueHelpClosePPLS: function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
		},

		handleValueHelpPPSPT: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();

			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._valueHelpDialogPPSPT) {
				this._valueHelpDialogPPSPT = sap.ui.xmlfragment(
					"zfiori.zmaterial_master.fragments.PPSpecialProcurementType",
					this
				);
				this.getView().addDependent(this._valueHelpDialogPPSPT);
			}

			// create a filter for the binding
			this._valueHelpDialogPPSPT.getBinding("items").filter([new Filter(
				"SOBSL",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);

			// open value help dialog filtered by the input value
			this._valueHelpDialogPPSPT.open(sInputValue);
		},
		_handleValueHelpSearchPPSPT: function (evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter(
				"SOBSL",
				sap.ui.model.FilterOperator.Contains, sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},
		_handleValueHelpClosePPSPT: function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
		},

		handleValueHelpPOU: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();

			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._valueHelpDialogPOU) {
				this._valueHelpDialogPOU = sap.ui.xmlfragment(
					"zfiori.zmaterial_master.fragments.POrderUnit",
					this
				);
				this.getView().addDependent(this._valueHelpDialogPOU);
			}

			// create a filter for the binding
			this._valueHelpDialogPOU.getBinding("items").filter([new Filter(
				"MSEHI",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);

			// open value help dialog filtered by the input value
			this._valueHelpDialogPOU.open(sInputValue);
		},
		_handleValueHelpSearchPOU: function (evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter(
				"MSEHI",
				sap.ui.model.FilterOperator.Contains, sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},
		_handleValueHelpClosePOU: function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
		},

		handleValueHelpPPVK: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();

			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._valueHelpDialogPPVK) {
				this._valueHelpDialogPPVK = sap.ui.xmlfragment(
					"zfiori.zmaterial_master.fragments.PPurchValueKey",
					this
				);
				this.getView().addDependent(this._valueHelpDialogPPVK);
			}

			// create a filter for the binding
			this._valueHelpDialogPPVK.getBinding("items").filter([new Filter(
				"EKWSL",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);

			// open value help dialog filtered by the input value
			this._valueHelpDialogPPVK.open(sInputValue);
		},
		_handleValueHelpSearchPPVK: function (evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter(
				"EKWSL",
				sap.ui.model.FilterOperator.Contains, sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},
		_handleValueHelpClosePPVK: function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
		},

		handleValueHelpBUVK: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();

			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._valueHelpDialogBUVK) {
				this._valueHelpDialogBUVK = sap.ui.xmlfragment(
					"zfiori.zmaterial_master.fragments.BUVarianceKey",
					this
				);
				this.getView().addDependent(this._valueHelpDialogBUVK);
			}

			// create a filter for the binding
			this._valueHelpDialogBUVK.getBinding("items").filter([new Filter(
				"AWSLS",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);

			// open value help dialog filtered by the input value
			this._valueHelpDialogBUVK.open(sInputValue);
		},
		_handleValueHelpSearchBUVK: function (evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter(
				"AWSLS",
				sap.ui.model.FilterOperator.Contains, sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},
		_handleValueHelpCloseBUVK: function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
		},

		handleValueHelpFIBUVK: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();

			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._valueHelpDialogFIBUVK) {
				this._valueHelpDialogFIBUVK = sap.ui.xmlfragment(
					"zfiori.zmaterial_master.fragments.FIBUvaluationkey",
					this
				);
				this.getView().addDependent(this._valueHelpDialogFIBUVK);
			}

			// create a filter for the binding
			this._valueHelpDialogFIBUVK.getBinding("items").filter([new Filter(
				"VAL_CLASS",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);

			// open value help dialog filtered by the input value
			this._valueHelpDialogFIBUVK.open(sInputValue);
		},
		_handleValueHelpSearchFIBUVK: function (evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter(
				"VAL_CLASS",
				sap.ui.model.FilterOperator.Contains, sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},
		_handleValueHelpCloseFIBUVK: function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var id_Valuation_key = this.byId("id_Valuation_key");
				var Description = this.byId("Description");
				var title = oSelectedItem.getTitle();
				var description = oSelectedItem.getDescription();

				id_Valuation_key.setValue(title);
				Description.setValue(description);
			}
			evt.getSource().getBinding("items").filter([]);
			// 	var productInput = this.byId(this.inputId);
			// 	productInput.setValue(oSelectedItem.getTitle());
			// }
			// evt.getSource().getBinding("items").filter([]);
		},

		handleValueHelpBUHC: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();

			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._valueHelpDialogBUHC) {
				this._valueHelpDialogBUHC = sap.ui.xmlfragment(
					"zfiori.zmaterial_master.fragments.BUHSCode",
					this
				);
				this.getView().addDependent(this._valueHelpDialogBUHC);
			}

			// create a filter for the binding
			this._valueHelpDialogBUHC.getBinding("items").filter([new Filter(
				"STAWN",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);

			// open value help dialog filtered by the input value
			this._valueHelpDialogBUHC.open(sInputValue);
		},
		_handleValueHelpSearchBUHC: function (evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter(
				"STAWN",
				sap.ui.model.FilterOperator.Contains, sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},
		_handleValueHelpCloseBUHC: function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
		},

		createPlantBoxs: function (plants, View) {
			var PlantGrid = this.getView().byId("PlantCheckB");
			var allNewPlants = [];

			//Action editable or disable
			//PLANTX selected or unselected
			var isInitiator = false;
			this.pageSections.forEach(function (viewsObj) {
				if (viewsObj.View === "INITVIEW") {
					isInitiator = viewsObj.Enable;
				}
			});
			plants.forEach(function (oPlant) {
				var isEditable = null;
				if (oPlant.ACTION === "E" && isInitiator) {
					isEditable = true;
				} else {
					isEditable = false;
				}
				var isSelected = null;
				if (oPlant.PLANTX === "X") {
					isSelected = true;
				} else {
					isSelected = false;
				}
				allNewPlants.push(new sap.m.CheckBox(oPlant.WERKS, {
					enabled: isEditable,
					selected: isSelected,
					text: oPlant.WERKS
				}));
			});

			//Old Logic
			// enabled: View === "C" ? (oPlant.ACTION === "E" ? true : false) : false,
			// selected: oPlant.ACTION === "R" || oPlant.PLANTX === "X" ? true : false,

			allNewPlants.forEach(function (obj) {
				PlantGrid.addContent(obj);
			});

		},

		onSLOCSync: function (oEvent) {
			var that = this;
			var currentData = this.getView().getModel("dataModel").getData();
			if (this.f4helps.PlantData.length > 0) {
				this.f4helps.PlantData.forEach(function (plantObj) {
					plantObj.PLANTX = sap.ui.getCore().byId(plantObj.WERKS).getSelected() === true ? "X" : "";
				});
			}
			var plantJSON = JSON.stringify(this.f4helps.PlantData);
			dataManagerLib.fetchSLOC(currentData.materialType, currentData.materialGrp, plantJSON, function (response) {
				that.SLOC = JSON.parse(response.Value);
				//console.log(that.SLOC);
				that.SLOC.forEach(function (slocObj) {
					if (slocObj.SLOCX === "X") {
						slocObj.isSelected = true;
					} else {
						slocObj.isSelected = false;
					}
					if (slocObj.ACTION === "E") {
						slocObj.isEditable = true;
					} else {
						slocObj.isEditable = false;
					}
				});
				var SLOCModel = new JSONModel({
					Locations: that.SLOC
				});
				that.getView().setModel(SLOCModel, "SLoc");
			}.bind(this), function (error) {
				if (!this.serviceErrorDialog) {
					this.serviceErrorDialog = new Dialog({
						title: "Error",
						type: "Message",
						state: "Error",
						content: new Text({
							text: "HTTP request failed."
						}),
						beginButton: new Button({
							text: "OK",
							press: function () {
								this.serviceErrorDialog.close();
							}.bind(this)
						})
					});
				}
				this.serviceErrorDialog.open();
			}.bind(this));
		},

		onNavBack: function (oEvent) {
			var oHistory, sPreviousHash;
			oHistory = History.getInstance();
			sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				this.getOwnerComponent().getRouter().navTo("MaterialType", {}, true /*no history*/ );
			}
		},

		enableViews: function (Mtart, then) {
			var that = this;

			var viewsModel = new JSONModel();
			viewsModel.setData({
				pageSections: that.pageSections
			});
			that.getView().setModel(viewsModel, "isEnabledModel");
			dataManagerLib.getViews("02", that.page, Mtart, that.oFormID, function (response) {
				if (response.results.length > 0) {
					var ViewsCanEdit = [];
					response.results.forEach(function (obj) {
						if (obj.Key === "Views") {
							ViewsCanEdit = JSON.parse(obj.Value);
						}
					});

					ViewsCanEdit.forEach(function (objAPIView) {
						that.pageSections.forEach(function (objAppView) {
							// objAppView.Visible = true;
							// objAppView.Enable = true;
							if (objAppView.View === objAPIView.VIEWID) {
								objAppView.Visible = true;
								objAppView.Enable = objAPIView.EDITABLE === "X" ? true : false;
								objAppView.OtherData = objAPIView;
							}
						});
					});
					var isEnabledModel = that.getView().getModel("isEnabledModel");
					isEnabledModel.setData({
						pageSections: that.pageSections
					});
					isEnabledModel.refresh();

					then(that.pageSections);

				}
			}.bind(this), function (error) {
				if (!this.serviceErrorDialog) {
					this.serviceErrorDialog = new Dialog({
						title: "Error",
						type: "Message",
						state: "Error",
						content: new Text({
							text: "HTTP request failed."
						}),
						beginButton: new Button({
							text: "OK",
							press: function () {
								this.serviceErrorDialog.close();
							}.bind(this)
						})
					});
				}
				this.serviceErrorDialog.open();
			}.bind(this));
		},

		onSubmit: function () {
			//var that = this;
			var currentData = this.getView().getModel("dataModel").getData();
			var storageLOCTab = this.getView().byId("tableForSLOC");
			var SLocItems = storageLOCTab.getItems();
			SLocItems.forEach(function (obj, index) {
				this.SLOC[index].SLOCX = obj.getAggregation("cells")[4].getProperty("selected") === true ? "X" : "";
			}.bind(this));

			if (this.f4helps.PlantData.length > 0) {
				this.f4helps.PlantData.forEach(function (plantObj) {
					plantObj.PLANTX = sap.ui.getCore().byId(plantObj.WERKS).getSelected() === true ? "X" : "";
				});
			}
			var INITVIEWHDRDATA_obj = {
				ERSDA: currentData.creationData, //creation date
				FORMNO: currentData.mmFormNumber, //form number
				MAKTX: currentData.materialText, // material description
				MATKL: currentData.materialGrp, //material group
				MATNR: currentData.materialNo, //material number
				MEINS: currentData.baseUnitMeasure, //base unit of measure
				MTART: currentData.materialType, //material type
				NTGEW: currentData.netWeight, //Net Weight
				BRGEW: currentData.grossWeight, //Gross Weight
				SPART: currentData.nationExport, // national export
				XCHPF: currentData.batch === true ? "X" : "" //Batch
			};
			var dialog = new Dialog({
				title: "Confarmation?",
				type: 'Message',
				state: 'Warning',
				content: [
					new sap.m.Label({
						text: 'Do you want to Submit?'
					})
				],
				beginButton: new Button({
					type: sap.m.ButtonType.Emphasized,
					text: 'Yes',
					press: function () {

						dataManagerLib.SubmitObjData(currentData.materialType, INITVIEWHDRDATA_obj, this.f4helps.PlantData, this.SLOC, this.PURCHDATA,
							this.PPVIEWDATA, this.FIVIEWDATA,

							function (response) {
								var resultObj = JSON.parse(response.Return);
								if (resultObj[0].TYPE === "S") {
									this.serviceSuccessDialog = new Dialog({
										title: "Information",
										type: "Message",
										state: "None",
										content: new Text({
											text: resultObj[0].MESSAGE
										}),
										beginButton: new Button({
											text: "OK",
											press: function () {
												this.serviceSuccessDialog.close();
												this.onNavBack();
											}.bind(this)
										})
									});
								} else {
									this.serviceSuccessDialog = new Dialog({
										title: "Information",
										type: "Message",
										state: "None",
										content: new Text({
											text: resultObj[0].MESSAGE
										}),
										beginButton: new Button({
											text: "OK",
											press: function () {
												this.serviceSuccessDialog.close();
											}.bind(this)
										})
									});
								}
								this.serviceSuccessDialog.open();
							}.bind(this),
							function (error) {
								if (!this.serviceErrorDialog) {
									this.serviceErrorDialog = new Dialog({
										title: "Error",
										type: "Message",
										state: "Error",
										content: new Text({
											text: "HTTP request failed."
										}),
										beginButton: new Button({
											text: "OK",
											press: function () {
												this.serviceErrorDialog.close();
											}.bind(this)
										})
									});
								}
								this.serviceErrorDialog.open();
							}.bind(this));

						dialog.close();
					}.bind(this)
				}),
				endButton: new Button({
					text: 'No',
					press: function () {
						dialog.close();
					}
				}),
				afterClose: function () {
					dialog.destroy();
				}
			});
			dialog.open();

			// dataManagerLib.SubmitObjData(currentData.materialType, INITVIEWHDRDATA_obj, this.f4helps.PlantData, this.SLOC, this.PURCHDATA,
			// 	this.PPVIEWDATA, this.FIVIEWDATA,

			// 	function (response) {
			// 		var resultObj = JSON.parse(response.Return);
			// 		if (resultObj[0].TYPE === "S") {
			// 			this.serviceSuccessDialog = new Dialog({
			// 				title: "Information",
			// 				type: "Message",
			// 				state: "None",
			// 				content: new Text({
			// 					text: resultObj[0].MESSAGE
			// 				}),
			// 				beginButton: new Button({
			// 					text: "OK",
			// 					press: function () {
			// 						this.serviceSuccessDialog.close();
			// 						this.onNavBack();
			// 					}.bind(this)
			// 				})
			// 			});
			// 		} else {
			// 			this.serviceSuccessDialog = new Dialog({
			// 				title: "Information",
			// 				type: "Message",
			// 				state: "None",
			// 				content: new Text({
			// 					text: resultObj[0].MESSAGE
			// 				}),
			// 				beginButton: new Button({
			// 					text: "OK",
			// 					press: function () {
			// 						this.serviceSuccessDialog.close();
			// 					}.bind(this)
			// 				})
			// 			});
			// 		}
			// 		this.serviceSuccessDialog.open();
			// 	}.bind(this),
			// 	function (error) {
			// 		if (!this.serviceErrorDialog) {
			// 			this.serviceErrorDialog = new Dialog({
			// 				title: "Error",
			// 				type: "Message",
			// 				state: "Error",
			// 				content: new Text({
			// 					text: "HTTP request failed."
			// 				}),
			// 				beginButton: new Button({
			// 					text: "OK",
			// 					press: function () {
			// 						this.serviceErrorDialog.close();
			// 					}.bind(this)
			// 				})
			// 			});
			// 		}
			// 		this.serviceErrorDialog.open();
			// 	}.bind(this));

			// }
		},

		onApprove: function () {
			if (this.Workitem === null || this.TopWorkitem === null) {
				if (!this.noApproversDialog) {
					this.noApproversDialog = new Dialog({
						title: "Information",
						type: "Message",
						state: "None",
						content: new Text({
							text: "User can't approve this request."
						}),
						beginButton: new Button({
							text: "OK",
							press: function () {
								this.noApproversDialog.close();
							}.bind(this)
						})
					});
				}
				this.noApproversDialog.open();
			} else {
				var currentData = this.getView().getModel("dataModel").getData();
				var SDVIEWData = this.getView().getModel("SDVIEWModel").getData();
				var PURCHVIEWData = this.getView().getModel("PURCHVIEWModel").getData();
				var PPVIEWData = this.getView().getModel("PPVIEWModel").getData();
				var QMVIEWData = this.getView().getModel("QMVIEWModel").getData();
				var FIVIEWData = this.getView().getModel("FIVIEWModel").getData();

				var storageLOCTab = this.getView().byId("tableForSLOC");
				var SLocItems = storageLOCTab.getItems();
				SLocItems.forEach(function (obj, index) {
					this.SLOC[index].SLOCX = obj.getAggregation("cells")[4].getProperty("selected") === true ? "X" : "";
				}.bind(this));
				var INITVIEWHDRDATA_obj = {
					ERSDA: currentData.creationData, //creation date
					FORMNO: currentData.mmFormNumber, //form number
					MAKTX: currentData.materialText, // material description
					MATKL: currentData.materialGrp, //material group
					MATNR: currentData.materialNo, //material number
					MEINS: currentData.baseUnitMeasure, //base unit of measure
					MTART: currentData.materialType, //material type
					NTGEW: currentData.netWeight, //Net Weight
					BRGEW: currentData.grossWeight, //Gross Weight
					SPART: currentData.nationExport, // national export
					XCHPF: currentData.batch === true ? "X" : "" //Batch
				};

				var dialog = new Dialog({
					title: "Confirmation",
					type: 'Message',
					state: 'Warning',
					content: [
						new sap.m.Text({
							text: 'Do you want to Approve?'
						}),
					],
					beginButton: new Button({
						type: sap.m.ButtonType.Emphasized,
						text: 'Yes',
						press: function () {
							dataManagerLib.ApproveREQ(
								currentData.materialType,
								INITVIEWHDRDATA_obj,
								SDVIEWData,
								PURCHVIEWData,
								PPVIEWData,
								QMVIEWData,
								FIVIEWData,
								this.f4helps.PlantData,
								this.SLOC,
								this.Workitem.toString(),
								this.TopWorkitem.toString(),
								"001",
								function (response) {
									var resultObj = JSON.parse(response.Return);
									if (resultObj[0].TYPE === "S") {
										this.serviceSuccessDialog = new Dialog({
											title: "Information",
											type: "Message",
											state: "None",
											content: new Text({
												text: resultObj[0].MESSAGE
											}),
											beginButton: new Button({
												text: "OK",
												press: function () {
													window.close();
												}.bind(this)
											})
										});
									} else {
										this.serviceSuccessDialog = new Dialog({
											title: "Information",
											type: "Message",
											state: "None",
											content: new Text({
												text: resultObj[0].MESSAGE
											}),
											beginButton: new Button({
												text: "OK",
												press: function () {
													this.serviceSuccessDialog.close();
												}.bind(this)
											})
										});
									}
									this.serviceSuccessDialog.open();
								}.bind(this),
								function (error) {
									if (!this.serviceErrorDialog) {
										this.serviceErrorDialog = new Dialog({
											title: "Error",
											type: "Message",
											state: "Error",
											content: new Text({
												text: "HTTP request failed."
											}),
											beginButton: new Button({
												text: "OK",
												press: function () {
													this.serviceErrorDialog.close();
												}.bind(this)
											})
										});
									}
									this.serviceErrorDialog.open();
								}.bind(this));

							dialog.close();
						}.bind(this)
					}),
					endButton: new Button({
						text: 'No',
						press: function () {
							dialog.close();
						}
					}),
					afterClose: function () {
						dialog.destroy();
					}
				});
				dialog.open();

			}
		},

		onReject: function (oEvent) {
			if (this.Approvers.length < 1 || this.Workitem === null || this.TopWorkitem === null) {
				if (!this.noApproversDialog) {
					this.noApproversDialog = new Dialog({
						title: "Information",
						type: "Message",
						state: "None",
						content: new Text({
							text: "User can't reject this request."
						}),
						beginButton: new Button({
							text: "OK",
							press: function () {
								this.noApproversDialog.close();
							}.bind(this)
						})
					});
				}
				this.noApproversDialog.open();
			} else {
				var Reject = {
					rejectLevel: 0,
					rejectText: ""
				};
				var RejectModel = new JSONModel(Reject);
				this.getView().setModel(RejectModel, "RejectModel");
				// create value help dialog
				if (!this.RejectDialog) {
					this.RejectDialog = sap.ui.xmlfragment(
						"zfiori.zmaterial_master.fragments.RejectForm",
						this
					);
					this.getView().addDependent(this.RejectDialog);
				}
				// open value help dialog filtered by the input value
				this.RejectDialog.open();
			}
		},

		onOkReject: function (oEvent) {

			//var that = this;
			var RejectModel = this.getView().getModel("RejectModel").getData();
			var RejectText = RejectModel.rejectText;
			var RejectLevel = {};
			this.Approvers.forEach(function (apvObj) {
				if (apvObj.ORGEH === parseInt(RejectModel.rejectLevel, 0)) {
					RejectLevel = apvObj;
				}
			});
			var currentData = this.getView().getModel("dataModel").getData();
			var SDVIEWData = this.getView().getModel("SDVIEWModel").getData();
			var PURCHVIEWData = this.getView().getModel("PURCHVIEWModel").getData();
			var PPVIEWData = this.getView().getModel("PPVIEWModel").getData();
			var QMVIEWData = this.getView().getModel("QMVIEWModel").getData();
			var FIVIEWData = this.getView().getModel("FIVIEWModel").getData();

			var storageLOCTab = this.getView().byId("tableForSLOC");
			var SLocItems = storageLOCTab.getItems();
			SLocItems.forEach(function (obj, index) {
				this.SLOC[index].SLOCX = obj.getAggregation("cells")[4].getProperty("selected") === true ? "X" : "";
			}.bind(this));

			if (RejectText === "") {
				MessageToast.show("Fill Comment.");
				return false;
			}

			var INITVIEWHDRDATA_obj = {
				ERSDA: currentData.creationData, //creation date
				FORMNO: currentData.mmFormNumber, //form number
				MAKTX: currentData.materialText, // material description
				MATKL: currentData.materialGrp, //material group
				MATNR: currentData.materialNo, //material number
				MEINS: currentData.baseUnitMeasure, //base unit of measure
				MTART: currentData.materialType, //material type
				NTGEW: currentData.netWeight, //Net Weight
				BRGEW: currentData.grossWeight, //Gross Weight
				SPART: currentData.nationExport, // national export
				XCHPF: currentData.batch === true ? "X" : "" //Batch
			};
			var dialog = new Dialog({
				title: 'Confirm Rejection',
				type: 'Message',
				state: 'Error',
				content: [
					new sap.m.Label({
						text: 'Do you want to reject? '
					})
				],
				beginButton: new Button({
					type: sap.m.ButtonType.Emphasized,
					text: 'Submit',
					press: function () {

						dataManagerLib.RejectREQ(
							currentData.materialType,
							INITVIEWHDRDATA_obj,
							SDVIEWData,
							PURCHVIEWData,
							PPVIEWData,
							QMVIEWData,
							FIVIEWData,
							this.f4helps.PlantData,
							this.SLOC,
							this.Workitem.toString(),
							this.TopWorkitem.toString(),
							"002",
							RejectLevel,
							RejectText,
							function (response) {
								var resultObj = JSON.parse(response.Return);
								if (resultObj[0].TYPE === "S") {
									this.serviceSuccessDialog = new Dialog({
										title: "Information",
										type: "Message",
										state: "None",
										content: new Text({
											text: resultObj[0].MESSAGE
												// text: "Do you want to Reject ?"
										}),
										beginButton: new Button({
											text: "ok",
											press: function () {
												window.close();
											}.bind(this)
										}),

									});
								} else {
									this.serviceSuccessDialog = new Dialog({
										title: "Information",
										type: "Message",
										state: "None",
										content: new Text({
											text: resultObj[0].MESSAGE
												// text: "Do you want to Reject ?"
										}),
										beginButton: new Button({
											text: "ok",
											press: function () {
												this.serviceSuccessDialog.close();
											}.bind(this)
										}),

									});
								}
								this.serviceSuccessDialog.open();
							}.bind(this),
							function (error) {
								if (!this.serviceErrorDialog) {
									this.serviceErrorDialog = new Dialog({
										title: "Error",
										type: "Message",
										state: "Error",
										content: new Text({
											text: "HTTP request failed."
										}),
										beginButton: new Button({
											text: "OK",
											press: function () {
												this.serviceErrorDialog.close();
											}.bind(this)
										})
									});
								}
								this.serviceErrorDialog.open();
							}.bind(this));

						dialog.close();
					}.bind(this)
				}),
				endButton: new Button({
					text: 'No',
					press: function () {
						dialog.close();
					}
				}),
				afterClose: function () {
					dialog.destroy();
				}
			});
			dialog.open();

			// dataManagerLib.RejectREQ(
			// 	currentData.materialType,
			// 	INITVIEWHDRDATA_obj,
			// 	SDVIEWData,
			// 	PURCHVIEWData,
			// 	PPVIEWData,
			// 	QMVIEWData,
			// 	FIVIEWData,
			// 	this.f4helps.PlantData,
			// 	this.SLOC,
			// 	this.Workitem.toString(),
			// 	this.TopWorkitem.toString(),
			// 	"002",
			// 	RejectLevel,
			// 	RejectText,
			// 	function (response) {
			// 		var resultObj = JSON.parse(response.Return);
			// 		if (resultObj[0].TYPE === "S") {
			// 			this.serviceSuccessDialog = new Dialog({
			// 				title: "Information",
			// 				type: "Message",
			// 				state: "None",
			// 				content: new Text({
			// 					text: resultObj[0].MESSAGE
			// 						// text: "Do you want to Reject ?"
			// 				}),
			// 				beginButton: new Button({
			// 					text: "ok",
			// 					press: function () {
			// 						window.close();
			// 					}.bind(this)
			// 				}),

			// 			});
			// 		} else {
			// 			this.serviceSuccessDialog = new Dialog({
			// 				title: "Information",
			// 				type: "Message",
			// 				state: "None",
			// 				content: new Text({
			// 					text: resultObj[0].MESSAGE
			// 						// text: "Do you want to Reject ?"
			// 				}),
			// 				beginButton: new Button({
			// 					text: "ok",
			// 					press: function () {
			// 						this.serviceSuccessDialog.close();
			// 					}.bind(this)
			// 				}),

			// 			});
			// 		}
			// 		this.serviceSuccessDialog.open();
			// 	}.bind(this),
			// 	function (error) {
			// 		if (!this.serviceErrorDialog) {
			// 			this.serviceErrorDialog = new Dialog({
			// 				title: "Error",
			// 				type: "Message",
			// 				state: "Error",
			// 				content: new Text({
			// 					text: "HTTP request failed."
			// 				}),
			// 				beginButton: new Button({
			// 					text: "OK",
			// 					press: function () {
			// 						this.serviceErrorDialog.close();
			// 					}.bind(this)
			// 				})
			// 			});
			// 		}
			// 		this.serviceErrorDialog.open();
			// 	}.bind(this));

		},

		onComplete: function (oEvent) {
			if (this.Workitem === null || this.TopWorkitem === null) {
				if (!this.noApproversDialog) {
					this.noApproversDialog = new Dialog({
						title: "Information",
						type: "Message",
						state: "None",
						content: new Text({
							text: "User can't delete this request."
						}),
						beginButton: new Button({
							text: "OK",
							press: function () {
								this.noApproversDialog.close();
							}.bind(this)
						})
					});
				}
				this.noApproversDialog.open();
			} else {
				var that = this;
				//var RejectModel = this.getView().getModel("RejectModel").getData();
				//var RejectText = RejectModel.rejectText;
				//var RejectLevel = {};
				// this.Approvers.forEach(function (apvObj) {
				// 	if (apvObj.ORGEH === parseInt(RejectModel.rejectLevel, 0)) {
				// 		RejectLevel = apvObj;
				// 	}
				// });
				var currentData = this.getView().getModel("dataModel").getData();
				var SDVIEWData = this.getView().getModel("SDVIEWModel").getData();
				var PURCHVIEWData = this.getView().getModel("PURCHVIEWModel").getData();
				var PPVIEWData = this.getView().getModel("PPVIEWModel").getData();
				var QMVIEWData = this.getView().getModel("QMVIEWModel").getData();
				var FIVIEWData = this.getView().getModel("FIVIEWModel").getData();

				var storageLOCTab = this.getView().byId("tableForSLOC");
				var SLocItems = storageLOCTab.getItems();
				SLocItems.forEach(function (obj, index) {
					this.SLOC[index].SLOCX = obj.getAggregation("cells")[4].getProperty("selected") === true ? "X" : "";
				}.bind(this));

				// if (RejectText === "") {
				// 	MessageToast.show("Fill Comment.");
				// 	return false;
				// }

				var INITVIEWHDRDATA_obj = {
					ERSDA: currentData.creationData, //creation date
					FORMNO: currentData.mmFormNumber, //form number
					MAKTX: currentData.materialText, // material description
					MATKL: currentData.materialGrp, //material group
					MATNR: currentData.materialNo, //material number
					MEINS: currentData.baseUnitMeasure, //base unit of measure
					MTART: currentData.materialType, //material type
					NTGEW: currentData.netWeight, //Net Weight
					BRGEW: currentData.grossWeight, //Gross Weight
					SPART: currentData.nationExport, // national export
					XCHPF: currentData.batch === true ? "X" : "" //Batch
				};
				var dialog = new Dialog({
					title: 'Confirm Rejection',
					type: 'Message',
					state: 'Error',
					content: [
						new sap.m.Label({
							text: 'Do you want to delete request? '
						})
					],
					beginButton: new Button({
						type: sap.m.ButtonType.Emphasized,
						text: 'Submit',
						press: function () {

							dataManagerLib.RejectREQ(
								currentData.materialType,
								INITVIEWHDRDATA_obj,
								SDVIEWData,
								PURCHVIEWData,
								PPVIEWData,
								QMVIEWData,
								FIVIEWData,
								this.f4helps.PlantData,
								this.SLOC,
								this.Workitem.toString(),
								this.TopWorkitem.toString(),
								"002",
								"0",
								"",
								function (response) {
									var resultObj = JSON.parse(response.Return);
									if (resultObj[0].TYPE === "S") {
										this.serviceSuccessDialog = new Dialog({
											title: "Information",
											type: "Message",
											state: "None",
											content: new Text({
												text: resultObj[0].MESSAGE
													// text: "Do you want to Reject ?"
											}),
											beginButton: new Button({
												text: "ok",
												press: function () {
													window.close();
												}.bind(this)
											}),

										});
									} else {
										this.serviceSuccessDialog = new Dialog({
											title: "Information",
											type: "Message",
											state: "None",
											content: new Text({
												text: resultObj[0].MESSAGE
													// text: "Do you want to Reject ?"
											}),
											beginButton: new Button({
												text: "ok",
												press: function () {
													this.serviceSuccessDialog.close();
												}.bind(this)
											}),

										});
									}
									this.serviceSuccessDialog.open();
								}.bind(this),
								function (error) {
									if (!this.serviceErrorDialog) {
										this.serviceErrorDialog = new Dialog({
											title: "Error",
											type: "Message",
											state: "Error",
											content: new Text({
												text: "HTTP request failed."
											}),
											beginButton: new Button({
												text: "OK",
												press: function () {
													this.serviceErrorDialog.close();
												}.bind(this)
											})
										});
									}
									this.serviceErrorDialog.open();
								}.bind(this));

							dialog.close();
						}.bind(this)
					}),
					endButton: new Button({
						text: 'No',
						press: function () {
							dialog.close();
						}
					}),
					afterClose: function () {
						dialog.destroy();
					}
				});
				dialog.open();
			}
		},

		onOkComplete: function (oEvent) {

		},

		onCloseReject: function (oEvent) {
			this.RejectDialog.close();
		},

		onBeforeRendering: function () {

		},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf zfiori.zmaterial_master.view.MaterialDetails
		 */
		onAfterRendering: function () {

		},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf zfiori.zmaterial_master.view.MaterialDetails
		 */
		onExit: function () {

		}

	});

});