sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device"
], function (JSONModel, Device) {
	"use strict";
	var _modelBase = null;
	return {

		init: function (oDataModel) {
			_modelBase = oDataModel;
			_modelBase.setCountSupported(false);
		},

		getoDataModel: function () {
			return _modelBase;
		},

		oModelRefresh: function () {
			_modelBase.refresh(true, false);
		},

		_getOData: function (sPath, oContext, oUrlParams, successCallback, errorCallback) {
			_modelBase.read(sPath, oContext, oUrlParams, true, function (response) {
				successCallback(response);
			}, function (response) {
				errorCallback(response);
			});
		},

		_postData: function (sPath, oContext, sucessCallback, errorCallback) {
			_modelBase.create(sPath, oContext, null, function (response) {
				sucessCallback(response);
			}, function (response) {
				errorCallback(response);
			});
		},

		getf4Help: function (successCallback, errorCallback) {

			var sPath = "Query_matcrdataSet?$filter=Appcat eq '02' and Apptyp eq 'I' and SrvCall eq ''";

			this._getOData(sPath, null, null, function (objResponse) {
				var oResult = objResponse;
				successCallback(oResult);
			}, function (objResponse) {
				errorCallback(objResponse);
			});
		},

		getFormData: function (AppCat, formNumber, successCallback, errorCallback) {

			var sPath = "Query_matcrdataSet?$filter=Appcat eq '" + AppCat + "' and Apptyp eq 'A' and SrvCall eq 'INIT' and Formno eq '" +
				formNumber + "'";

			this._getOData(sPath, null, null, function (objResponse) {
				var oResult = objResponse;
				successCallback(oResult);
			}, function (objResponse) {
				errorCallback(objResponse);
			});
		},

		getViews: function (AppCat, page, Mtart, formNo, successCallback, errorCallback) {

			var pageType = page.Create === true ? "I" : "A";
			var formNumber = page.Create === true ? "" : formNo;
			var sPath = "Query_matcrdataSet?$filter=Appcat eq '" + AppCat + "' and Apptyp eq '" + pageType +
				"' and SrvCall eq 'VIEW' and Mtart eq '" + Mtart +
				"' and Formno eq '" + formNumber + "'";

			this._getOData(sPath, null, null, function (objResponse) {
				var oResult = objResponse;
				successCallback(oResult);
			}, function (objResponse) {
				errorCallback(objResponse);
			});
		},

		copyMatnr: function (matnr, Mtart, successCallback, errorCallback) {

			var sPath = "Query_matcrdataSet?$filter=Appcat eq '02' and Apptyp eq 'I' and SrvCall eq 'COPY' and Matnr eq '" +
				matnr + "'and Mtart eq '" + Mtart + "'";

			this._getOData(sPath, null, null, function (objResponse) {
				var oResult = objResponse;
				successCallback(oResult);
			}, function (objResponse) {
				errorCallback(objResponse);
			});
		},

		FGcopyMatnr: function (matnr, successCallback, errorCallback) {

			var sPath = "Query_matcrdataSet?$filter=Appcat eq '01' and Apptyp eq 'I' and SrvCall eq 'COPY' and Matnr eq '" +
				matnr + "'";

			this._getOData(sPath, null, null, function (objResponse) {
				var oResult = objResponse;
				successCallback(oResult);
			}, function (objResponse) {
				errorCallback(objResponse);
			});
		},

		initMatnr: function (mtart, successCallback, errorCallback) {

			var sPath = "Query_matcrdataSet?$filter=Appcat eq '02' and Apptyp eq 'I' and SrvCall eq 'INIT' and Mtart eq '" +
				mtart + "'";

			this._getOData(sPath, null, null, function (objResponse) {
				var oResult = objResponse;
				successCallback(oResult);
			}, function (objResponse) {
				errorCallback(objResponse);
			});
		},

		FGinitMatnr: function (mtart, successCallback, errorCallback) {

			var sPath = "Query_matcrdataSet?$filter=Appcat eq '01' and Apptyp eq 'I' and SrvCall eq 'INIT' and Mtart eq '" +
				mtart + "'";

			this._getOData(sPath, null, null, function (objResponse) {
				var oResult = objResponse;
				successCallback(oResult);
			}, function (objResponse) {
				errorCallback(objResponse);
			});
		},

		fetchSLOC: function (Mtart, Matkl, plants, sucessCallback, errorCallback) {
			var sPath = "slocDataSet";
			var obj = {
				"Appcat": "02",
				"Apptyp": "I",
				"Mtart": Mtart,
				"Matkl": Matkl === null ? "" : Matkl,
				"IPlants": plants,
				"SrvCall": "SLOC"
			};

			this._postData(sPath, obj, function (objResponse) {
				sucessCallback(objResponse);
			}, function (objResponse) {
				errorCallback(objResponse);
			});
		},

		FGfetchSLOC: function (Mtart, Matkl, plants, sucessCallback, errorCallback) {
			var sPath = "slocDataSet";
			var obj = {
				"Appcat": "01",
				"Apptyp": "A",
				"Mtart": Mtart,
				"Matkl": Matkl === null ? "" : Matkl,
				"IPlants": plants,
				"SrvCall": "SLOC"
			};

			this._postData(sPath, obj, function (objResponse) {
				sucessCallback(objResponse);
			}, function (objResponse) {
				errorCallback(objResponse);
			});
		},

		SubmitObjData: function (Mtart, INITVIEWHDRDATA, PlantData, SLOCData, PURCHDATA, PPVIEWDATA, FIVIEWDATA, sucessCallback, errorCallback) {
			var INITVIEWHDRDATA_JSON = JSON.stringify(INITVIEWHDRDATA);
			var PlantData_JSON = JSON.stringify(PlantData);
			var SLOCData_JSON = JSON.stringify(SLOCData);
			var PURCHDATA_JSON = JSON.stringify(PURCHDATA);
			var PPVIEWDATA_JSON = JSON.stringify(PPVIEWDATA);
			var FIVIEWDATA_JSON = JSON.stringify(FIVIEWDATA);
			// var QMVIEWDATA_JSON = JSON.stringify(QMVIEWDATA);
			// var SDVIEWDATA_JSON = JSON.stringify(SDVIEW);
			// var CMVIEWDATA_JSON = JSON.stringify(CMVIEW);

			var sPath = "Create_MatcrhdrSet";
			var obj = {
				"Appcat": "02",
				"Apptyp": "I",
				"SrvCall": "C",
				"Mtart": Mtart,
				"MatcrData": [{
						"Key": "INITVIEWHDRDATA",
						"Value": INITVIEWHDRDATA_JSON
					}, {
						"Key": "PlantData",
						"Value": PlantData_JSON
					}, {
						"Key": "SLOCData",
						"Value": SLOCData_JSON
					}, {
						"Key": "PURCHVIEWDATA",
						"Value": PURCHDATA_JSON
					},

					{
						"Key": "PPVIEWDATA",
						"Value": PPVIEWDATA_JSON
					}, {
						"Key": "FIVIEWDATA",
						"Value": FIVIEWDATA_JSON
					},
				]
			};

			this._postData(sPath, obj, function (objResponse) {
				sucessCallback(objResponse);
			}, function (objResponse) {
				errorCallback(objResponse);
			});
		},

		FGSubmitObjData: function (Mtart, INITVIEWHDRDATA, PlantData, SLOCData, PPVIEWDATA, FIVIEWDATA, QMVIEWDATA, SDVIEW, CMVIEW,
			sucessCallback, errorCallback) {
			var INITVIEWHDRDATA_JSON = JSON.stringify(INITVIEWHDRDATA);
			var PlantData_JSON = JSON.stringify(PlantData);
			var SLOCData_JSON = JSON.stringify(SLOCData);
			// var PURCHDATA_JSON = JSON.stringify(PURCHDATA);
			var PPVIEWDATA_JSON = JSON.stringify(PPVIEWDATA);
			var FIVIEWDATA_JSON = JSON.stringify(FIVIEWDATA);
			var QMVIEWDATA_JSON = JSON.stringify(QMVIEWDATA);
			var SDVIEWDATA_JSON = JSON.stringify(SDVIEW);
			var CMVIEWDATA_JSON = JSON.stringify(CMVIEW);

			var sPath = "Create_MatcrhdrSet";
			var obj = {
				"Appcat": "01",
				"Apptyp": "I",
				"SrvCall": "C",
				"Mtart": Mtart,
				"MatcrData": [{
						"Key": "INITVIEWHDRDATA",
						"Value": INITVIEWHDRDATA_JSON
					}, {
						"Key": "PlantData",
						"Value": PlantData_JSON
					}, {
						"Key": "SLOCData",
						"Value": SLOCData_JSON
					},
					// {
					// 	"Key": "PURCHDATA",
					// 	"Value": PURCHDATA_JSON
					// },

					{
						"Key": "PPVIEWDATA",
						"Value": PPVIEWDATA_JSON
					}, {
						"Key": "FIVIEWDATA",
						"Value": FIVIEWDATA_JSON
					}, {
						"Key": "QMVIEWDATA",
						"Value": QMVIEWDATA_JSON
					}, {
						"Key": "SDVIEWDATA",
						"Value": SDVIEWDATA_JSON
					}, {
						"Key": "CMVIEWDATA",
						"Value": CMVIEWDATA_JSON
					},
				]
			};

			this._postData(sPath, obj, function (objResponse) {
				sucessCallback(objResponse);
			}, function (objResponse) {
				errorCallback(objResponse);
			});
		},

		ApproveREQ: function (
			Mtart,
			INITVIEWHDRDATA,
			SDVIEWData,
			PURCHVIEWData,
			PPVIEWData,
			QMVIEWData,
			FIVIEWData,
			PlantData,
			SLOC,
			workItem,
			topWorkItem,
			decision,
			sucessCallback, errorCallback) {
			var INITVIEWHDRDATAJSON = JSON.stringify(INITVIEWHDRDATA);
			var SDVIEWDataJSON = JSON.stringify(SDVIEWData);
			var PURCHVIEWDataJSON = JSON.stringify(PURCHVIEWData);
			var PPVIEWDataJSON = JSON.stringify(PPVIEWData);
			var QMVIEWDataJSON = JSON.stringify(QMVIEWData);
			var FIVIEWDataJSON = JSON.stringify(FIVIEWData);
			var PlantDataJSON = JSON.stringify(PlantData);
			var SLOCJSON = JSON.stringify(SLOC);
			var sPath = "Create_MatcrhdrSet";
			var obj = {
				"Appcat": "02",
				"Apptyp": "A",
				"Mtart": Mtart,
				"SrvCall": "DECI",
				"MatcrData": [{
					"Key": "INITVIEWHDRDATA",
					"Value": INITVIEWHDRDATAJSON
				}, {
					"Key": "PlantData",
					"Value": PlantDataJSON
				}, {
					"Key": "SLOCData",
					"Value": SLOCJSON
				}, {
					"Key": "PURCHVIEWDATA",
					"Value": PURCHVIEWDataJSON
				}, {
					"Key": "PPVIEWDATA",
					"Value": PPVIEWDataJSON
				}, {
					"Key": "FIVIEWDATA",
					"Value": FIVIEWDataJSON
				}, {
					"Key": "SDVIEWDATA",
					"Value": SDVIEWDataJSON
				}, {
					"Key": "QMVIEWDATA",
					"Value": QMVIEWDataJSON
				}, {
					"Key": "Workitem",
					"Value": workItem
				}, {
					"Key": "TopWorkitem",
					"Value": topWorkItem
				}, {
					"Key": "Decision",
					"Value": decision
				}]
			};

			this._postData(sPath, obj, function (objResponse) {
				sucessCallback(objResponse);
			}, function (objResponse) {
				errorCallback(objResponse);
			});
		},

		FGApproveREQ: function (
			Mtart,
			INITVIEWHDRDATA,
			CMVIEWData,
			SDVIEWData,
			// PURCHVIEWData,
			PPVIEWData,
			QMVIEWData,
			FIVIEWData,
			PlantData,
			SLOC,
			workItem,
			topWorkItem,
			decision,
			sucessCallback, errorCallback) {
			var INITVIEWHDRDATAJSON = JSON.stringify(INITVIEWHDRDATA);
			var CMVIEWDataJSON = JSON.stringify(CMVIEWData);
			var SDVIEWDataJSON = JSON.stringify(SDVIEWData);
			// var PURCHVIEWDataJSON = JSON.stringify(PURCHVIEWData);
			var PPVIEWDataJSON = JSON.stringify(PPVIEWData);
			var QMVIEWDataJSON = JSON.stringify(QMVIEWData);
			var FIVIEWDataJSON = JSON.stringify(FIVIEWData);
			var PlantDataJSON = JSON.stringify(PlantData);
			var SLOCJSON = JSON.stringify(SLOC);
			var sPath = "Create_MatcrhdrSet";
			var obj = {
				"Appcat": "01",
				"Apptyp": "A",
				"Mtart": Mtart,
				"SrvCall": "DECI",
				"MatcrData": [{
						"Key": "INITVIEWHDRDATA",
						"Value": INITVIEWHDRDATAJSON
					}, {
						"Key": "PlantData",
						"Value": PlantDataJSON
					}, {
						"Key": "SLOCData",
						"Value": SLOCJSON
					}, {
						"Key": "CMVIEWData",
						"Value": CMVIEWDataJSON
					},

					{
						"Key": "PPVIEWDATA",
						"Value": PPVIEWDataJSON
					}, {
						"Key": "FIVIEWDATA",
						"Value": FIVIEWDataJSON
					}, {
						"Key": "SDVIEWDATA",
						"Value": SDVIEWDataJSON
					}, {
						"Key": "QMVIEWDATA",
						"Value": QMVIEWDataJSON
					}, {
						"Key": "Workitem",
						"Value": workItem
					}, {
						"Key": "TopWorkitem",
						"Value": topWorkItem
					}, {
						"Key": "Decision",
						"Value": decision
					}
				]
			};

			this._postData(sPath, obj, function (objResponse) {
				sucessCallback(objResponse);
			}, function (objResponse) {
				errorCallback(objResponse);
			});
		},

		RejectREQ: function (
			Mtart,
			INITVIEWHDRDATA,
			SDVIEWData,
			PURCHVIEWData,
			PPVIEWData,
			QMVIEWData,
			FIVIEWData,
			PlantData,
			SLOC,
			workItem,
			topWorkItem,
			decision,
			RejectionLevel,
			RejectionText,
			sucessCallback, errorCallback) {
			var INITVIEWHDRDATAJSON = JSON.stringify(INITVIEWHDRDATA);
			var SDVIEWDataJSON = JSON.stringify(SDVIEWData);
			var PURCHVIEWDataJSON = JSON.stringify(PURCHVIEWData);
			var PPVIEWDataJSON = JSON.stringify(PPVIEWData);
			var QMVIEWDataJSON = JSON.stringify(QMVIEWData);
			var FIVIEWDataJSON = JSON.stringify(FIVIEWData);
			var PlantDataJSON = JSON.stringify(PlantData);
			var SLOCJSON = JSON.stringify(SLOC);
			var RejectionLevelJSON = JSON.stringify(RejectionLevel);
			var sPath = "Create_MatcrhdrSet";
			var obj = {
				"Appcat": "02",
				"Apptyp": "A",
				"Mtart": Mtart,
				"SrvCall": "DECI",
				"MatcrData": [{
					"Key": "INITVIEWHDRDATA",
					"Value": INITVIEWHDRDATAJSON
				}, {
					"Key": "PlantData",
					"Value": PlantDataJSON
				}, {
					"Key": "SLOCData",
					"Value": SLOCJSON
				}, {
					"Key": "PURCHVIEWDATA",
					"Value": PURCHVIEWDataJSON
				}, {
					"Key": "PPVIEWDATA",
					"Value": PPVIEWDataJSON
				}, {
					"Key": "FIVIEWDATA",
					"Value": FIVIEWDataJSON
				}, {
					"Key": "SDVIEWDATA",
					"Value": SDVIEWDataJSON
				}, {
					"Key": "QMVIEWDATA",
					"Value": QMVIEWDataJSON
				}, {
					"Key": "Workitem",
					"Value": workItem
				}, {
					"Key": "TopWorkitem",
					"Value": topWorkItem
				}, {
					"Key": "Decision",
					"Value": decision
				}, {
					"Key": "Rejagent",
					"Value": RejectionLevelJSON
				}, {
					"Key": "RejText",
					"Value": RejectionText
				}]
			};

			this._postData(sPath, obj, function (objResponse) {
				sucessCallback(objResponse);
			}, function (objResponse) {
				errorCallback(objResponse);
			});
		},

		FGRejectREQ: function (
			Mtart,
			INITVIEWHDRDATA,
			SDVIEWData,
			// PURCHVIEWData,
			PPVIEWData,
			QMVIEWData,
			FIVIEWData,
			PlantData,
			SLOC,
			workItem,
			topWorkItem,
			decision,
			RejectionLevel,
			RejectionText,
			sucessCallback, errorCallback) {
			var INITVIEWHDRDATAJSON = JSON.stringify(INITVIEWHDRDATA);
			var SDVIEWDataJSON = JSON.stringify(SDVIEWData);
			// var PURCHVIEWDataJSON = JSON.stringify(PURCHVIEWData);
			var PPVIEWDataJSON = JSON.stringify(PPVIEWData);
			var QMVIEWDataJSON = JSON.stringify(QMVIEWData);
			var FIVIEWDataJSON = JSON.stringify(FIVIEWData);
			var PlantDataJSON = JSON.stringify(PlantData);
			var SLOCJSON = JSON.stringify(SLOC);
			var RejectionLevelJSON = JSON.stringify(RejectionLevel);
			var sPath = "Create_MatcrhdrSet";
			var obj = {
				"Appcat": "01",
				"Apptyp": "A",
				"Mtart": Mtart,
				"SrvCall": "DECI",
				"MatcrData": [{
						"Key": "INITVIEWHDRDATA",
						"Value": INITVIEWHDRDATAJSON
					}, {
						"Key": "PlantData",
						"Value": PlantDataJSON
					}, {
						"Key": "SLOCData",
						"Value": SLOCJSON
					},
					// {
					// 	"Key": "PURCHVIEWDATA",
					// 	"Value": PURCHVIEWDataJSON
					// },
					{
						"Key": "PPVIEWDATA",
						"Value": PPVIEWDataJSON
					}, {
						"Key": "FIVIEWDATA",
						"Value": FIVIEWDataJSON
					}, {
						"Key": "SDVIEWDATA",
						"Value": SDVIEWDataJSON
					}, {
						"Key": "QMVIEWDATA",
						"Value": QMVIEWDataJSON
					}, {
						"Key": "Workitem",
						"Value": workItem
					}, {
						"Key": "TopWorkitem",
						"Value": topWorkItem
					}, {
						"Key": "Decision",
						"Value": decision
					}, {
						"Key": "Rejagent",
						"Value": RejectionLevelJSON
					}, {
						"Key": "RejText",
						"Value": RejectionText
					}
				]
			};

			this._postData(sPath, obj, function (objResponse) {
				sucessCallback(objResponse);
			}, function (objResponse) {
				errorCallback(objResponse);
			});
		}

	};
});