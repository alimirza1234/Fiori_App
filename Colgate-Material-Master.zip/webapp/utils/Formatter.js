jQuery.sap.declare("zfiori.zmaterial_master.utils.Formatter");

zfiori.zmaterial_master.utils.Formatter = (function () {
	return {
		status: function (sStatus) {

			return sStatus === "Active" ? "Success" : "Warning";
		},
		dateTime: function (sDate, stime) {
			var timeArray = stime.split(":");
			var shours = timeArray[0];
			var smin = timeArray[1];
			var sec = timeArray[2];
			var oDate = new Date(sDate);
			oDate.setHours(shours);
			oDate.setMinutes(smin);
			oDate.setSeconds(sec);

			return oDate.toGMTString();
		},

		setStatusText2: function (value) {

			if (typeof (value) != "undefined") {
				if (value == '1')
					return 'Approved';
				else if (value == '2')
					return 'Rejected';
				else if (value == '3')
					return 'Pending';
				// else if (value == '')
				// return 'Pending';
			}
			return '';
		},
		status1: function (sStatus) {

			if (sStatus === 1) {

				return "Approved";
			} else if (sStatus === 2) {
				return "Rejected";
			} else if (sStatus === 3) {
				return "Pending";
			} else {
				return "None";
			}
		},

		currencyFormate: function (sal) {
			debugger;
			sal = parseFloat(sal).toFixed(2); //2 Decimal Points
			if (sal != "" && sal != undefined && sal != null) {
				if (typeof sal !== 'string') {
					return sal.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
				} else {
					return sal.replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
				}
			}
		},

		attachIcon: function (sValue) {
			if (sValue === "jpg" || sValue === "jpeg" || sValue === "png") {
				return "sap-icon://background";
			}
			if (sValue === "pdf") {
				return "sap-icon://pdf-attachment";
			}
			if (sValue === "application/vnd.openxmlformats-officedocument.wordprocessingml.document" || sValue === "application/msword" || sValue ===
				"doc" || sValue === "docx") {
				return "sap-icon://doc-attachment";
			}
			if (sValue === "plain") {
				return "sap-icon://document-text";
			}
			if (sValue === "vnd.openxmlformats-officedocument.spreadsheetml.sheet" || sValue === "application/vnd.ms-excel" || sValue === "xls" ||
				sValue === "xlsx") {
				return "sap-icon://excel-attachment";
			} else {
				return "sap-icon://document";
			}
		},
		setIcon: function (value) {
			if (typeof (value) != "undefined") {
				if (value == 'APPROVED')
					return 'sap-icon://accept';
				else if (value == 'REJECTED')
					return 'sap-icon://decline';
				else
					return 'sap-icon://pending';
			}
		},

		setStatusText: function (value) {
			if (typeof (value) != "undefined") {
				if (value == '1')
					return 'Approved';
				else if (value == '2')
					return 'Rejected';
				else
					return 'Pending';
			}
			return '';
		},
		setText: function (value) {
			if (typeof (value) != "undefined") {
				if (value == 'APPROVED')
					return 'Approved';
				else if (value == 'REJECTED')
					return 'Rejected';
				else
					return 'Pending';
			}
			return '';
		},

		setState: function (value) {
			if (typeof (value) != "undefined") {
				if (value == '1')
					return sap.ui.core.ValueState.Success;
				else if (value == '2')
					return sap.ui.core.ValueState.Error;
				else
					return sap.ui.core.ValueState.Warning;
			}
		},
		setStateTab: function (value) {
			if (typeof (value) != "undefined") {
				if (value == 'APPROVED')
					return sap.ui.core.ValueState.Success;
				else if (value == 'REJECTED')
					return sap.ui.core.ValueState.Error;
				else
					return sap.ui.core.ValueState.Warning;
			}
		},

	};
}());