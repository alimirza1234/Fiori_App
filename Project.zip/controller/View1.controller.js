sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("com.test.hotkeys.zTest.controller.View1", {
		onInit: function () {
            debugger
		var Json = [
                { "Manpower": [{
                    "Year": 2001,
                    "City": "New York ",
                    "Profit": 120000,
                    "Unit Price": 1117.60,
                    "Units Available": 13076,
                    "Cost": 139033.42,
                    "Revenue": 207685.42,
                    "Units Sold": 4437,
                    "Catogery" : "Export",
                    "Cost12" : "" },
                    {
                    "Year": 2001,
                    "City": "San Francisco ",
                    "Profit": 145000,
                    "Unit Price": 1117.60,
                    "Units Available": 13076,
                    "Cost": 139033.42,
                    "Revenue": 207685.42,
                    "Units Sold": 4437,
                    "Catogery" : "Export",
                    "Cost12" : "" } 
                ]},
                    { "Manpower": [{
                        "Year": 2001,
                        "City": "Washington",
                        "Profit": 170,
                        "Unit Price": 1117.60,
                        "Units Available": 13076,
                        "Cost": 139033.42,
                        "Revenue": 207685.42,
                        "Units Sold": 4437,
                        "Catogery" : "Export",
                        "Cost12" : ""
                    }] }
        ];

            var oModel = new sap.ui.model.json.JSONModel()
            oModel.setData(Json);
            this.getView().setModel(oModel,"MainModel");
            this.changeData(0);
		},
        changeData: function(sPath){
            debugger
            this.getView().bindElement({path:'/'+sPath, model: "MainModel"});
        }
		
	});
});