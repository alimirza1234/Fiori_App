sap.ui.define([
	"TripRequest/Business_Trip/test/unit/controller/App.controller"
], function () {
	"use strict";
});