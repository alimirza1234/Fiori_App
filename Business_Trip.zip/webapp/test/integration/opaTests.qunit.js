/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"TripRequest/Business_Trip/test/integration/AllJourneys"
	], function () {
		QUnit.start();
	});
});