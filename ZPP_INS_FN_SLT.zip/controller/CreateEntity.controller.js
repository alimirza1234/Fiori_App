sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	'sap/m/MessageToast'
], function(Controller, JSONModel, MessageToast) {
	"use strict";

	return Controller.extend("zpp_ins_fn_slt.controller.CreateEntity", {

		_oBinding: {},

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		onInit: function() {
			var that = this;
			this._oViewModel = new JSONModel({
				enableCreate: false,
				delay: 0,
				busy: false,
				mode: "create",
				viewTitle: ""
			});

			this._oODataModel = this.getOwnerComponent().getModel();
			this._oODataModel.setSizeLimit(5000);

			sap.ui.getCore().getMessageManager().registerObject(this.getView(), true);
			var oMessagesModel = sap.ui.getCore().getMessageManager().getMessageModel();
			this._oBinding = new sap.ui.model.Binding(oMessagesModel, "/", oMessagesModel.getContext("/"));
			this._oBinding.attachChange(function(oEvent) {
				var aMessages = oEvent.getSource().getModel().getData();
				for (var i = 0; i < aMessages.length; i++) {
					if (aMessages[i].type === "Error" && !aMessages[i].technical) {
						that._oViewModel.setProperty("/enableCreate", false);
					}
				}
			});
			var sUrl4 = "/sap/opu/odata/sap/ZSN_GOOD_APP_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(sUrl4, true);
			var sPathInquire = "initial_set(IvCall='I')";
			var oItem = [];
			oItem.splice(0, 0, "");
			// var obj_item = {name: 'Tom'};
			oModel.read(sPathInquire, null, null, true, function(success) {
				var user_id = JSON.parse(success.EvJson);
				user_id.forEach(function(obj) {
					if (obj.ZZGROUP === "GROUP A") {
						oItem.push(obj);
					}
				});
				var userModel = new JSONModel(oItem);
				that.getView().setModel(userModel, "userModel");
			}, function(error) {
				MessageToast.show("Users not found");
			});
		},
		///////////////// Custom Methods for Data load, approve and upload

		fShiftChange: function(oEvent) {
			var sValue = this.getView().byId("ddl_Shift").getSelectedKey();
			var oInput = this.getView().byId("SHIFT");
			oInput.setValue(sValue);
		},
		fMachChange: function(oEvent) {
			var sValue = this.getView().byId("ddl_MACHINE_ID").getSelectedKey();
			var oInput = this.getView().byId("MACHINE_ID");
			oInput.setValue(sValue);
			this.getView().byId("MachineDesc").setValue(this.getView().byId("ddl_MACHINE_ID").getSelectedItem().getText());
		},
		fMachStatChange: function(oEvent) {
			var sValue = this.getView().byId("ddl_MACHINE_STAT").getSelectedKey();
			var oInput = this.getView().byId("MACHINE_STAT");
			oInput.setValue(sValue);
			if (sValue === "Ok" || sValue === "Operative") {
				this.getView().byId("ddl_MACHINE_REMARKS").setEnabled(false);
				this.getView().byId("ddl_MESH_INSTAL_VAL").setEnabled(true);
				this.getView().byId("MESH_INSTAL_REM").setEnabled(true);
				this.getView().byId("PROD_TEMP_VAL").setEnabled(true);
				this.getView().byId("PROD_TEMP_REM").setEnabled(true);
				this.getView().byId("POUCH_VERT_VAL").setEnabled(true);
				this.getView().byId("POUCH_VERT_REM").setEnabled(true);
				this.getView().byId("POUCH_TOP_VAL").setEnabled(true);
				this.getView().byId("POUCH_TOP_REM").setEnabled(true);
				this.getView().byId("MFG_DATE_P_VAL").setEnabled(true);
				this.getView().byId("MFG_DATE_P_REM").setEnabled(true);
				this.getView().byId("ddl_CODING_P_VAL").setEnabled(true);
				this.getView().byId("CODING_P_REM").setEnabled(true);
				this.getView().byId("ddl_PRINT_POS_VAL").setEnabled(true);
				this.getView().byId("PRINT_POS_REM").setEnabled(true);
				this.getView().byId("ddl_LICENSE_VAL").setEnabled(true);
				this.getView().byId("LICENSE_REM").setEnabled(true);
				this.getView().byId("ddl_CART_COND_VAL").setEnabled(true);
				this.getView().byId("CART_COND_REM").setEnabled(true);
				this.getView().byId("ddl_MFG_DATE_C_VAL").setEnabled(true);
				this.getView().byId("MFG_DATE_C_REM").setEnabled(true);
				this.getView().byId("ddl_CODING_C_VAL").setEnabled(true);
				this.getView().byId("CODING_C_REM").setEnabled(true);
				this.getView().byId("ddl_CART_STRIP_VAL").setEnabled(true);
				this.getView().byId("CART_STRIP_REM").setEnabled(true);
				this.getView().byId("ddl_PALLET_VAL").setEnabled(true);
				this.getView().byId("PALLET_REM").setEnabled(true);
				this.getView().byId("ddl_GMP_COMP_VAL").setEnabled(true);
				this.getView().byId("GMP_COMP_REM").setEnabled(true);

			} else {
				this.getView().byId("ddl_MACHINE_REMARKS").setEnabled(true);
				this.getView().byId("ddl_MESH_INSTAL_VAL").setEnabled(false);
				this.getView().byId("MESH_INSTAL_REM").setEnabled(false);
				this.getView().byId("PROD_TEMP_VAL").setEnabled(false);
				this.getView().byId("PROD_TEMP_REM").setEnabled(false);
				this.getView().byId("POUCH_VERT_VAL").setEnabled(false);
				this.getView().byId("POUCH_VERT_REM").setEnabled(false);
				this.getView().byId("POUCH_TOP_VAL").setEnabled(false);
				this.getView().byId("POUCH_TOP_REM").setEnabled(false);
				this.getView().byId("MFG_DATE_P_VAL").setEnabled(false);
				this.getView().byId("MFG_DATE_P_REM").setEnabled(false);
				this.getView().byId("ddl_CODING_P_VAL").setEnabled(false);
				this.getView().byId("CODING_P_REM").setEnabled(false);
				this.getView().byId("ddl_PRINT_POS_VAL").setEnabled(false);
				this.getView().byId("PRINT_POS_REM").setEnabled(false);
				this.getView().byId("ddl_LICENSE_VAL").setEnabled(false);
				this.getView().byId("LICENSE_REM").setEnabled(false);
				this.getView().byId("ddl_CART_COND_VAL").setEnabled(false);
				this.getView().byId("CART_COND_REM").setEnabled(false);
				this.getView().byId("ddl_MFG_DATE_C_VAL").setEnabled(false);
				this.getView().byId("MFG_DATE_C_REM").setEnabled(false);
				this.getView().byId("ddl_CODING_C_VAL").setEnabled(false);
				this.getView().byId("CODING_C_REM").setEnabled(false);
				this.getView().byId("ddl_CART_STRIP_VAL").setEnabled(false);
				this.getView().byId("CART_STRIP_REM").setEnabled(false);
				this.getView().byId("ddl_PALLET_VAL").setEnabled(false);
				this.getView().byId("PALLET_REM").setEnabled(false);
				this.getView().byId("ddl_GMP_COMP_VAL").setEnabled(false);
				this.getView().byId("GMP_COMP_REM").setEnabled(false);
			}
		},
		fMachStatRemChange: function(oEvent) {
			var sValue = this.getView().byId("ddl_MACHINE_REMARKS").getSelectedKey();
			var oInput = this.getView().byId("MACHINE_REMARKS");
			oInput.setValue(sValue);
		},
		fMeshInsChange: function(oEvent) {
			var sValue = this.getView().byId("ddl_MESH_INSTAL_VAL").getSelectedKey();
			var oInput = this.getView().byId("MESH_INSTAL_VAL");
			oInput.setValue(sValue);
		},
		fCodingPChange: function(oEvent) {
			var sValue = this.getView().byId("ddl_CODING_P_VAL").getSelectedKey();
			var oInput = this.getView().byId("CODING_P_VAL");
			oInput.setValue(sValue);
		},
		fPrintPChange: function(oEvent) {
			var sValue = this.getView().byId("ddl_PRINT_POS_VAL").getSelectedKey();
			var oInput = this.getView().byId("PRINT_POS_VAL");
			oInput.setValue(sValue);
		},
		fLecNoPChange: function(oEvent) {
			var sValue = this.getView().byId("ddl_LICENSE_VAL").getSelectedKey();
			var oInput = this.getView().byId("LICENSE_VAL");
			oInput.setValue(sValue);
		},
		fCarCondChange: function(oEvent) {
			var sValue = this.getView().byId("ddl_CART_COND_VAL").getSelectedKey();
			var oInput = this.getView().byId("CART_COND_VAL");
			oInput.setValue(sValue);
		},
		fCarStrpChange: function(oEvent) {
			var sValue = this.getView().byId("ddl_CART_STRIP_VAL").getSelectedKey();
			var oInput = this.getView().byId("CART_STRIP_VAL");
			oInput.setValue(sValue);
		},
		fMfgDateChange: function(oEvent) {
			var sValue = this.getView().byId("ddl_MFG_DATE_C_VAL").getSelectedKey();
			var oInput = this.getView().byId("MFG_DATE_C_TEXT");
			oInput.setValue(sValue);
		},
		fCodeCarChange: function(oEvent) {
			var sValue = this.getView().byId("ddl_CODING_C_VAL").getSelectedKey();
			var oInput = this.getView().byId("CODING_C_VAL");
			oInput.setValue(sValue);
		},
		fPalletChange: function(oEvent) {
			var sValue = this.getView().byId("ddl_PALLET_VAL").getSelectedKey();
			var oInput = this.getView().byId("PALLET_VAL");
			oInput.setValue(sValue);
		},
		fGmpCompChange: function(oEvent) {
			var sValue = this.getView().byId("ddl_GMP_COMP_VAL").getSelectedKey();
			var oInput = this.getView().byId("GMP_COMP_VAL");
			oInput.setValue(sValue);
		},
		/**
		 * Event handler (attached declaratively) for the view save button. Saves the changes added by the user.&nbsp;
		 * @function
		 * @public
		 */
		onSave: function() {
			var messagetext = "";
			var Shift = this.getView().byId("SHIFT").getValue();

			if (messagetext !== "") {
				sap.m.MessageBox.show(messagetext + "cannot be null, please fill the values and try again");
			} else {
				var userRequestBody = {
					properties: {
						Shift: Shift
					}
				};

				var oModel = this.getOwnerComponent().getModel();
				var oContext = oModel.createEntry("/ZQC_INS_FN_SLT_TSet", userRequestBody); // ZTB_QM_IPPKL_JRSet
				this.getView().setBindingContext(oContext);
				oModel.setUseBatch(false);
				oModel.submitChanges();
				oModel.setRefreshAfterChange(true);
				this.getOwnerComponent().getRouter().getTargets().display("object");
			}
		},
		onCanel: function(oEvent) {
			var that = this;
			var dialog = new sap.m.Dialog({
				title: 'Confirm',
				type: 'Message',
				content: new sap.m.Text({
					text: 'Are you sure, you want to cancel? You will loose all your noted observations.'
				}),
				beginButton: new sap.m.Button({
					text: 'Ok',
					press: function() {
						// sap.m.MessageToast.show('Submit pressed!');
						that.clearFormdetails();
						dialog.close();
						that.getOwnerComponent().getRouter().getTargets().display("object");
					}
				}),
				endButton: new sap.m.Button({
					text: 'Cancel',
					press: function() {
						dialog.close();
					}
				}),
				afterClose: function() {
					dialog.destroy();
				}
			});

			dialog.open();
		},

		onPress: function(evt) {
			var that = this;
			var messagetext = "";
			var Shift = this.getView().byId("SHIFT").getValue();
			if (Shift === "" || Shift === "0") {
				messagetext = messagetext + "Shift,";
			}

			var BatchNo = this.getView().byId("BATCH_NO_ID").getValue();
			if (BatchNo === "") {
				messagetext = messagetext + " Batch #,";
			}

			var Plant = this.getView().byId("PLANT_ID_ID").getValue();
			if (Plant === "") {
				messagetext = messagetext + " Plant ID,";
			}

			var PlantName = this.getView().byId("PLANT_NAME").getValue();
			if (PlantName === "") {
				messagetext = messagetext + " Plant Name,";
			}

			var WORK_CENTER = this.getView().byId("WORK_CENTER").getValue();
			if (WORK_CENTER === "") {
				messagetext = messagetext + " Work Center,";
			}

			var MatId = this.getView().byId("MATERIAL_ID").getValue();
			if (MatId === "") {
				messagetext = messagetext + " Material ID,";
			}

			var MatDesc = this.getView().byId("MATERIAL_DESC").getValue();
			if (MatDesc === "") {
				messagetext = messagetext + " Material Name,";
			}

			var MACHINE_ID = this.getView().byId("MACHINE_ID").getValue();
			if (MACHINE_ID === "" || MACHINE_ID === "000" || MACHINE_ID === "00000" || MACHINE_ID === "0") {
				messagetext = messagetext + " Machine ID,";
			}

			var MACH_DESC = this.getView().byId("MachineDesc").getValue();
			if (MACHINE_ID === "") {
				messagetext = messagetext + " Machine Name,";
			}

			// var SubmitBy = this.getView().byId("SUBMIT_BY").getValue();
			var Submit = this.getView().byId("SUBMIT_BY").getSelectedItem();
			var SubmitBy = Submit.getText();
			if (SubmitBy === "") {
				messagetext = messagetext + " Inspected By,";
			}

			var InspDept = this.getView().byId("INSPECTION_DEPT").getValue();
			if (InspDept === "") {
				messagetext = messagetext + " Inspection Dept,";
			}

			var ProductionOrder = this.getView().byId("PRODUCTION_ORDER_NO").getValue();
			if (ProductionOrder === "") {
				messagetext = messagetext + " Production Order No,";
			}

			var BasicStartDate = new sap.ui.model.type.DateTime();
			BasicStartDate = this.getView().byId("BASIC_START_DATE").getValue();
			if (BasicStartDate === "") {
				messagetext = messagetext + " Basic Start Date,";
			} else {
				var a = BasicStartDate.split(" ");
				var d = a[0].split(".");
				BasicStartDate = d[2] + "-" + d[1] + "-" + d[0];
			}

			var BasicFinishDate = new sap.ui.model.type.DateTime();
			BasicFinishDate = this.getView().byId("BASIC_FINISH_DATE").getValue();
			if (BasicFinishDate === "") {
				messagetext = messagetext + " Basic Finish Date,";
			} else {
				var a = BasicFinishDate.split(" ");
				var d = a[0].split(".");
				BasicFinishDate = d[2] + "-" + d[1] + "-" + d[0];
			}

			var CnfQty = this.getView().byId("TOTAL_CNF_QTY").getValue();
			if (CnfQty === "") {
				messagetext = messagetext + " Total Confirm Qty,";
			}

			var DlvQty = this.getView().byId("TOTAL_DLV_QTY").getValue();
			if (DlvQty === "") {
				messagetext = messagetext + " Total Delv Qty,";
			}

			var MachStat = this.getView().byId("MACHINE_STAT").getValue();
			if (MachStat === "" || MachStat === "0") {
				messagetext = messagetext + " Machine Status,";
			}

			var MACHINE_REMARKS = this.getView().byId("MACHINE_REMARKS").getValue();
			var MESH_INSTAL_VAL = this.getView().byId("MESH_INSTAL_VAL").getValue();
			var MESH_INSTAL_REM = this.getView().byId("MESH_INSTAL_REM").getValue();
			var PROD_TEMP_VAL = this.getView().byId("PROD_TEMP_VAL").getValue();
			if (PROD_TEMP_VAL === "") {
				PROD_TEMP_VAL = "0.00";
			}
			var PROD_TEMP_REM = this.getView().byId("PROD_TEMP_REM").getValue();
			var POUCH_VERT_VAL = this.getView().byId("POUCH_VERT_VAL").getValue();
			if (POUCH_VERT_VAL === "" && (MachStat === "Ok" || MachStat === "Operative")) {
				messagetext = messagetext + " Pouch Verticle,";
			} else if (POUCH_VERT_VAL === "") {
				POUCH_VERT_VAL = "0.00";
			}
			var POUCH_VERT_REM = this.getView().byId("POUCH_VERT_REM").getValue();
			var POUCH_TOP_VAL = this.getView().byId("POUCH_TOP_VAL").getValue();
			if (POUCH_TOP_VAL === "" && (MachStat === "Ok" || MachStat === "Operative")) {
				messagetext = messagetext + " Pouch top,";
			} else if (POUCH_TOP_VAL === "") {
				POUCH_TOP_VAL = "0.00";
			}
			var POUCH_TOP_REM = this.getView().byId("POUCH_TOP_REM").getValue();
			var POUCH_HOR_VAL = "0.00";
			var POUCH_HOR_REM = "";
			var MFG_DATE_P_VAL = this.getView().byId("MFG_DATE_P_VAL").getValue();
			if (MFG_DATE_P_VAL === "" && (MachStat === "Ok" || MachStat === "Operative")) {
				messagetext = messagetext + " Manufacturing Date on pouch,";
			} else if (MFG_DATE_P_VAL === "") {
				MFG_DATE_P_VAL = " ";
			} else {
				MFG_DATE_P_VAL = this.getView().byId("MFG_DATE_P_VAL").getValue();
			}
			var MFG_DATE_P_REM = this.getView().byId("MFG_DATE_P_REM").getValue();
			var CODING_P_VAL = this.getView().byId("CODING_P_VAL").getValue();
			if ((CODING_P_VAL === "" || CODING_P_VAL === "0") && (MachStat === "Ok" || MachStat === "Operative")) {
				messagetext = messagetext + " coding/printing on pouch,";
			}

			var CODING_P_REM = this.getView().byId("CODING_P_REM").getValue();
			var PRINT_POS_VAL = this.getView().byId("PRINT_POS_VAL").getValue();
			if ((PRINT_POS_VAL === "" || PRINT_POS_VAL === "0") && (MachStat === "Ok" || MachStat === "Operative")) {
				messagetext = messagetext + " printing postion on pouch,";
			}
			var PRINT_POS_REM = this.getView().byId("PRINT_POS_REM").getValue();
			var LICENSE_VAL = this.getView().byId("LICENSE_VAL").getValue();
			if ((LICENSE_VAL === "" || LICENSE_VAL === "0") && (MachStat === "Ok" || MachStat === "Operative")) {
				messagetext = messagetext + " carton condition,";
			}
			var LICENSE_REM = this.getView().byId("LICENSE_REM").getValue();
			var CART_COND_VAL = this.getView().byId("CART_COND_VAL").getValue();
			if ((CART_COND_VAL === "" || CART_COND_VAL === "0") && (MachStat === "Ok" || MachStat === "Operative")) {
				messagetext = messagetext + " carton condition,";
			}
			var CART_COND_REM = this.getView().byId("CART_COND_REM").getValue();
			var MFG_DATE_C_VAL = " ";
			var MFG_DATE_C_TEXT = this.getView().byId("MFG_DATE_C_TEXT").getValue();
			if ((MFG_DATE_C_TEXT === "" || MFG_DATE_C_TEXT === "0") && (MachStat === "Ok" || MachStat === "Operative")) {
				messagetext = messagetext + " Mfg & Exp Date,";
			}
			var MFG_DATE_C_REM = this.getView().byId("MFG_DATE_C_REM").getValue();
			var BB_END_DATE_VAL = " ";
			var BB_END_DATE_REM = "";
			var CODING_C_VAL = this.getView().byId("CODING_C_VAL").getValue();
			if ((CODING_C_VAL === "" || CODING_C_VAL === "0") && (MachStat === "Ok" || MachStat === "Operative")) {
				messagetext = messagetext + " Carton coding,";
			}
			var CODING_C_REM = this.getView().byId("CODING_C_REM").getValue();
			var CART_STRIP_VAL = this.getView().byId("CART_STRIP_VAL").getValue();
			if ((CART_STRIP_VAL === "" || CART_STRIP_VAL === "0") && (MachStat === "Ok" || MachStat === "Operative")) {
				messagetext = messagetext + " Carton Strip,";
			}
			var CART_STRIP_REM = this.getView().byId("CART_STRIP_REM").getValue();
			var PALLET_VAL = this.getView().byId("PALLET_VAL").getValue();
			if ((PALLET_VAL === "" || PALLET_VAL === "0") && (MachStat === "Ok" || MachStat === "Operative")) {
				messagetext = messagetext + " Palletizing,";
			}
			var PALLET_REM = this.getView().byId("PALLET_REM").getValue();
			var GMP_COMP_VAL = this.getView().byId("GMP_COMP_VAL").getValue();
			if ((GMP_COMP_VAL === "" || GMP_COMP_VAL === "0") && (MachStat === "Ok" || MachStat === "Operative")) {
				messagetext = messagetext + " GMP Comp,";
			}
			var GMP_COMP_REM = this.getView().byId("GMP_COMP_REM").getValue();
			var OVER_ALL_REM = this.getView().byId("OVER_ALL_REM").getValue();
			var DEPT_TYP = this.getView().byId("DEPT_TYP").getValue();
			if (messagetext !== "") {
				sap.m.MessageBox.alert(messagetext + "cannot be null, please fill the values and try again");
			} else {
				//***************************************************************//

				var dialog = new sap.m.Dialog({
					title: 'Confirm',
					type: 'Message',
					content: [
						new sap.m.Text({
							text: "Are you sure, you want to save your inspection  ?"
						})
					],
					beginButton: new sap.m.Button({
						text: 'Save',

						press: function() {
							//*******************************************//

							//****************************************************************//
							var userRequestBody = {
								properties: {
									SHIFT: Shift,
									BATCH_NO: BatchNo,
									PLANT_ID: Plant,
									PLANT_NAME: PlantName,
									WORK_CENTER: WORK_CENTER,
									MATERIAL_ID: MatId,
									MATERIAL_DESC: MatDesc,
									MACHINE_ID: MACHINE_ID,
									MACH_DESC: MACH_DESC,
									SUBMIT_BY: SubmitBy,
									INSPECTION_DEPT: InspDept,
									PRODUCTION_ORDER_NO: ProductionOrder,
									BASIC_START_DATE: new Date(BasicStartDate + " 11:13:00"),
									BASIC_FINISH_DATE: new Date(BasicFinishDate + " 11:13:00"),
									TOTAL_CNF_QTY: CnfQty,
									TOTAL_DLV_QTY: DlvQty,
									MACHINE_STAT: MachStat,
									MACHINE_REMARKS: MACHINE_REMARKS,
									MESH_INSTAL_VAL: MESH_INSTAL_VAL,
									MESH_INSTAL_REM: MESH_INSTAL_REM,
									PROD_TEMP_VAL: PROD_TEMP_VAL,
									PROD_TEMP_REM: PROD_TEMP_REM,
									POUCH_VERT_VAL: POUCH_VERT_VAL,
									POUCH_VERT_REM: POUCH_VERT_REM,
									POUCH_TOP_VAL: POUCH_TOP_VAL,
									POUCH_TOP_REM: POUCH_TOP_REM,
									POUCH_HOR_VAL: POUCH_HOR_VAL,
									POUCH_HOR_REM: POUCH_HOR_REM,
									MFG_DATE_P_VAL: MFG_DATE_P_VAL,
									MFG_DATE_P_REM: MFG_DATE_P_REM,
									CODING_P_VAL: CODING_P_VAL,
									CODING_P_REM: CODING_P_REM,
									PRINT_POS_VAL: PRINT_POS_VAL,
									PRINT_POS_REM: PRINT_POS_REM,
									LICENSE_VAL: LICENSE_VAL,
									LICENSE_REM: LICENSE_REM,
									CART_COND_VAL: CART_COND_VAL,
									CART_COND_REM: CART_COND_REM,
									MFG_DATE_C_VAL: MFG_DATE_C_VAL,
									MFG_DATE_C_TEXT: MFG_DATE_C_TEXT,
									MFG_DATE_C_REM: MFG_DATE_C_REM,
									BB_END_DATE_VAL: BB_END_DATE_VAL,
									BB_END_DATE_REM: BB_END_DATE_REM,
									CODING_C_VAL: CODING_C_VAL,
									CODING_C_REM: CODING_C_REM,
									CART_STRIP_VAL: CART_STRIP_VAL,
									CART_STRIP_REM: CART_STRIP_REM,
									PALLET_VAL: PALLET_VAL,
									PALLET_REM: PALLET_REM,
									GMP_COMP_VAL: GMP_COMP_VAL,
									GMP_COMP_REM: GMP_COMP_REM,
									OVER_ALL_REM: OVER_ALL_REM,
									DEPT_TYP: DEPT_TYP
								}
							};
							var oModel = that.getOwnerComponent().getModel();
							var oContext = oModel.createEntry("/ZQC_INS_FN_SLT_TSet", userRequestBody); //ZTB_QM_IPPKL_JRSet
							that.getView().setBindingContext(oContext);
							oModel.submitChanges();
							that.clearFormdetails();
							dialog.close();
							that.getOwnerComponent().getRouter().getTargets().display("object");
						}
					}),

					endButton: new sap.m.Button({
						text: 'Cancel',
						press: function() {
							dialog.close();
						}
					}),
					afterClose: function() {
						dialog.destroy();
					}
				});
				dialog.open();

			}
		},

		clearFormdetails: function() {
			var sVal = "";
			var oInput;

			oInput = this.getView().byId("SUBMIT_BY");
			oInput.setSelectedKey("0");
			oInput.setValue(sVal);

			oInput = this.getView().byId("ddl_Shift");
			oInput.setSelectedKey("0");
			oInput = this.getView().byId("SHIFT");
			oInput.setValue(sVal);

			oInput = this.getView().byId("ddl_MACHINE_ID");
			oInput.setSelectedKey("0");
			oInput = this.getView().byId("MACHINE_ID");
			oInput.setValue(sVal);

			oInput = this.getView().byId("ddl_MACHINE_STAT");
			oInput.setSelectedKey("0");
			oInput = this.getView().byId("MACHINE_STAT");
			oInput.setValue(sVal);

			oInput = this.getView().byId("ddl_MACHINE_REMARKS");
			oInput.setSelectedKey("0");
			oInput = this.getView().byId("MACHINE_REMARKS");
			oInput.setValue(sVal);

			oInput = this.getView().byId("PLANT_ID_ID");
			oInput.setValue(sVal);
			oInput = this.getView().byId("PLANT_NAME");
			oInput.setValue(sVal);
			oInput = this.getView().byId("BASIC_START_DATE");
			oInput.setValue(sVal);
			oInput = this.getView().byId("BASIC_FINISH_DATE");
			oInput.setValue(sVal);
			oInput = this.getView().byId("MATERIAL_ID");
			oInput.setValue(sVal);
			oInput = this.getView().byId("TOTAL_CNF_QTY");
			oInput.setValue(sVal);
			oInput = this.getView().byId("MATERIAL_DESC");
			oInput.setValue(sVal);
			oInput = this.getView().byId("MachineDesc");
			oInput.setValue(sVal);
			oInput = this.getView().byId("TOTAL_DLV_QTY");
			oInput.setValue(sVal);
			oInput = this.getView().byId("PRODUCTION_ORDER_NO");
			oInput.setValue(sVal);
			oInput = this.getView().byId("BATCH_NO_ID");
			oInput.setValue(sVal);
			oInput = this.getView().byId("INSPECTION_DEPT");
			oInput.setValue(sVal);
			oInput = this.getView().byId("SUBMIT_BY");
			oInput.setValue(sVal);
			oInput = this.getView().byId("WORK_CENTER");
			oInput.setValue(sVal);

			oInput  =  this.getView().byId("ddl_MESH_INSTAL_VAL");
			oInput.setSelectedKey("0");
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("MESH_INSTAL_VAL");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("MESH_INSTAL_REM");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("PROD_TEMP_VAL");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("PROD_TEMP_REM");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("POUCH_VERT_VAL");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("POUCH_VERT_REM");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("POUCH_TOP_VAL");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("POUCH_TOP_REM");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("MFG_DATE_P_VAL");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("MFG_DATE_P_REM");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("ddl_CODING_P_VAL");
			oInput.setSelectedKey("0");
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("CODING_P_VAL");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("CODING_P_REM");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("ddl_PRINT_POS_VAL");
			oInput.setSelectedKey("0");
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("PRINT_POS_VAL");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("PRINT_POS_REM");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("ddl_LICENSE_VAL");
			oInput.setSelectedKey("0");
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("LICENSE_VAL");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("LICENSE_REM");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("ddl_CART_COND_VAL");
			oInput.setSelectedKey("0");
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("CART_COND_VAL");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("CART_COND_REM");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("ddl_MFG_DATE_C_VAL");
			oInput.setSelectedKey("0");
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("MFG_DATE_C_TEXT");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("MFG_DATE_C_REM");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("ddl_CODING_C_VAL");
			oInput.setSelectedKey("0");
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("CODING_C_VAL");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("CODING_C_REM");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("ddl_CART_STRIP_VAL");
			oInput.setSelectedKey("0");
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("CART_STRIP_VAL");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("CART_STRIP_REM");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("ddl_PALLET_VAL");
			oInput.setSelectedKey("0");
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("PALLET_VAL");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("PALLET_REM");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("ddl_GMP_COMP_VAL");
			oInput.setSelectedKey("0");
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("GMP_COMP_VAL");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("GMP_COMP_REM");
			oInput.setValue(sVal);
			oInput.setEnabled(false);
			oInput  =  this.getView().byId("OVER_ALL_REM");
			oInput.setValue(sVal);

		},
		formatDate: function(_date, _format, _delimiter) {
			var formatLowerCase = _format.toLowerCase();
			var formatItems = formatLowerCase.split(_delimiter);
			var dateItems = _date.split(_delimiter);
			var monthIndex = formatItems.indexOf("mm");
			var dayIndex = formatItems.indexOf("dd");
			var yearIndex = formatItems.indexOf("yyyy");
			var month = parseInt(dateItems[monthIndex]);
			month -= 1;

			var formatedDate = new Date(dateItems[yearIndex], month, dateItems[dayIndex], '10', '10', '10', '10');
			return formatedDate;
		},

		fBatchChange: function(oEvent) {
			var that = this;
			this.byId("PLANT_ID_ID").setValue("");
			this.byId("PLANT_NAME").setValue("");
			this.byId("MATERIAL_ID").setValue("");
			this.byId("MATERIAL_DESC").setValue("");
			this.byId("INSPECTION_DEPT").setValue("");
			this.byId("PRODUCTION_ORDER_NO").setValue("");
			this.byId("BASIC_START_DATE").setValue("");
			this.byId("BASIC_FINISH_DATE").setValue("");
			this.byId("TOTAL_CNF_QTY").setValue("");
			this.byId("TOTAL_DLV_QTY").setValue("");
			this.byId("DEPT_TYP").setValue("");
			this.byId("WORK_CENTER").setValue("");
			this.byId("MATERIAL_ID").setValue("");
			this.byId("MachineDesc").setValue("");
			this.byId("ddl_MACHINE_ID").removeAllItems();
			var sVal = this.getView().byId("BATCH_NO_ID").getValue();

			if ((sVal !== "Select") || (sVal !== "")) {

				var oInput = this.getView().byId("BATCH_NO_ID");
				oInput.setValue(sVal);
				var oModel = this.getOwnerComponent().getModel();
				var sValue = this.getView().byId("BATCH_NO_ID").getValue();
				var readstring = "/ZST_AFPO_BATCHSet(CHARG='" + sValue + "|0030|X')";
				// oModel.setRefreshAfterChange(false);

				oModel.read(readstring, {
					success: function(oData) {

						if (oData.CHARG === "") {
							sap.m.MessageBox.show("Invalid Batch #", {
								icon: sap.m.MessageBox.Icon.ERROR, // default
								title: "Error", // default
								actions: sap.m.MessageBox.Action.OK, // default
								onClose: null, // default
								styleClass: "", // default
								initialFocus: null, // default
								textDirection: sap.ui.core.TextDirection.Inherit // default
							});
						} else {
							var mResult = oData.Matnr;
							var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
								pattern: "dd.MM.yyyy"
							});
							var DEPT_TYP = "PP";
							that.byId("PLANT_ID_ID").setValue(oData.WERKS);
							that.byId("PLANT_NAME").setValue(oData.NAME1);
							that.byId("WORK_CENTER").setValue(oData.KTEXT);
							that.byId("MATERIAL_ID").setValue(oData.MATNR);
							that.byId("MATERIAL_DESC").setValue(oData.MAKTX);
							that.byId("INSPECTION_DEPT").setValue(oData.INSPECTION_DEPT);
							that.byId("PRODUCTION_ORDER_NO").setValue(oData.AUFNR);
							that.byId("BASIC_START_DATE").setValue(oData.GSTRP);
							that.byId("BASIC_FINISH_DATE").setValue(oData.GLTRP);
							that.byId("TOTAL_CNF_QTY").setValue(oData.IGMNG);
							that.byId("TOTAL_DLV_QTY").setValue(oData.WEMNG);
							that.byId("DEPT_TYP").setValue(DEPT_TYP);

							mResult = oData.GSTRP;
							var dateStr = dateFormat.format(mResult);
							that.byId("BASIC_START_DATE").setValue(dateStr);
							mResult = oData.GLTRP;
							dateStr = dateFormat.format(mResult);
							that.byId("BASIC_FINISH_DATE").setValue(dateStr);

							sValue = oData.WERKS;
							var MachineId = that.byId("MACHINE_ID");
							MachineId.setValue("");
							var MachineDesc = that.byId("MachineDesc");
							MachineDesc.setValue("");
							var sRegion = that.byId("ddl_MACHINE_ID");
							var oFilters = [new sap.ui.model.Filter("PLANT", "EQ", sValue)];
							var oTemplate = new sap.ui.core.Item({
								key: "{MachineId}",
								text: "{MachineDesc}"
							});
							sRegion.setSelectedKey();
							sRegion.bindItems("/ZTB_QM_MACHINFOSet", oTemplate, null, oFilters);

						}

					},
					error: function(oError) {
						// Error handling on failed response
					}
				});
			}

		},
		//end

		//////////////////////////////////////////////////////////////////////////
		isNumeric: function(obj) {
			var realStringObj = obj && obj.toString();
			return !jQuery.isArray(obj) && (realStringObj - parseFloat(realStringObj) + 1) >= 0;
		},

		valInput_01: function() {
			var val = this.getView().byId("PROD_TEMP_VAL").getValue();

			if (val !== '') {
				var oResult = this.isNumeric(val);
				if (!oResult) {
					sap.m.MessageBox.alert("Invalid Input: product temperature, please input correct data");
					var textval = this.byId("PROD_TEMP_VAL");
					textval.setValue("");
				}
			}
		},
		valInput_02: function() {
			var val = this.getView().byId("POUCH_VERT_VAL").getValue();

			if (val !== '') {
				var oResult = this.isNumeric(val);
				if (!oResult) {
					sap.m.MessageBox.alert("Invalid Input: pouch vertical sealing, please input correct data");
					var textval = this.byId("POUCH_VERT_VAL");
					textval.setValue("");
				}
			}
		},
		valInput_03: function() {
			var val = this.getView().byId("POUCH_TOP_VAL").getValue();

			if (val !== '') {
				var oResult = this.isNumeric(val);
				if (!oResult) {
					sap.m.MessageBox.alert("Invalid Input: pouch top horizontal sealing, please input correct data");
					var textval = this.byId("POUCH_TOP_VAL");
					textval.setValue("");
				}
			}
		},
		valInput_04: function() {
			var val = this.getView().byId("POUCH_HOR_VAL").getValue();

			if (val !== '') {
				var oResult = this.isNumeric(val);
				if (!oResult) {
					sap.m.MessageBox.alert("Invalid Input: pouch bottom horizontal sealing, please input correct data");
					var textval = this.byId("POUCH_HOR_VAL");
					textval.setValue("");
				}
			}
		},
		onNavBack: function() {
			this.getOwnerComponent().getRouter().getTargets().display("object");
		}

	});

});