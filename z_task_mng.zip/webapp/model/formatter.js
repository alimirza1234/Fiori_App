sap.ui.define([], function () {
	"use strict";
	return {
		status: function (sStatus) {
			if (sStatus == "Closed" || sStatus == "CLOSED") {
				return "Success";
			} else if (sStatus == "Open" || sStatus == "OPEN") {
				return "Error";

			} else if (sStatus == "sos" || sStatus == "SOS") {
				return "Error";

			} else {
				return "Error";

			}
		}

	};
});