sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"zfiori/z_task_mng/model/models",
	"sap/ui/model/odata/ODataModel",
	"zfiori/z_task_mng/utils/datamanager"
], function (UIComponent, Device, models, ODataModel, datamanager) {
	"use strict";

	return UIComponent.extend("zfiori.z_task_mng.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function () {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// enable routing
			this.getRouter().initialize();

			// set the device model
			this.setModel(models.createDeviceModel(), "device");
			
			var sUrl = "/sap/opu/odata/sap/ZTM_APP_SRV/";
			var oModel = new ODataModel(sUrl, true);
			sap.ui.getCore().setModel(oModel);
			datamanager.init(oModel);
			
		}
	});
});