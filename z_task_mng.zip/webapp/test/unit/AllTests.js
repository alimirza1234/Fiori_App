sap.ui.define([
	"zfiori/z_task_mng/test/unit/controller/mainPage.controller"
], function () {
	"use strict";
});