/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"zfiori/z_task_mng/test/integration/AllJourneys"
	], function () {
		QUnit.start();
	});
});