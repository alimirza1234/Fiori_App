 //function _arrayBufferToBase64(buffer) {
 //	debugger;
 //	var oContent = '';
 //	var binaryArrays = new Uint8Array(buffer);
 //	var len = binaryArrays.byteLength;
 //	for (var i = 0; i < len; i++) {
 //		// convert code to char 
 //		oContent += String.fromCharCode(binaryArrays[i]);
 //	}
 //	// convert binary to  ascii code
 //	return window.btoa(oContent);
 //}
 //var fileObject2 = {};

 //function buff(e) {
 //	debugger;
 //	// k = e;
 //	var base64 = _arrayBufferToBase64(e.target.result);
 //	fileObject2.value = base64;
 //}
 var FileValue = [];
 var FileObj = {};

 function arrayToBinary(e) {

 	var t = "";
 	var a = new Uint8Array(e);
 	var i = a.byteLength;
 	for (var s = 0; s < i; s++) {
 		t += String.fromCharCode(a[s]);
 	}
 	var n = btoa(t);
 	FileObj.value = n;
 	FileValue.push(n);
 }

 sap.ui.define([
 	"sap/ui/core/mvc/Controller",
 	"zfiori/z_task_mng/utils/datamanager",
 	'sap/ui/core/Fragment',
 	"sap/ui/core/routing/History",
 	"sap/ui/model/json/JSONModel",
 	'sap/m/MessageBox',
 	"sap/m/Button",
 	"sap/m/Dialog",
 	'sap/m/MessageToast',
 	"sap/m/MessageStrip",
 	"sap/m/Text",
 	'sap/m/Token',
 	'sap/ui/model/FilterOperator',
 	'sap/ui/model/Filter'
 ], function (Controller, datamanager, Fragment, History, JSONModel, MessageBox, Button, Dialog, MessageToast, MessageStrip, Text, Token,
 	FilterOperator, Filter) {
 	"use strict";

 	return Controller.extend("zfiori.z_task_mng.controller.taskCreate", {
 		pageState: {
 			create: true,
 			edit: true,
 			required: false,
 		},
 		modeState: {
 			mode: "Delete"
 		},
 		oTaskData: {},
 		fileObject: {},
 		of4help: {},
 		Files: [],
 		reader: {},
 		oFileObject: {},
 		task_id: null,
 		oModel12: {},
 		uname: [],

 		// oRichTextEditor: null,

 		onInit: function (oEvent) {
 			this.getOwnerComponent().getRouter().getRoute("taskCreate").attachMatched(this.onNavToCurrentPage, this);

 		},

 		onBeforeRendering: function () {

 		},

 		onNavToCurrentPage: function (oEvent) {
 			var oBusy = new sap.m.BusyDialog();
 			var that = this;
 			that.byId("OpenDate").bindValue({
 				path: "formModel>/TATT",
 				type: "sap.ui.model.type.Date",
 				formatOptions: {
 					pattern: "dd-MM-yyyy",
 					strictParsing: true
 				},
 				constraints: {
 					minimum: new Date("2020-01-01")
 				}
 			});
 			that.task_id = oEvent.getParameter("arguments").taskId;
 			var C_RTE_details = that.getView().byId("C_RTE_details");
 			// var Remarks = that.getView().byId("Remarks");
 			//C_RTE_details.addButtonGroup("styleselect").addButtonGroup("table");
 			// var a = this.getView().byId("Attachlist");
 			// var n = new JSONModel();
 			// a.setModel(n, "AttachList");
 			oBusy.open();
 			datamanager.getF4helpdata(function (response) {
 				that.of4help = JSON.parse(response.IvJson);
 				var a = that.of4help.FILE_TYPE;
 				var b = {
 					"MANDT": null,
 					"FILE_TYPE": null,
 					"TEXT": null
 				};
 				// a.insert([0], b);
 				a.unshift(b);
 				// that.oTaskData.TATT = new Date(that.oTaskData.AEDAT);
 				var of4helpmodel = new JSONModel(that.of4help);
 				that.getView().setModel(of4helpmodel, "of4helpmodel");
 				var r = that.getView().byId("Assignee");
 				var s = that.getView().byId("approveBy");
 				var t = that.getView().byId("reviseBy");
 				// r.destroTokens();
 				// console.log(that.of4help);
 				// oBusy.open();
 				if (that.task_id) {
 					debugger;
 					that.pageState.create = false;
 					that.pageState.edit = false;
 					that.pageState.required = true;
 					var oPanel = that.getView().byId("Panel");
 					oPanel.setVisible(true);
 					var list = that.getView().byId("Status");
 					var statusenable = list.mProperties.enabled.true;
 					var g = that.getView().byId("fileUploader");
 					g.setVisible(true);
 					var u = that.getView().byId("AttachmentForm");
 					u.setVisible(true);
 					var c = that.getView().byId("Attachlist");
 					c.setVisible(true);

 					datamanager.getAttachmentList(that.task_id, function (e) {
 							that.oTaskAttach = JSON.parse(e.IvJson);
 							// for (var i = 0; i < that.oTaskAttach.length; i++) {
 							// 	that.oTaskAttach[i].mode = "None";
 							// }
 							// that.oTaskAttach[0].mode = "Delete";
 							// var a = that.oTaskAttach[0];
 							// that.oTaskAttach.push(a);
 							// that.oTaskAttach[1].mode = "None";

 							// if (that.oTaskData.AENAM !== that.of4help.SYUNAME) {

 							// 	var delCheck = that.getView().byId("Attachlist");
 							// 	that.modeState.mode = "Delete";
 							// 	var modeState = new JSONModel(that.modeState);
 							// 	that.getView().setModel(modeState, "modeState");
 							// }
 							var a = new JSONModel(that.oTaskAttach);
 							that.getView().setModel(a, "ShowAttachList");
 							that.getView().getModel('ShowAttachList').refresh();
 						},

 						function (e) {
 							MessageToast.show(" attachment error ");
 						});

 					datamanager.getTaskDetails(that.task_id, function (result) {
 						that.oTaskData = JSON.parse(result.IvJson);
 						// if (that.oTaskData.AENAM !== that.of4help.SYUNAME) {

 						// 	var delCheck = that.getView().byId("Attachlist");
 						// 	//   var a = delCheck.setMode("None");
 						// 	// // that.getView().getModel('AttachList').refresh();
 						// 	that.modeState.mode = "None";
 						// 	var modeState = new JSONModel(that.modeState);
 						// 	that.getView().setModel(modeState, "modeState");

 						// }
 						// else if (that.of4help.SYUNAME !== undefined) {
 						// 	that.modeState.mode = "Delete";
 						// 	var modeState = new JSONModel(that.modeState);
 						// 	that.getView().setModel(modeState, "modeState");
 						// }
 						// else {
 						// 	var delCheck = that.getView().byId("Attachlist");
 						// 	delCheck.setMode("Delete");
 						// 	that.getView().getModel('AttachList').refresh();
 						// }
 						var obj = {
 							status: false,
 							description: false,
 							title: false,
 							Taskgroup: false,
 							Filetype: false,
 							tmParentTaskid: false,
 							TaskdueDate: false,
 							PotReference: false,
 							Priority: false,
 							DocRefNo: false,
 							DocName: false,
 							Approveby: false,
 							Revisedby: false,
 							Assignby: false,
 						};
 						var oStatus = new JSONModel(obj);
 						that.getView().setModel(oStatus, 'StatusEdit');
 						r.destroyTokens();
 						s.destroyTokens();
 						t.destroyTokens();
 						if (that.oTaskData.ASSIGNEE && that.oTaskData.ASSIGNEE.length > 0) {
 							var n = that.oTaskData.ASSIGNEE.split(",");
 							n.forEach(function (e) {
 								r.addToken(new Token({
 									text: e
 								}));
 							});
 						}
 						if (that.oTaskData.APPROVE_BY && that.oTaskData.APPROVE_BY.length > 0) {
 							var m = that.oTaskData.APPROVE_BY.split(",");
 							m.forEach(function (e) {
 								s.addToken(new Token({
 									text: e
 								}));
 							});
 						}
 						if (that.oTaskData.REVISED_BY && that.oTaskData.REVISED_BY.length > 0) {
 							var o = that.oTaskData.REVISED_BY.split(",");
 							o.forEach(function (e) {
 								t.addToken(new Token({
 									text: e
 								}));
 							});
 						}
 						that.oTaskData.TATT = new Date(that.oTaskData.TATT);
 						var oModel = new JSONModel(that.oTaskData);
 						// .setValue(new Date(that.oTaskData.TATT));
 						that.getView().setModel(oModel, "formModel");
 						setTimeout(function () {
 							C_RTE_details.setValue(that.oTaskData.DISCRIPTION);
 							// Remarks.setValue(that.oTaskData.Remarks);

 						}, 500);
 						// C_RTE_details.setValue(that.oTaskData.DISCRIPTION);
 						var AfterRemarks = that.getView().byId('AfterRemarks');
 						AfterRemarks.setEditable(false);
 						AfterRemarks.setVisible(true);

 						var Remarks = that.getView().byId('Remarks');
 						Remarks.setEditable(true);
 						Remarks.setVisible(true);
 						// Remarks.getValue();
 						var getRemarksContent = tinyMCE.editors[3].getContent();
 						var regex = /(<([^>]+)>)/ig;
 						var hasText = !!getRemarksContent.replace(regex, "").length;
 						if (hasText === true) {
 							getRemarksContent.setValue('');
 						}
 						oBusy.close();
 					}, function (error) {
 						MessageToast.show(" Does not get task id ");
 					});
 					// oBusy.close();

 				} else {

 					// oBusy.open();
 					that.pageState.create = true;
 					that.pageState.edit = false;
 					that.pageState.required = false;
 					var oPanel = that.getView().byId("Panel");
 					oPanel.setVisible(false);
 					var f = that.getView().byId("fileUploader");
 					f.setVisible(true);
 					var v = that.getView().byId("AttachmentForm");
 					v.setVisible(true);
 					var h = that.getView().byId("Attachlist");
 					h.setVisible(true);
 					// oBusy.open();
 					var AfterRemarks = that.getView().byId('AfterRemarks');
 					var Remarks = that.getView().byId('Remarks');
 					AfterRemarks.setEditable(false);
 					AfterRemarks.setVisible(true);
 					Remarks.setEditable(false);

 					that.getView().byId("Assignee").destroyTokens();
 					that.getView().byId("approveBy").destroyTokens();
 					that.getView().byId("reviseBy").destroyTokens();
 					// that.statusState.create = true;
 					// that.statusState.edit = false;
 					var oModel = new JSONModel({
 						"Tid": "",
 						"TITLE": "",
 						"DISCRIPTION": "",
 						"TYPE_T": "C",
 						"FILE_TYPE": "",
 						"PID": "",
 						"PTITLE": "",
 						"ASSIGNEE": "",
 						"ASSIGNEE_TO_NAME": "",
 						"AEDAT_C": new Date(),
 						"STATUS": "O",
 						"POT_ID": "",
 						// "REMARKS": "",
 						"AFTERREMARKS": "",
 						"PRIORITY": "H",
 						"SAP_DOCNR": "",
 						"SAP_DOCNM": "",
 						"APPROVE_BY": "",
 						"REVISED_BY": ""

 					});
 					that.getView().setModel(oModel, "formModel");
 					var obj = {
 						status: false
 					};
 					var oStatus = new JSONModel(obj);
 					that.getView().setModel(oStatus, 'StatusEdit');

 				}
 				var pageModel = new JSONModel(that.pageState);
 				that.getView().setModel(pageModel, "pageModel");
 				debugger;
 				oBusy.close();
 			}, function (error) {
 				MessageToast.show(" Does not get data ");
 			});
 			oBusy.open();

 		},

 		onAfterRendering: function () {

 		},

 		getParentData: function (oEvent) {
 			if (!this.newStudentDialog1) {
 				this.newStudentDialog1 = sap.ui.xmlfragment("zfiori.z_task_mng.fragments.ParentTaskList", this);
 				var oModel = new sap.ui.model.json.JSONModel();
 				this.newStudentDialog1.setModel(oModel);
 			}
 			var data1 = JSON.parse(JSON.stringify(this.of4help)); //it break ka obj linkage and create anohter obj whick is independent
 			this.newStudentDialog1.getModel().setData(data1);
 			this.newStudentDialog1.open();
 		},

 		_ParentValueHelpSearch: function (evt) {
 			var sValue = evt.getParameter("value");
 			var oFilter = new Filter(
 				"LONG_ID",
 				FilterOperator.Contains,
 				sValue
 			);
 			evt.getSource().getBinding("items").filter([oFilter]);
 		},

 		selectParentItem: function (evt) {

 			var oSelectedItem = evt.mParameters.selectedItems;
 			if (oSelectedItem) {
 				var productInput1 = this.byId("parentTaskID");
 				var parentTaskTitle = this.byId("parentTaskTitle");
 				var oPrnr1 = oSelectedItem[0].getTitle();
 				var oName1 = oSelectedItem[0].getDescription();

 				productInput1.setValue(oPrnr1);
 				parentTaskTitle.setValue(oName1);
 			}
 			evt.getSource().getBinding("items").filter([]);
 		},

 		Potlivechange: function (evt) {
 			var sValue = evt.getParameter("value");
 			var oFilter = new Filter(
 				"POT_NAME",
 				FilterOperator.Contains,
 				sValue
 			);
 			evt.getSource().getBinding("items").filter([oFilter]);
 		},

 		getParentData1: function (oEvent) {
 			if (!this.newStudentDialog12) {
 				this.newStudentDialog12 = sap.ui.xmlfragment("zfiori.z_task_mng.fragments.potf4", this);
 				var oModel = new sap.ui.model.json.JSONModel();
 				this.newStudentDialog12.setModel(oModel);
 			}
 			var data1 = JSON.parse(JSON.stringify(this.of4help)); //it break ka obj linkage and create anohter obj whick is independent
 			this.newStudentDialog12.getModel().setData(data1);
 			this.newStudentDialog12.open();
 		},
 		selectParentItem1: function (evt) {

 			var oSelectedItem = evt.mParameters.selectedItems;
 			if (oSelectedItem) {
 				var productInput1 = this.byId("cdprefrence");
 				// var parentTaskTitle = this.byId("parentTaskTitle");
 				var oPrnr1 = oSelectedItem[0].getTitle();
 				// var oName1 = oSelectedItem[0].getDescription();

 				productInput1.setValue(oPrnr1);
 				// parentTaskTitle.setValue(oName1);
 			}
 			evt.getSource().getBinding("items").filter([]);
 		},

 		// getAssignData: function (oEvent) {
 		// 	// var sInputValue = oEvent.getSource().getValue();

 		// 	// // create value help dialog
 		// 	// if (!this._valueHelpDialog) {
 		// 	// 	Fragment.load({
 		// 	// 		name: "zfiori.z_task_mng.fragments.AssignTaskList",
 		// 	// 		controller: this
 		// 	// 	}).then(function (oValueHelpDialog) {
 		// 	// 		this._valueHelpDialog = oValueHelpDialog;
 		// 	// 		this.getView().addDependent(this._valueHelpDialog);
 		// 	// 		this._openValueHelpDialog(sInputValue);
 		// 	// 	}.bind(this));
 		// 	// } else {
 		// 	// 	this._openValueHelpDialog(sInputValue);
 		// 	// }
 		// 	var valueHelpDialog = new sap.ui.xmlfragment("zfiori.z_task_mng.fragments.AssignTaskList", this);
 		// 	var oInput = oEvent.getSource().getValue();
 		// 	this.getView().addDependent(valueHelpDialog);
 		// 	valueHelpDialog.open(oInput);
 		// },
 		getAssignData1: function (oEvent) {

 			var sInputValue = oEvent.getSource().getValue();

 			// create value help dialog
 			if (!this._valueHelpDialog1) {
 				Fragment.load({
 					name: "zfiori.z_task_mng.fragments.potf4",
 					controller: this
 				}).then(function (oValueHelpDialog) {
 					this._valueHelpDialog1 = oValueHelpDialog;
 					this.getView().addDependent(this._valueHelpDialog1);
 					this._openValueHelpDialog1(sInputValue);
 				}.bind(this));
 			} else {
 				this._openValueHelpDialog1(sInputValue);
 			}
 		},

 		_openValueHelpDialog1: function (sInputValue) {
 			this._valueHelpDialog1.getBinding("items").filter([new Filter(
 				"POT_ID",
 				FilterOperator.Contains,
 				sInputValue
 			)]);

 			// open value help dialog filtered by the input value
 			this._valueHelpDialog1.open(sInputValue);
 		},
 		_openValueHelpDialog: function (sInputValue) {
 			// create a filter for the binding
 			this._valueHelpDialog.getBinding("items").filter([new Filter(
 				"USRID",
 				FilterOperator.Contains,
 				sInputValue
 			)]);

 			// open value help dialog filtered by the input value
 			this._valueHelpDialog.open(sInputValue);
 		},

 		_handleValueHelpSearch: function (evt) {
 			var sValue = evt.getParameter("value");
 			var oFilter = new Filter(
 				"USRID",
 				FilterOperator.Contains,
 				sValue
 			);
 			evt.getSource().getBinding("items").filter([oFilter]);
 		},

 		_handleValueHelpSearchR: function (e) {
 			var t = e.getParameter("value");
 			var a = new Filter("USRID", FilterOperator.Contains, t);
 			e.getSource().getBinding("items").filter([a]);
 		},

 		_handleValueHelpCloseR: function (evt) {
 			var that = this;
 			var aSelectedItems = evt.getParameter("selectedItems");
 			var getitem = evt.oSource._oList._aSelectedPaths;

 			// var getf4list = this.getView().getModel("of4helpmodel").oData.USRID;
 			// var evt.oSource._oList._aSelectedPaths;
 			var oMultiInput = sap.ui.getCore().byId('Assignee12')
 			if (getitem && getitem.length > 0) {
 				getitem.forEach(function (oitem, index) {
 					var oIndex = getitem[index].slice(7);
 					var getf4list = that.getView().getModel("of4helpmodel").getData().USRID[oIndex];
 					oMultiInput.addToken(new Token({
 						text: getf4list.USRID
 					}));
 				});
 			}

 			// if (aSelectedItems && aSelectedItems.length > 0) {
 			// aSelectedItems.forEach(function (oItem) {
 			// 	oMultiInput.addToken(new Token({
 			// 		text: oItem.getTitle()
 			// 	}));
 			// });
 		},

 		_handleValueHelpClose: function (evt) {
 			var that = this;
 			var aSelectedItems = evt.getParameter("selectedItems");
 			var getitem = evt.oSource._oList._aSelectedPaths;

 			// var getf4list = this.getView().getModel("of4helpmodel").oData.USRID;
 			// var evt.oSource._oList._aSelectedPaths;
 			var oMultiInput = that.byId('Assignee');
 			if (getitem && getitem.length > 0) {
 				getitem.forEach(function (oitem, index) {
 					var oIndex = getitem[index].slice(7);
 					var getf4list = that.getView().getModel("of4helpmodel").getData().USRID[oIndex];
 					oMultiInput.addToken(new Token({
 						text: getf4list.USRID
 					}));
 				});
 			}

 			// if (aSelectedItems && aSelectedItems.length > 0) {
 			// aSelectedItems.forEach(function (oItem) {
 			// 	oMultiInput.addToken(new Token({
 			// 		text: oItem.getTitle()
 			// 	}));
 			// });
 		},

 		getApproveData: function (oEvent) {
 			var sInputValue = oEvent.getSource().getValue();

 			// create value help dialog
 			if (!this._valueApproveDialog) {
 				Fragment.load({
 					name: "zfiori.z_task_mng.fragments.Approve",
 					controller: this
 				}).then(function (oValueHelpDialog) {
 					this._valueApproveDialog = oValueHelpDialog;
 					this.getView().addDependent(this._valueApproveDialog);
 					this._openApproveDialog(sInputValue);
 				}.bind(this));
 			} else {
 				this._openApproveDialog(sInputValue);
 			}
 		},
 		_openApproveDialog: function (sInputValue) {
 			// create a filter for the binding
 			this._valueApproveDialog.getBinding("items").filter([new Filter(
 				"USRID",
 				FilterOperator.Contains,
 				sInputValue
 			)]);

 			// open value help dialog filtered by the input value
 			this._valueApproveDialog.open(sInputValue);
 		},
 		_handleApproveValueHelpSearch: function (evt) {
 			var sValue = evt.getParameter("value");
 			var oFilter = new Filter(
 				"USRID",
 				FilterOperator.Contains,
 				sValue
 			);
 			evt.getSource().getBinding("items").filter([oFilter]);
 		},
 		_handleApproveClose: function (evt) {
 			var aSelectedItems = evt.getParameter("selectedItems"),
 				oMultiInput = this.byId("approveBy");

 			if (aSelectedItems && aSelectedItems.length > 0) {
 				aSelectedItems.forEach(function (oItem) {
 					oMultiInput.addToken(new Token({
 						text: oItem.getTitle()
 					}));
 				});
 			}
 		},

 		getReviseData: function (oEvent) {
 			var sInputValue = oEvent.getSource().getValue();

 			// create value help dialog
 			if (!this._valueReviseDialog) {
 				Fragment.load({
 					name: "zfiori.z_task_mng.fragments.Revise",
 					controller: this
 				}).then(function (oValueHelpDialog) {
 					this._valueReviseDialog = oValueHelpDialog;
 					this.getView().addDependent(this._valueReviseDialog);
 					this._openReviseDialog(sInputValue);
 				}.bind(this));
 			} else {
 				this._openReviseDialog(sInputValue);
 			}
 		},
 		_openReviseDialog: function (sInputValue) {
 			// create a filter for the binding
 			this._valueReviseDialog.getBinding("items").filter([new Filter(
 				"USRID",
 				FilterOperator.Contains,
 				sInputValue
 			)]);

 			// open value help dialog filtered by the input value
 			this._valueReviseDialog.open(sInputValue);
 		},

 		_handleReviseValueHelpSearch: function (evt) {
 			var sValue = evt.getParameter("value");
 			var oFilter = new Filter(
 				"USRID",
 				FilterOperator.EQ,
 				sValue
 			);
 			evt.getSource().getBinding("items").filter([oFilter]);
 		},

 		_handleReviseClose: function (evt) {
 			var aSelectedItems = evt.getParameter("selectedItems"),
 				oMultiInput = this.byId("reviseBy");

 			if (aSelectedItems && aSelectedItems.length > 0) {
 				aSelectedItems.forEach(function (oItem) {
 					oMultiInput.addToken(new Token({
 						text: oItem.getTitle()
 					}));
 				});
 			}
 		},

 		handleSaveBtnPress: function (oEvent) {
 			debugger;

 			var description = this.getView().byId("C_RTE_details").getValue();
 			var gettoken = this.getView().byId("Assignee").getTokens();
 			var getApprovetoken = this.getView().byId("approveBy").getTokens();
 			var getRevisetoken = this.getView().byId("reviseBy").getTokens();
 			var Approve = '';
 			var Revise = '';
 			var AssigneeId = '';
 			gettoken.forEach(function (item, index) {
 				AssigneeId = AssigneeId + gettoken[index].mProperties.text + ',';
 			});
 			getApprovetoken.forEach(function (item, index) {
 				Approve = Approve + getApprovetoken[index].mProperties.text + ',';
 			});
 			getRevisetoken.forEach(function (item, index) {
 				Revise = Revise + getRevisetoken[index].mProperties.text + ',';
 			});
 			var parentID = this.getView().byId('parentTaskID').getValue();
 			var arr = this.getView().getModel('of4helpmodel').oData.TASK_F4;
 			var TID = '';
 			if (arr) {
 				arr.forEach(function (item) {
 					if (item.LONG_ID === parentID) {
 						TID = item.TID;
 					}
 					// else{
 					// 	TID = item.TID;
 					// }
 				});
 			}
 			var getTasktitle = this.getView().byId("TaskTitle").getValue();
 			var getTaskRemarks = this.getView().byId("Remarks").getValue();
 			var filetype = this.getView().byId("filetype").mProperties.selectedKey;
 			var getTask_type = this.getView().byId("Task_Type");
 			var valueOfTask = getTask_type.mProperties.selectedKey;

 			var getAssignee = this.getView().byId("Assignee").getValue();
 			var EApprove = this.getView().byId('approveBy').mProperties.editable;
 			var ERevise = this.getView().byId('reviseBy').mProperties.editable;

 			if (getTasktitle === "" || valueOfTask === "" || AssigneeId === "" || description === "") {
 				MessageToast.show("Fill all mandatory fields.");
 				return false;
 			}
 			if (EApprove === true && ERevise === true) {
 				if (Approve === "" || Revise === "") {
 					MessageToast.show("Fill all mandatory fields.");
 					return false;
 				}
 			}
 			// if (EApprove === "true" || Approve === "" || ERevise === "true" || Revise === "") {
 			// 	MessageToast.show("Fill all mandatory fields");
 			// 	return false;
 			// }
 			var that = this;
 			var selectedData = oEvent.getSource().getModel("formModel").getData();

 			var oModel12 = {
 				"Tid": TID,
 				"Type": selectedData.TYPE_T,
 				"file_type": filetype,
 				"Title": selectedData.TITLE,
 				"Discription": description,
 				"Assignee": AssigneeId,
 				// "Date": selectedData.AEDAT_C,
 				"Status": selectedData.STATUS,
 				"POT_ID": selectedData.POT_ID,
 				"Remarks": getTaskRemarks,
 				"Priority": selectedData.PRIORITY,
 				"Tat": "",
 				"Tatt": selectedData.TATT,
 				"sap_docnr": selectedData.SAP_DOCNR,
 				"sap_docnm": selectedData.SAP_DOCNM,
 				"Approve_by": Approve,
 				"Revised_by": Revise
 			};
 			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
 				pattern: "yyyy-MM-dd"
 			});
 			oModel12.Tatt = dateFormat.format(new Date(oModel12.Tatt));
 			var oBusy = new sap.m.BusyDialog();
 			// this.Clear();
 			var dialog = new Dialog({
 				title: 'Confirm',
 				type: 'Message',
 				state: 'Success',
 				content: new Text({
 					text: 'Do you want to create the task?'
 				}),
 				beginButton: new Button({
 					type: sap.m.ButtonType.Emphasized,
 					text: 'Yes',
 					press: function () {
 						oBusy.open();
 						datamanager.saveTask(oModel12, function (response) {
 							if (JSON.parse(response.IvJson).MTY === "S") {

 								var a = {};
 								var s = [];
 								that.Files.forEach(function (t, i) {
 									a = {};
 									a.TID = JSON.parse(response.IvJson).TID;
 									a.filename = that.Files[i].filename;
 									a.mimetype = that.Files[i].mimetype;
 									FileValue.forEach(function (e, t) {
 										a.value = FileValue[i];
 									});
 									s.push(a);
 								});
 								// that.fileObject.TID = selectedData.PID.toString();
 								// that.fileObject.value = fileObject2.value;
 								datamanager.sendattachment(s, function (success) {

 									// MessageToast.show("Task has been created successfully ");
 									that.Files = [];
 									if (s.length !== 0) {
 										that.getView().byId("Attachlist").getModel("AttachList").setData(null);
 									}
 									// that.getView().byId("Attachlist").getModel("AttachList").setData(null);
 									FileValue.splice(0, FileValue.length);
 									that.getView().byId("Assignee").destroyTokens();
 									that.getView().byId("TaskTitle").setValue("");
 									// that.getView().byId("TaskDescription").setValue("");
 									that.getView().byId("Remarks").setValue("");
 									that.getView().byId("OpenDate").setValue("");
 									that.fileObject = {};
 									// that.getView().byId("Attachlist").getModel("AttachList").refresh();
 									// that.files = null;
 									// that.getView().byId("Assignee").destroyTokens();
 								}, function (error) {
 									MessageToast.show("Error");
 								});
 								// oBusy.close();
 								MessageToast.show(JSON.parse(response.IvJson).MSG);
 								var oHistory = History.getInstance();
 								var sPreviousHash = oHistory.getPreviousHash();
 								if (sPreviousHash !== undefined) {
 									var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
 									oRouter.navTo("taskList", true);
 									// window.history.go(-1);
 								} else {
 									var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
 									oRouter.navTo("taskList", true);
 								}
 							} else if (JSON.parse(response.IvJson).MTY === "E") {
 								oBusy.close();
 								MessageToast.show(JSON.parse(response.IvJson).MSG);
 							}
 							// oBusy.close();
 						}, function (error) {
 							// oBusy.close();
 							// MessageToast.show("Task has not been created");

 						});

 						dialog.close();
 						oBusy.close();
 					}

 				}),
 				endButton: new Button({
 					text: 'No',
 					press: function () {
 						dialog.close();
 					}
 				}),
 				afterClose: function () {
 					dialog.destroy();
 				}
 			});
 			dialog.open();
 		},

 		changeLive: function (oEvent) {

 			var oValue = oEvent.getParameter("value");
 			var oparentTaskTitle = this.getView().byId("parentTaskTitle");
 			var array = this.of4help.TASK_F4.filter(function (item) {
 				return oValue == item.TID;
 			});
 			if (array.length > 0) {
 				var oTitle = array[0].TITLE;
 				oparentTaskTitle.setValue(oTitle);
 			} else {
 				oparentTaskTitle.setValue("");
 			}
 		},

 		handleEditBtnPress: function (oEvent) {

 			var getTaskRemarks = this.getView().byId("Remarks").getValue();
 			var Parenttask_id = this.getView().byId("parentTaskID").getValue();
 			var getf4help = this.getView().getModel("of4helpmodel").oData.TASK_F4;
 			var TID = "";
 			getf4help.forEach(function (item) {
 				if (item.LONG_ID === Parenttask_id) {
 					TID = item.TID;
 				}

 			});

 			var a = this.getView().byId("Assignee").getTokens();
 			var s = "";
 			a.forEach(function (e, t) {
 				s = s + a[t].mProperties.text + ",";
 			});
 			var Approve = this.getView().byId("approveBy").getTokens();
 			var approve = "";
 			Approve.forEach(function (e, t) {
 				approve = approve + Approve[t].mProperties.text;
 			});
 			var Revise = this.getView().byId("reviseBy").getTokens();
 			var revise = "";
 			Revise.forEach(function (e, t) {
 				revise = revise + Revise[t].mProperties.text;
 			});

 			var selectedData = oEvent.getSource().getModel("formModel").getData();
 			// var AfterRemarks = this.getView().byId("AfterRemarks").getValue();
 			// var Remarks = this.getView().byId("Remarks").getValue();
 			// var oRichConcat = Remarks.concat(AfterRemarks);
 			var oModelEdit = {
 				"Pid": TID,
 				"Tid": selectedData.TID.toString(),
 				"Type": selectedData.TYPE_T,
 				"Departments": selectedData.DEPARTMENT,
 				"Title": selectedData.TITLE,
 				"Discription": selectedData.DISCRIPTION,
 				"Assignee": s,
 				// "Date": ,
 				"Status": selectedData.STATUS,
 				"POT_ID": selectedData.POT_ID,
 				"Remarks": getTaskRemarks,
 				"Priority": selectedData.PRIORITY,
 				"Tatt_aedat": selectedData.AEDAT_C,
 				"Aedat": selectedData.AEDAT,
 				"Aetim": selectedData.AETIM,
 				"Aenam": selectedData.AENAM,
 				"Tatt": selectedData.TATT,
 				"Complete": selectedData.ISCOMPABLE,
 				"sap_docnr": selectedData.SAP_DOCNR,
 				"sap_docnm": selectedData.SAP_DOCNM,
 				"long_id": selectedData.LONG_ID,
 				"file_type": selectedData.FILE_TYPE,
 				"APPROVE_BY": approve,
 				"REVISED_BY": revise
 			};
 			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
 				pattern: "yyyy-MM-dd"
 			});
 			oModelEdit.Tatt = dateFormat.format(new Date(oModelEdit.Tatt));
 			var that = this;
 			var getTasktitle = this.getView().byId("TaskTitle").getValue();
 			var getTaskRemarks = this.getView().byId("Remarks").getValue();
 			var getTask_type = this.getView().byId("Task_Type");
 			var valueOfTask = getTask_type.mProperties.selectedKey;
 			var taskenddate = this.getView().byId("OpenDate").getValue();
 			// var getAssignee = this.getView().byId("Assignee").getValue();
 			if (getTasktitle === "" || getTaskRemarks === "" || valueOfTask === "" || s === "" || taskenddate === "") {
 				MessageToast.show("Fill all mandatory fields.");
 				return false;
 			}
 			var oBusy = new sap.m.BusyDialog();

 			// var dialog = new Dialog({
 			// 	title: "Do you want to edit this task",
 			// 	type: 'Message',
 			// 	state: 'Warning',
 			// 	content: [
 			// 		new sap.m.Label({
 			// 			text: 'Comment : '
 			// 		}),
 			// 		new sap.m.TextArea({
 			// 			rows: 3,
 			// 			cols: 30,
 			// 			maxLength: 250,
 			// 			id: 'editReason'
 			// 		}),
 			// 	],
 			// 	// content: new Text({
 			// 	// 	text: 'Do you want to edit this task?'
 			// 	// }),
 			// 	beginButton: new Button({
 			// 		type: sap.m.ButtonType.Emphasized,
 			// 		text: 'Yes',
 			// 		press: function () {
 			// var comment = sap.ui.getCore().byId('editReason').getValue();
 			// if (comment === "") {
 			// 	MessageToast.show("Fill Comment.");
 			// 	return false;
 			// }
 			// oModelEdit.comment = comment;

 			oBusy.open();
 			datamanager.editTask(oModelEdit, function (response) {
 				if (JSON.parse(response.IvJson).MTY === "S") {
 					var a = {};
 					var s = [];
 					that.Files.forEach(function (t, i) {
 						a = {};
 						a.TID = JSON.parse(response.IvJson).TID;
 						a.filename = that.Files[i].filename;
 						a.mimetype = that.Files[i].mimetype;
 						FileValue.forEach(function (e, t) {
 							a.value = FileValue[i];
 						});
 						s.push(a);
 					});
 					datamanager.sendattachment(s, function (success) {

 						// MessageToast.show("Task has been created successfully ");
 						that.Files = [];
 						if (s.length !== 0) {
 							that.getView().byId("Attachlist").getModel("AttachList").setData(null);
 						}
 						that.getView().byId("Assignee").destroyTokens();
 						that.getView().byId("TaskTitle").setValue("");
 						// that.getView().byId("TaskDescription").setValue("");
 						that.getView().byId("Remarks").setValue("");
 						that.getView().byId("OpenDate").setValue("");
 						that.fileObject = {};
 						// that.files = null;
 						// that.getView().byId("Assignee").destroyTokens();
 					}, function (error) {

 					});
 					oBusy.close();
 					MessageBox.success(JSON.parse(response.IvJson).MSG);
 					var oHistory = History.getInstance();
 					var sPreviousHash = oHistory.getPreviousHash();

 					if (sPreviousHash !== undefined) {
 						window.history.go(-2);
 					} else {
 						var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
 						oRouter.navTo("taskList", true);
 					}
 				} else if (JSON.parse(response.IvJson).MTY === "E") {
 					oBusy.close();
 					MessageBox.error(JSON.parse(response.IvJson).MSG);

 				}
 				oBusy.close();
 			}, function (error) {
 				oBusy.close();

 				MessageToast.show("Task not Updated");
 				// 					var oHistory = History.getInstance();
 				// var sPreviousHash = oHistory.getPreviousHash();
 				// if (sPreviousHash !== undefined) {
 				// 	window.history.go(-2);
 				// } else {
 				// 	var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
 				// 	oRouter.navTo("taskList", true);
 				// }

 			});
 			// 			dialog.close();
 			// 		}

 			// 	}),
 			// 	endButton: new Button({
 			// 		text: 'No',
 			// 		press: function () {
 			// 			oBusy.close();
 			// 			dialog.close();
 			// 		}
 			// 	}),
 			// 	afterClose: function () {
 			// 		dialog.destroy();
 			// 	}
 			// });

 			// dialog.open();
 		},

 		onItemPress: function (oEvent) {
 			debugger;
 			var that = this;

 			if (that.task_id) {
 				var s = oEvent.getParameter("listItem").getBindingContextPath().slice(1);
 				var n = that.getView().getModel("AttachList").getData()[s];
 				that.oFileObject.FID = n.fid;
 				datamanager.getAttachment(that.oFileObject, function (e) {
 						var a = JSON.parse(e.IvJson).value;
 						var s = that.b64toBlob(a, n.mimetype);
 						var o = URL.createObjectURL(s);
 						window.open(o);
 					},
 					function (e) {}
 				);
 			} else {

 				var oIndex = oEvent.getParameter("listItem").getBindingContextPath().slice(1);
 				var i = FileValue[oIndex];
 				var s = that.Files[oIndex].mimetype;
 				var n = that.b64toBlob(i, s);
 				var r = URL.createObjectURL(n);
 				window.open(r);
 			}

 			// var s = oEvent.getParameter("listItem").getBindingContextPath().slice(1);
 			// var n = that.getView().getModel("AttachList").getData()[s];
 			// that.oFileObject.FID = n.fid;
 			// datamanager.getAttachment(that.oFileObject, function (e) {
 			// 		var a = JSON.parse(e.IvJson).value;
 			// 		var s = that.b64toBlob(a, n.mimetype);
 			// 		var o = URL.createObjectURL(s);
 			// 		window.open(o);
 			// 	},
 			// 	function (e) {}
 			// );
 			// // var that = this;
 			// debugger;
 			// var oIndex = oEvent.getParameter("listItem").getBindingContextPath().slice(1);
 			// var i = FileValue[oIndex];
 			// var s = that.Files[oIndex].mimetype;
 			// var n = that.b64toBlob(i, s);
 			// var r = URL.createObjectURL(n);
 			// window.open(r);

 		},

 		Reassign: function (e) {
 			debugger;
 			var t = e.getSource();
 			if (!this.ReassignDialog) {
 				this.ReassignDialog = sap.ui.xmlfragment("zfiori.z_task_mng.fragments.Reasign", this);
 			}
 			var assignee = sap.ui.getCore().getElementById("Assignee12");
 			assignee.destroyTokens();
 			if (this.oTaskData.ASSIGNEE && this.oTaskData.ASSIGNEE.length > 0) {
 				var splitAssigneeArr = this.oTaskData.ASSIGNEE.split(",");
 				splitAssigneeArr.forEach(function (e) {
 					assignee.addToken(new Token({
 						text: e
 					}));
 				});
 			}
 			var n = new sap.ui.model.json.JSONModel;
 			n.setData(this.oTaskData);
 			sap.ui.getCore().getElementById("OpenDate").setValue(new Date(this.oTaskData.TATT));
 			this.ReassignDialog.setModel(n, "selectedTaskDetailsModel");
 			this.ReassignDialog.open();
 		},

 		onClose: function (e) {
 			this.ReassignDialog.close();
 		},

 		onSave: function (e) {
 			debugger;
 			var that = this;
 			var Remarks = that.getView().byId("Remarks").getValue();
 			// var comment = sap.ui.getCore().getElementById("Rem").getValue();
 			// var comment = that.getView().byId("Remarks").getValue();
 			var getmodel = that.getView().getModel("formModel").oData;
 			var assigntoken = sap.ui.getCore().getElementById("Assignee12");
 			// var approve = sap.ui.getCore().getElementById("approveBy");
 			// var getapprovetoken = approve.getTokens();
 			// var revise = sap.ui.getCore().getElementById("reviseBy");
 			// var getrevisetoken = revise.getTokens();
 			// var getappval = "";
 			// var getreval = "";
 			var n = "";
 			var o = that.task_id;
 			var r = assigntoken.getTokens();
 			r.forEach(function (e, t) {
 				n = n + r[t].getText() + ","
 			});

 			// getapprovetoken.forEach(function (e, t) {
 			// 	getappval = getappval + getapprovetoken[t].getText();
 			// });

 			// getrevisetoken.forEach(function (e, t) {
 			// 	getreval = getreval + getrevisetoken[t].getText();
 			// });
 			var u = sap.ui.getCore().getElementById("OpenDate").getDateValue();
 			// var u2 = sap.ui.getCore().getElementById("OpenDate1").getDateValue();
 			var oModelReassign = {
 				// "Pid": getmodel.PID.toString(),
 				"Tid": getmodel.TID.toString(),
 				// "Type": getmodel.TYPE_T,
 				// "Title": getmodel.TITLE,
 				// "Discription": getmodel.DISCRIPTION,
 				"Assignee": n,
 				// "Date": ,
 				// "Status": getmodel.STATUS,
 				// "POT_ID": getmodel.POT_ID,
 				"comment": Remarks,
 				// "Priority": getmodel.PRIORITY,
 				// "Tatt_aedat": getmodel.AEDAT_C,
 				"Aedat": getmodel.AEDAT,
 				// "Aetim": getmodel.AETIM,
 				// "Aenam": getmodel.AENAM,
 				"Tatt": getmodel.TATT,
 				// "Complete": getmodel.ISCOMPABLE,
 				// "Doc Ref name": getmodel.SAP_DOCNM,
 				// "Doc ref no": getmodel.SAP_DOCNR,
 				// "long_id": getmodel.LONG_ID,
 				// // "type": getmodel.TYPE,
 				// "APPROVE_BY": getappval,
 				// "REVISED_BY": getreval
 			};
 			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
 				pattern: "yyyy-MM-dd"
 			});
 			oModelReassign.Tatt = dateFormat.format(new Date(oModelReassign.Tatt));
 			oModelReassign.Aedat = dateFormat.format(new Date(oModelReassign.Aedat));
 			// oModelReassign.Remarks = Remarks;
 			if (n != "" && Remarks != "") {
 				// var h = this;
 				// that.onClear();
 				var oBusy = new sap.m.BusyDialog();
 				oBusy.open();
 				datamanager.getReassigne(oModelReassign, function (e) {

 					if (JSON.parse(e.IvJson).MTY === "S") {

 						var a = {};
 						var s = [];
 						that.Files.forEach(function (t, i) {
 							a = {};
 							a.TID = JSON.parse(e.IvJson).TID;
 							a.filename = that.Files[i].filename;
 							a.mimetype = that.Files[i].mimetype;
 							FileValue.forEach(function (e, t) {
 								a.value = FileValue[i];
 							});
 							s.push(a);
 						});
 						datamanager.sendattachment(s, function (success) {

 							// MessageToast.show("Task has been created successfully ");
 							that.Files = [];
 							if (s.length !== 0) {
 								that.getView().byId("Attachlist").getModel("AttachList").setData(null);
 							}
 							that.getView().byId("Assignee").destroyTokens();
 							that.getView().byId("TaskTitle").setValue("");
 							// that.getView().byId("TaskDescription").setValue("");
 							that.getView().byId("Remarks").setValue("");
 							that.getView().byId("OpenDate").setValue("");
 							that.fileObject = {};
 							// that.files = null;
 							// that.getView().byId("Assignee").destroyTokens();
 						}, function (error) {

 						});

 						assigntoken.destroyTokens();
 						that.getView().byId("Remarks").setValue('');
 						oBusy.close();
 						MessageToast.show(JSON.parse(e.IvJson).MSG);
 						that.ReassignDialog.close();
 						var a = History.getInstance();
 						var n = a.getPreviousHash();
 						if (n !== undefined) {
 							window.history.go(-2);
 						} else {
 							var o = sap.ui.core.UIComponent.getRouterFor(that);
 							o.navTo("taskList", true);
 						}

 					} else if (JSON.parse(e.IvJson).MTY === "E") {
 						oBusy.close();
 						MessageToast.show(JSON.parse(e.IvJson).MSG);
 					}
 					oBusy.close();
 				}, function (e) {
 					oBusy.close();
 					// i.show("Task has not been Reassigned");
 				});
 				oBusy.close();
 			} else {
 				MessageToast.show("Please Fill Required Fields!");
 			}
 		},

 		getAssignData: function (e) {
 			var t = e.getSource().getValue();
 			if (!this._RvalueHelpDialog) {
 				Fragment.load({
 					name: "zfiori.z_task_mng.fragments.R-AssignTasklist",
 					controller: this
 				}).then(function (e) {
 					this._RvalueHelpDialog = e;
 					this.getView().addDependent(this._RvalueHelpDialog);
 					this._openValueHelpDialog(t);
 				}.bind(this));
 			} else {
 				this._openValueHelpDialog(t);
 			}
 		},
 		CgetAssignData: function (e) {
 			var t = e.getSource().getValue();
 			if (!this._valueHelpDialog) {
 				Fragment.load({
 					name: "zfiori.z_task_mng.fragments.AssignTaskList",
 					controller: this
 				}).then(function (e) {
 					this._valueHelpDialog = e;
 					this.getView().addDependent(this._valueHelpDialog);
 					this._CopenValueHelpDialog(t);
 				}.bind(this));
 			} else {
 				this._CopenValueHelpDialog(t);
 			}
 		},

 		_openValueHelpDialog: function (e) {
 			this._RvalueHelpDialog.getBinding("items").filter([new Filter("USRID", FilterOperator.Contains, e)]);
 			this._RvalueHelpDialog.open(e);
 		},

 		_CopenValueHelpDialog: function (e) {
 			this._valueHelpDialog.getBinding("items").filter([new Filter("USRID", FilterOperator.Contains, e)]);
 			this._valueHelpDialog.open(e);
 		},

 		// _handleValueHelpClose: function (e) {
 		// 	var t = e.getParameter("selectedItems"),
 		// 		a = sap.ui.getCore().getElementById("Assignee");
 		// 	if (t && t.length > 0) {
 		// 		t.forEach(function (e) {
 		// 			a.addToken(new Filter({
 		// 				text: e.getTitle()
 		// 			}));
 		// 		});
 		// 	}
 		// },

 		// _handleValueHelpClose: function (evt) {
 		// 	var that = this;
 		// 	var aSelectedItems = evt.getParameter("selectedItems");
 		// 	var getitem = evt.oSource._oList._aSelectedPaths;

 		// 	// var getf4list = this.getView().getModel("of4helpmodel").oData.USRID;
 		// 	// var evt.oSource._oList._aSelectedPaths;
 		// 	var oMultiInput = sap.ui.getCore().byId('Assignee')
 		// 	if (getitem && getitem.length > 0) {
 		// 		getitem.forEach(function (oitem, index) {
 		// 			var oIndex = getitem[index].slice(7);
 		// 			var getf4list = that.getView().getModel("of4helpmodel").getData().USRID[oIndex];
 		// 			oMultiInput.addToken(new Token({
 		// 				text: getf4list.USRID
 		// 			}));
 		// 		});
 		// 	}

 		// 	// if (aSelectedItems && aSelectedItems.length > 0) {
 		// 	// aSelectedItems.forEach(function (oItem) {
 		// 	// 	oMultiInput.addToken(new Token({
 		// 	// 		text: oItem.getTitle()
 		// 	// 	}));
 		// 	// });
 		// },

 		b64toBlob: function (b64Data, contentType, sliceSize) {

 			contentType = contentType || '';
 			sliceSize = sliceSize || 512;
 			var oContent = atob(b64Data);
 			var binaryArrays = [];
 			for (var a = 0; a < oContent.length; a += sliceSize) {
 				var contentSlice = oContent.slice(a, a + sliceSize);
 				var contentSliceLength = new Array(contentSlice.length);
 				for (var i = 0; i < contentSlice.length; i++) {
 					contentSliceLength[i] = contentSlice.charCodeAt(i);
 				}
 				var binaryArray = new Uint8Array(contentSliceLength);
 				binaryArrays.push(binaryArray);
 			}
 			var blob = new Blob(binaryArrays, {
 				type: contentType
 			});
 			return blob;
 		},
 		buff: function (e) {
 			var t = this;

 			var a = e.target.result;
 			arrayToBinary(a);
 		},

 		attachment: function (oEvent) {
 			var t = this;
 			this.reader = new FileReader;
 			var getlist = t.getView().byId("Attachlist");
 			// getlist.setMode("Delete");
 			var a = this.getView().byId("Attachlist");
 			var fileuploader = this.getView().byId("fileUploader");
 			var i = oEvent.getParameter("files")[0];
 			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
 				pattern: "yyyy-MM-dd"
 			});
 			t.fileObject = {};
 			t.fileObject.mimetype = i.type;
 			if (t.fileObject.mimetype !== "application/pdf") {
 				MessageToast.show("Only PDF file attach");
 				fileuploader.clear();
 				return false;
 			}
 			t.fileObject.filename = i.name;
 			t.fileObject.sydats = dateFormat.format(new Date(i.lastModifiedDate));
 			// t.fileObject.mode = "Delete";
 			this.reader.readAsArrayBuffer(i);
 			this.reader.onload = t.buff;

 			// for(var i = 0; i < this.getView().getModel('AttachList').getData().length ; i++ ){
 			//     t.Files.push(this.getView().getModel('AttachList').getData()[i]); 
 			// }
 			t.Files.push(t.fileObject);

 			var n = new JSONModel(t.Files);
 			this.getView().setModel(n, 'AttachList');
 			this.getView().getModel("AttachList");
 			a.getModel("AttachList").setData(t.Files);
 			var r = this.getView().byId("fileUploader");
 			r.clear();

 		},
 		// typeMissmatch: function (oEvent) {
 		// 	var aFileTypes = oEvent.getSource().getFileType();
 		// 	jQuery.each(aFileTypes, function (key, value) {
 		// 		aFileTypes[key] = "*." + value;
 		// 	});
 		// 	var sSupportedFileTypes = aFileTypes.join(", ");
 		// 	var msg = this.getView().getModel("i18n").getResourceBundle().getText("FileTypeIsNotSupported");

 		// 	MessageToast.show(msg + oEvent.getParameter("fileType"));
 		// 	//  MessageToast.show("File type: " + oEvent.getParameter("fileType") + " is not supported.");
 		// },

 		handleFileDelete: function (oEvent) {
 			var that = this;
 			// if (that.task_id) {
 			// 	var arrattachment = [];
 			// 	var selectedData = oEvent.getSource().getModel("AttachList").getData();
 			// 	var Attachlist = that.getView().byId("Attachlist");
 			// 	// var delCheck = false;
 			// 	// if (that.uname === that.oTaskData.AENAM) {
 			// 	// 	var delCheck = Attachlist.mProperties.visible

 			// 	// }
 			// 	var oItem = oEvent.getParameter("listItem"),
 			// 		sPath = oItem.getBindingContext("AttachList").getPath(),
 			// 		oIndex = sPath.split("/");
 			// 	var nindex = sPath[sPath.length - 1];
 			// 	var oSelectedattach = that.oTaskAttach[nindex];
 			// 	that.oFileObject.FID = oSelectedattach.fid;

 			// 	datamanager.getAttachment(that.oFileObject, function (e) {
 			// 			var a = JSON.parse(e.IvJson).value;
 			// 			var attachmModel = {
 			// 				"endda": "",
 			// 				"fid": oSelectedattach.fid,
 			// 				"filename": oSelectedattach.filename,
 			// 				"mimetype": oSelectedattach.mimetype,
 			// 				"sydats": oSelectedattach.sydats,
 			// 				"sytims": oSelectedattach.sytims,
 			// 				"tid": oSelectedattach.tid,
 			// 				"value": a,
 			// 				"version": oSelectedattach.version
 			// 			};
 			// 			arrattachment.push(attachmModel);
 			// 			datamanager.sendattachment(arrattachment, function (e) {
 			// 					var oModel = JSON.parse(e.IvJson);
 			// 					var Attachlist = that.getView().byId("Attachlist");
 			// 					var array = [];
 			// 					var getattachments = that.getView().byId("Attachlist").getModel("AttachList").oData;
 			// 					var getattchvalue = "";
 			// 					getattachments.forEach(function (item, index) {
 			// 						getattchvalue = item.fid;
 			// 					});
 			// 					for (var i = 0; i < getattachments.length; i++) {
 			// 						var attachmentFid = that.getView().byId("Attachlist").getModel("AttachList").oData[i].fid;
 			// 						if (getattchvalue !== attachmentFid) {
 			// 							array.push(getattachments[i]);
 			// 						}
 			// 					}
 			// 					getattachments = array;
 			// 					var oListModel = new JSONModel(getattachments);
 			// 					Attachlist.setModel(oListModel, "AttachList");
 			// 					that.getView().getModel('AttachList').refresh();

 			// 				},

 			// 				function (e) {
 			// 					MessageToast.show(" error ");
 			// 				});

 			// 		},
 			// 		function (e) {
 			// 			MessageToast.show(" error ");
 			// 		}
 			// 	);

 			// } else {
 			var Attachlist = that.getView().byId("Attachlist");
 			var oItem = oEvent.getParameter("listItem"),
 				sPath = oItem.getBindingContext("AttachList").getPath(),
 				oIndex = sPath.split("/");
 			that.Files.splice(oIndex[1], 1);
 			FileValue.splice(oIndex[1], 1);
 			var oListModel = new JSONModel(that.Files);
 			Attachlist.setModel(oListModel, "AttachList");
 			// that.Files.forEach(function (obj, index) {
 			// 	obj.ATTACHMENT_INDEX = index + 1;
 			// });
 			// }

 		},
 		oChangeEvent: function (Event) {
 			var that = this;
 			if (Event.oSource.mProperties.selectedKey === "4" || Event.oSource.mProperties.selectedKey === "M" || Event.oSource.mProperties.selectedKey ===
 				"N" || Event.oSource.mProperties.selectedKey === "O") {
 				that.getView().byId("approveBy").destroyTokens();
 				that.getView().byId("approveBy").setEditable(false);
 				that.getView().byId("reviseBy").destroyTokens();
 				that.getView().byId("reviseBy").setEditable(false);
 			} else {
 				that.getView().byId("approveBy").setEditable(true);
 				that.getView().byId("reviseBy").setEditable(true);
 			}
 		},
 		onNavBack: function () {
 			debugger;
 			var that = this;
 			that.getView().byId("Remarks").setValue("");
 			that.getView().byId("Assignee").destroyTokens();
 			if (that.Files.length !== 0) {

 				that.getView().byId("Attachlist").getModel("AttachList").setData(null);
 			}

 			while (that.Files.length > 0 || FileValue > 0) {
 				that.Files.pop();
 				FileValue.pop();
 			}
 			// that.getView().getModel('AttachList').refresh();
 			var oHistory = History.getInstance();
 			var sPreviousHash = oHistory.getPreviousHash();
 			if (sPreviousHash !== undefined) {
 				var n = sap.ui.core.UIComponent.getRouterFor(this);
 				n.navTo("taskList", true);
 				// window.history.go(-1);
 			} else {
 				var n = sap.ui.core.UIComponent.getRouterFor(this);
 				n.navTo("taskList", true);
 			}

 		}

 	});

 });