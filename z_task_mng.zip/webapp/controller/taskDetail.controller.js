var FileValue = [];
var FileObj = {};

function arrayToBinary(e) {

	var t = "";
	var a = new Uint8Array(e);
	var i = a.byteLength;
	for (var s = 0; s < i; s++) {
		t += String.fromCharCode(a[s]);
	}
	var n = btoa(t);
	FileObj.value = n;
	FileValue.push(n);
}
sap.ui.define(["sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"zfiori/z_task_mng/utils/datamanager",
	"sap/ui/model/json/JSONModel",
	"zfiori/z_task_mng/model/formatter",
	"sap/m/MessageBox",
	"sap/m/MessageToast",
	"sap/ui/Device",
	"sap/m/Button",
	"sap/m/Dialog",
	"sap/m/MessageStrip",
	"sap/m/Text",
	"sap/ui/core/Fragment",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/Filter",
	"sap/m/Token",
	"sap/m/TextArea",
	"sap/m/ButtonType",
	'sap/m/MessageToast',
], function (e, t, a, s, n, o, i, r, l, g, u, c, h, p, d, f, TextArea, ButtonType, MessageToast) {
	"use strict ";
	var v = "";
	return e.extend("zfiori.z_task_mng.controller.taskDetail", {
		pageState: {
			edit: true,
			complete: true
		},
		formatter: n,
		oTasksDetail: {},
		oTaskAttach: {},
		oFileObject: {},
		onInit: function () {
			this.getOwnerComponent().getRouter().getRoute("taskDetail").attachMatched(this.onNavToCurrentPage, this);
		},

		onNavToCurrentPage: function (e) {
			var oBusy = new sap.m.BusyDialog();
			var t = this;
			// var pageModel = new JSONModel(t.pageState);
			// t.getView().setModel(pageModel, "pageModel");
			v = e.getParameter("arguments").taskId;
			oBusy.open();
			a.getAttachmentList(v, function (e) {
					debugger;
					t.oTaskAttach = JSON.parse(e.IvJson);
					var a = new s(t.oTaskAttach);
					t.getView().setModel(a, "Attachmentlist");
					sap.ui.getCore().setModel(a, "Attachmentlist");
					oBusy.close();
				},
				function (e) {});

			a.getTaskDetails(v, function (e) {
					t.oTasksDetail = JSON.parse(e.IvJson);
					// var DISCRIPTION = decodeURI(t.oTasksDetail.DISCRIPTION)
					// t.oTasksDetail.DISCRIPTION = DISCRIPTION;
					// var richtext = $("<div/>").html(t.oTasksDetail.DISCRIPTION).text();
					// t.oTasksDetail.DISCRIPTION = richtext;
					var a = new s(t.oTasksDetail);
					t.getView().setModel(a, "selectedTaskDetailsModel");
					var editstatus = t.getView().getModel("selectedTaskDetailsModel").getData();
					if (editstatus.ISCOMPABLE === "0") {
						t.pageState.complete = true; //  block of code to be executed if condition1 is true
					} else if (editstatus.ISCOMPABLE === "1") {
						t.pageState.complete = false; //  block of code to be executed if the condition1 is false and condition2 is true
					}
					if (editstatus.STATUS === "O") {
						t.pageState.edit = true; //  block of code to be executed if condition1 is true
						// t.pageState.complete = true;
					} else if (editstatus.STATUS === "C") {
						t.pageState.edit = false; //  block of code to be executed if the condition1 is false and condition2 is true
						t.pageState.complete = false;
					}
					var RTE_details = t.getView().byId("RTE_details");
					var objDes = {
						Discription: false
					};
					var oDes = new s(objDes);
					t.getView().setModel(oDes, 'oDes');
					setTimeout(function () {
						RTE_details.setValue(t.oTasksDetail.DISCRIPTION);
					}, 1000);
					console.log(t.oTasksDetail);
					var pageModel = new s(t.pageState);
					t.getView().setModel(pageModel, "pageModel");
				},
				function (e) {});
			a.getF4helpdata(function (e) {
				t.of4help = JSON.parse(e.IvJson);
				var a = new s(t.of4help);
				t.getView().setModel(a, "of4helpmodel");
				console.log(t.of4help);

			})
			oBusy.open();
		},
		onNavBack: function () {
			var e = t.getInstance();
			var a = e.getPreviousHash();
			if (a !== undefined) {
				window.history.go(-1);
			} else {
				var s = sap.ui.core.UIComponent.getRouterFor(this);
				s.navTo("RoutemainPage", true);
			}
		},
		handleEditPress: function (e) {
			window.attachments = this.getView().getModel("Attachmentlist").oData
			var t = sap.ui.core.UIComponent.getRouterFor(this);
			t.navTo("taskCreate", {
				taskId: this.oTasksDetail.TID
			});
		},
		onItemPress: function (e) {
			var t = this;
			var s = e.getParameter("listItem").getBindingContextPath().slice(1);
			var n = t.getView().getModel("Attachmentlist").getData()[s];
			t.oFileObject.FID = n.fid;
			a.getAttachment(t.oFileObject, function (oEvent) {
					var a = JSON.parse((oEvent.IvJson)).value;
					var s = t.b64toBlob(a, n.mimetype);
					var o = URL.createObjectURL(s);
					window.open(o);
				},
				function (e) {}
			);
		},

		onPrint: function (oEvent) {
			var that = this;
			getTaskid = that.getView().getModel("selectedTaskDetailsModel").oData.TID;
			a.getprintattachment(getTaskid, function (response) {

					that.pfd_contant = JSON.parse(response.IvJson);
					var pdfurl = that.pfd_contant.value;
					var mimetype = that.pfd_contant.mimetype;

					var blob = that.b64toBlob(pdfurl, mimetype);
					var blobUrl = URL.createObjectURL(blob);
					window.open(blobUrl);

				},
				function (error) {
					i.show(" Attachment Error ");

				});

		},
		b64toBlob: function (e, t, a) {
			t = t || "";
			a = a || 512;
			var s = atob(e);
			var n = [];
			for (var o = 0; o < s.length; o += a) {
				var i = s.slice(o, o + a);
				var r = new Array(i.length);
				for (var l = 0; l < i.length; l++) {
					r[l] = i.charCodeAt(l);
				}
				var g = new Uint8Array(r);
				n.push(g);
			}
			var u = new Blob(n, {
				type: t
			});
			return u;
		},
		// Reassign: function (e) {
		// 	debugger;
		// 	var t = e.getSource();
		// 	if (!this.ReassignDialog) {
		// 		this.ReassignDialog = sap.ui.xmlfragment("zfiori.z_task_mng.fragments.Reasign", this);
		// 	}
		// 	var assignee = sap.ui.getCore().getElementById("Assignee");
		// 	// var approveby = sap.ui.getCore().getElementById("approveBy");
		// 	// var reviseby = sap.ui.getCore().getElementById("reviseBy");
		// 	assignee.destroyTokens();
		// 	// approveby.destroyTokens();
		// 	// reviseby.destroyTokens();
		// 	if (this.oTasksDetail.ASSIGNEE && this.oTasksDetail.ASSIGNEE.length > 0) {
		// 		var splitAssigneeArr = this.oTasksDetail.ASSIGNEE.split(",");
		// 		splitAssigneeArr.forEach(function (e) {
		// 			assignee.addToken(new f({
		// 				text: e
		// 			}));
		// 		});
		// 	}
		// 	var n = new sap.ui.model.json.JSONModel;
		// 	n.setData(this.oTasksDetail);
		// 	// sap.ui.getCore().getElementById("OpenDate").setValue(new Date(this.oTasksDetail.TATT));
		// 	this.ReassignDialog.setModel(n, "selectedTaskDetailsModel");
		// 	this.ReassignDialog.open();
		// },
		onValueHelpOkPress: function (e) {
			var t = e.getParameter("tokens");
			this._oMultiInput.setTokens(t);
			this._oValueHelpDialog.close();
		},

		getAssignData: function (e) {
			var t = e.getSource().getValue();
			if (!this._valueHelpDialog) {
				h.load({
					name: "zfiori.z_task_mng.fragments.AssignTaskList",
					controller: this
				}).then(function (e) {
					this._valueHelpDialog = e;
					this.getView().addDependent(this._valueHelpDialog);
					this._openValueHelpDialog(t);
				}.bind(this));
			} else {
				this._openValueHelpDialog(t);
			}
		},
		_openValueHelpDialog: function (e) {
			this._valueHelpDialog.getBinding("items").filter([new d("USRID", p.Contains, e)]);
			this._valueHelpDialog.open(e);
		},
		_handleValueHelpSearch: function (e) {
			var t = e.getParameter("value");
			var a = new d("USRID", p.Contains, t);
			e.getSource().getBinding("items").filter([a]);
		},
		_handleValueHelpClose: function (e) {
			var t = e.getParameter("selectedItems"),
				a = sap.ui.getCore().getElementById("Assignee");
			if (t && t.length > 0) {
				t.forEach(function (e) {
					a.addToken(new f({
						text: e.getTitle()
					}));
				});
			}
		},

		getReviseData: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();

			// create value help dialog
			if (!this._valueReviseDialog) {
				h.load({
					name: "zfiori.z_task_mng.fragments.Revise",
					controller: this
				}).then(function (oValueHelpDialog) {
					this._valueReviseDialog = oValueHelpDialog;
					this.getView().addDependent(this._valueReviseDialog);
					this._openReviseDialog(sInputValue);
				}.bind(this));
			} else {
				this._openReviseDialog(sInputValue);
			}
		},
		_openReviseDialog: function (sInputValue) {
			// create a filter for the binding
			this._valueReviseDialog.getBinding("items").filter([new d(
				"USRID",
				p.Contains,
				sInputValue
			)]);

			// open value help dialog filtered by the input value
			this._valueReviseDialog.open(sInputValue);
		},
		_handleReviseValueHelpSearch: function (evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new d(
				"USRID",
				p.Contains,
				sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},
		_handleReviseClose: function (e) {
			var t = e.getParameter("selectedItems"),
				a = sap.ui.getCore().getElementById("reviseBy");
			if (t && t.length > 0) {
				t.forEach(function (e) {
					a.addToken(new f({
						text: e.getTitle()
					}));
				});
			}
		},

		getApproveData: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();

			// create value help dialog
			if (!this._valueApproveDialog) {
				h.load({
					name: "zfiori.z_task_mng.fragments.Approve",
					controller: this
				}).then(function (oValueHelpDialog) {
					this._valueApproveDialog = oValueHelpDialog;
					this.getView().addDependent(this._valueApproveDialog);
					this._openApproveDialog(sInputValue);
				}.bind(this));
			} else {
				this._openApproveDialog(sInputValue);
			}
		},
		_openApproveDialog: function (sInputValue) {
			// create a filter for the binding
			this._valueApproveDialog.getBinding("items").filter([new d(
				"USRID",
				p.Contains,
				sInputValue
			)]);

			// open value help dialog filtered by the input value
			this._valueApproveDialog.open(sInputValue);
		},
		_handleApproveValueHelpSearch: function (evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new d(
				"USRID",
				p.Contains,
				sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},
		_handleApproveClose: function (e) {
			var t = e.getParameter("selectedItems"),
				a = sap.ui.getCore().getElementById("approveBy");
			if (t && t.length > 0) {
				t.forEach(function (e) {
					a.addToken(new f({
						text: e.getTitle()
					}));
				});
			}
		},

		// onSave: function (e) {
		// 	debugger;
		// 	var getmodel = this.getView().getModel("selectedTaskDetailsModel").oData;
		// 	var s = sap.ui.getCore().getElementById("Assignee");
		// 	// var approve = sap.ui.getCore().getElementById("approveBy");
		// 	// var getapprovetoken = approve.getTokens();
		// 	// var revise = sap.ui.getCore().getElementById("reviseBy");
		// 	// var getrevisetoken = revise.getTokens();
		// 	// var getappval = "";
		// 	// var getreval = "";
		// 	var n = "";
		// 	var o = v;
		// 	var r = s.getTokens();
		// 	r.forEach(function (e, t) {
		// 		n = n + r[t].getText() + ","
		// 	});

		// 	// getapprovetoken.forEach(function (e, t) {
		// 	// 	getappval = getappval + getapprovetoken[t].getText();
		// 	// });

		// 	// getrevisetoken.forEach(function (e, t) {
		// 	// 	getreval = getreval + getrevisetoken[t].getText();
		// 	// });
		// 	var u = sap.ui.getCore().getElementById("OpenDate").getDateValue();
		// 	// var u2 = sap.ui.getCore().getElementById("OpenDate1").getDateValue();
		// 	var oModelReassign = {
		// 		// "Pid": getmodel.PID.toString(),
		// 		"Tid": getmodel.TID.toString(),
		// 		// "Type": getmodel.TYPE_T,
		// 		// "Title": getmodel.TITLE,
		// 		// "Discription": getmodel.DISCRIPTION,
		// 		"Assignee": n,
		// 		// "Date": ,
		// 		// "Status": getmodel.STATUS,
		// 		// "POT_ID": getmodel.POT_ID,
		// 		// "Remarks": getmodel.REMARKS,
		// 		// "Priority": getmodel.PRIORITY,
		// 		// "Tatt_aedat": getmodel.AEDAT_C,
		// 		"Aedat": getmodel.AEDAT,
		// 		// "Aetim": getmodel.AETIM,
		// 		// "Aenam": getmodel.AENAM,
		// 		"Tatt": u,
		// 		// "Complete": getmodel.ISCOMPABLE,
		// 		// "Doc Ref name": getmodel.SAP_DOCNM,
		// 		// "Doc ref no": getmodel.SAP_DOCNR,
		// 		// "long_id": getmodel.LONG_ID,
		// 		// // "type": getmodel.TYPE,
		// 		// "APPROVE_BY": getappval,
		// 		// "REVISED_BY": getreval
		// 	};
		// 	var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
		// 		pattern: "yyyy-MM-dd"
		// 	});
		// 	oModelReassign.Tatt = dateFormat.format(new Date(oModelReassign.Tatt));
		// 	oModelReassign.Aedat = dateFormat.format(new Date(oModelReassign.Aedat));
		// 	if (n !== "" && u !== "") {
		// 		var h = this;
		// 		h.onClear();
		// 		var oBusy = new sap.m.BusyDialog();
		// 		// var p = new g({
		// 		// 	title: "Do you want to Reassign this task",
		// 		// 	type: "Message",
		// 		// 	state: "Warning",
		// 		// 	// content: new c({
		// 		// 	// 	text: "Do you want to really Reassign this task"
		// 		// 	// }),
		// 		// 	content: [
		// 		// 		new sap.m.Label({
		// 		// 			text: 'Comment : '
		// 		// 		}),
		// 		// 		new sap.m.TextArea({
		// 		// 			rows: 3,
		// 		// 			cols: 30,
		// 		// 			maxLength: 250,
		// 		// 			id: 'RejectReason'
		// 		// 		}),
		// 		// 	],
		// 		// 	beginButton: new l({
		// 		// 		type: sap.m.ButtonType.Emphasized,
		// 		// 		text: "Yes",
		// 		// 		press: function () {
		// 		// 			var comment = sap.ui.getCore().byId('RejectReason').getValue();
		// 		// 			if (comment === "") {
		// 		// 				MessageToast.show("Fill Comment.");
		// 		// 				return false;
		// 		// 			}
		// 		// oModelReassign.comment = comment;
		// 		oBusy.open();
		// 		a.getReassigne(oModelReassign, function (e) {

		// 			if (JSON.parse(e.IvJson).MTY === "S") {
		// 				s.destroyTokens();
		// 				oBusy.close();
		// 				i.show(JSON.parse(e.IvJson).MSG);
		// 				var a = t.getInstance();
		// 				var n = a.getPreviousHash();
		// 				if (n !== undefined) {
		// 					window.history.go(-1);
		// 				} else {
		// 					var o = sap.ui.core.UIComponent.getRouterFor(this);
		// 					o.navTo("taskList", true);
		// 				}

		// 			} else if (JSON.parse(e.IvJson).MTY === "E") {
		// 				oBusy.close();
		// 				i.show(JSON.parse(e.IvJson).MSG);
		// 			}
		// 			oBusy.close();
		// 		}, function (e) {
		// 			oBusy.close();
		// 			// i.show("Task has not been Reassigned");
		// 		});
		// 		p.close();
		// 	} else {
		// 		i.show("Please Fill Required Fields!");
		// 	}
		// },

		Complete: function (e) {
			let s = 100;
			var n = v;
			var oBusy = new sap.m.BusyDialog();
			// var p = new g({
			// 	title: "Do you want to complete this task ",
			// 	type: "Message",
			// 	state: "Warning",
			// 	content: [
			// 		new sap.m.Label({
			// 			text: 'Comment : '
			// 		}),
			// 		new sap.m.TextArea({
			// 			rows: 3,
			// 			cols: 30,
			// 			maxLength: 250,
			// 			id: 'RejectReason'
			// 		}),
			// 	],
			// 	// content: new c({
			// 	// 	text: "Do you want to really Complete this task?"
			// 	// }),
			// 	beginButton: new l({
			// 		type: sap.m.ButtonType.Emphasized,
			// 		text: "Yes",
			// 		press: function () {
			// 			var comment = sap.ui.getCore().byId('RejectReason').getValue();
			oBusy.open();
			a.getComplete(n, s, function (e) {
					if (JSON.parse(e.IvJson).MTY === "S") {
						oBusy.close();
						i.show(JSON.parse(e.IvJson).MSG);
						var a = t.getInstance();
						var s = a.getPreviousHash();
						if (s !== undefined) {
							window.history.go(-1);
						} else {
							var n = sap.ui.core.UIComponent.getRouterFor(this);
							n.navTo("taskList", true);
						}
					} else if (JSON.parse(e.IvJson).MTY === "E") {
						oBusy.close();
						i.show(JSON.parse(e.IvJson).MSG);
					}
					// oBusy.close();
				},
				function (e) {
					oBusy.close();
					i.show(JSON.parse(e.IvJson).MSG);
				});
			// 			p.close();
			// 		}

			// 	}),
			// 	endButton: new l({
			// 		text: "No",
			// 		press: function () {
			// 			p.close();
			// 		}
			// 	}),
			// 	afterClose: function () {
			// 		p.destroy();
			// 	}
			// });
			// p.open();
		},

		buff: function (e) {},

		attachment: function (e) {},

		// onClose: function (e) {
		// 	this.ReassignDialog.close();
		// },

		onClear: function (e) {
			sap.ui.getCore().getElementById("Assignee").setValue(null);
		}
	})
});