sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("zfiori.z_task_mng.controller.App", {
	
		// var getmodel = sap.ui.getCore().byId("gridList").getModel("tableModel");

	});
});