sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/Sorter",
	"sap/ui/model/Filter",
	"sap/ui/core/Fragment",
	"sap/m/Dialog",
	"zfiori/z_task_mng/model/formatter",
	"zfiori/z_task_mng/utils/datamanager",
	"sap/m/MessageBox",
	"sap/m/MessageToast",
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device"
], function (Controller, Sorter, Filter, Fragment, Dialog, formatter, datamanager, MessageBox, MessageToast, JSONModel, Device) {
	"use strict";

	return Controller.extend("zfiori.z_task_mng.controller.taskList", {
		formatter: formatter,

		oTasksList: [],
		clicks: "null",
		initialCount: "null",

		onInit: function (oEvent) {
			this.getOwnerComponent().getRouter().getRoute("taskList").attachMatched(this.onNavToCurrentPage, this);
		},

		onNavToCurrentPage: function () {

			var that = this;
			that.getView().setModel(new JSONModel({
				width: (Device.system.phone) ? "50em" : "100em"
			}));
			// var pageno = 20;
			datamanager.getTasksListData(function (response) {
				that.oTasksList = JSON.parse(response.IvJson);
				that.oTasksList.sort(function (a, b) {
					if (a.TID > b.TID) {
						return -1;
					}
					if (a.TID < b.TID) {
						return 1;
					}
					return 0;
				});
				var oTasksListModel = new JSONModel(that.oTasksList);
				that.getView().setModel(oTasksListModel, "TaskListModel");
				console.log(that.oTasksList);
			}, function (error) {
				MessageToast.show("Data load Complete");
			});
		},

		ActivePress: function (oEvent) {
			debugger;
			var that = this;
			var ActiveTable = [];
			var Active = "Active";
			var path = oEvent.oSource.oPropagatedProperties.oBindingContexts.TaskListModel.sPath;
			var patharray = path.split('/');
			var nindex = patharray[patharray.length - 1];
			var oSelectedTask = this.oTasksList[nindex];
			var Tid = oSelectedTask.TID;
			var ActiveModel = {
				Active: "X",
				Tid: Tid,
			};
			ActiveTable.push(ActiveModel);
			datamanager.ActiveTask(ActiveTable, function (e) {
					MessageToast.show("Task has been Activated");
					datamanager.getTasksListData(function (response) {
						that.oTasksList = JSON.parse(response.IvJson);
						that.oTasksList.sort(function (a, b) {
							if (a.TID > b.TID) {
								return -1;
							}
							if (a.TID < b.TID) {
								return 1;
							}
							return 0;
						});
						var oTasksListModel = new JSONModel(that.oTasksList);
						that.getView().setModel(oTasksListModel, "TaskListModel");
						console.log(that.oTasksList);
					}, function (error) {
						MessageToast.show("Data load Complete");
					});
					// var activeResult = JSON.parse(e.IvJson);
					// if (activeResult.ACTIVE !== "") {
					// 	MessageToast.show("Task has been deactivated");
					// 	datamanager.getTasksListData(function (response) {
					// 		that.oTasksList = JSON.parse(response.IvJson);
					// 		that.oTasksList.sort(function (a, b) {
					// 			if (a.TID > b.TID) {
					// 				return -1;
					// 			}
					// 			if (a.TID < b.TID) {
					// 				return 1;
					// 			}
					// 			return 0;
					// 		});
					// 		var oTasksListModel = new JSONModel(that.oTasksList);
					// 		that.getView().setModel(oTasksListModel, "TaskListModel");
					// 		console.log(that.oTasksList);
					// 	}, function (error) {
					// 		MessageToast.show("Data load Complete");
					// 	});

					// } else {

					// 	if (JSON.parse(e.IvJson).MTY === "S") {
					// 		MessageToast.show(JSON.parse(e.IvJson).MSG);

					// 	} else if (JSON.parse(e.IvJson).MTY === "E") {
					// 		MessageToast.show(JSON.parse(e.IvJson).MSG);
					// 	}
					// }
				},
				function (e) {
					MessageToast.show(JSON.parse(e.IvJson).MSG);
				});

		},
		DeactivePress: function (oEvent) {
			debugger;
			var that = this;
			var DeactiveTable = [];
			var Deactive = "Deactive";
			var path = oEvent.oSource.oPropagatedProperties.oBindingContexts.TaskListModel.sPath;
			var patharray = path.split('/');
			var nindex = patharray[patharray.length - 1];
			var oSelectedTask = this.oTasksList[nindex];
			var Tid = oSelectedTask.TID;
			var DeactiveModel = {
				Active: "",
				Tid: Tid,
			};
			DeactiveTable.push(DeactiveModel)
			datamanager.DeactiveTask(DeactiveTable, function (e) {
					MessageToast.show("Task has been deactivated");
					datamanager.getTasksListData(function (response) {
						that.oTasksList = JSON.parse(response.IvJson);
						that.oTasksList.sort(function (a, b) {
							if (a.TID > b.TID) {
								return -1;
							}
							if (a.TID < b.TID) {
								return 1;
							}
							return 0;
						});
						var oTasksListModel = new JSONModel(that.oTasksList);
						that.getView().setModel(oTasksListModel, "TaskListModel");
						console.log(that.oTasksList);
					}, function (error) {
						MessageToast.show("Data load Complete");
					});

					// var deactiveResult = JSON.parse(e.IvJson);
					// if (JSON.parse(e.IvJson).ACTIVE === "X") {
					// 	MessageToast.show("Task has been deactivated");
					// 	datamanager.getTasksListData(function (response) {
					// 		that.oTasksList = JSON.parse(response.IvJson);
					// 		that.oTasksList.sort(function (a, b) {
					// 			if (a.TID > b.TID) {
					// 				return -1;
					// 			}
					// 			if (a.TID < b.TID) {
					// 				return 1;
					// 			}
					// 			return 0;
					// 		});
					// 		var oTasksListModel = new JSONModel(that.oTasksList);
					// 		that.getView().setModel(oTasksListModel, "TaskListModel");
					// 		console.log(that.oTasksList);
					// 	}, function (error) {
					// 		MessageToast.show("Data load Complete");
					// 	});

					// } else {
					// 	if (JSON.parse(e.IvJson).MTY === "S") {
					// 		MessageToast.show(JSON.parse(e.IvJson).MSG);

					// 	} else if (JSON.parse(e.IvJson).MTY === "E") {
					// 		MessageToast.show(JSON.parse(e.IvJson).MSG);
					// 	}
					// }
				},
				function (e) {
					MessageToast.show(JSON.parse(e.IvJson).MSG);
				});

		},

		onNext: function () {
			var page = 0;
			var arraylist = [];
			var tasklist = this.getView().getModel('TaskListModel').oData;
			arraylist.push(tasklist);
			// console.log(arraylist);
			for (let i = 0; i < page + 10; i++) {
				tasklist.appendChild(arraylist[i]);
			}

		},

		onFilterSelect: function (oEvent) {
			var that = this;
			var key = oEvent.getParameters().key;
			if (key == 'bydefault_task') {
				var alltask = "X";
				datamanager.get_alltask_filterlist(alltask, function (response) {
					that.oTasksList = JSON.parse(response.IvJson);
					that.oTasksList.sort(function (a, b) {
						if (a.TID > b.TID) {
							return -1;
						}
						if (a.TID < b.TID) {
							return 1;
						}
						return 0;
					});
					var oTasksListModel = new JSONModel(that.oTasksList);
					that.getView().setModel(oTasksListModel, "TaskListModel");
					console.log(that.oTasksList);
				}, function (error) {
					MessageToast.show("Data load Complete");
				});
			} else if (key == 'assigne_to') {
				var assign_to = "Y";
				datamanager.get_assigneto_filterlist(assign_to, function (response) {
					that.oAssigne_to = JSON.parse(response.IvJson);
					that.oAssigne_to.sort(function (a, b) {
						if (a.TID > b.TID) {
							return -1;
						}
						if (a.TID < b.TID) {
							return 1;
						}
						return 0;
					});
					var oAssigne_to = new JSONModel(that.oAssigne_to);
					that.getView().setModel(oAssigne_to, "oAssigne_to");
					console.log(that.oAssigne_to);
				}, function (error) {
					MessageToast.show("Data load Complete");
				});
			} else if (key == 'assigne_by') {
				var assigne_by = "Z";
				datamanager.get_assigneby_filterlist(assigne_by, function (response) {
					that.oAssigne_by = JSON.parse(response.IvJson);
					that.oAssigne_by.sort(function (a, b) {
						if (a.TID > b.TID) {
							return -1;
						}
						if (a.TID < b.TID) {
							return 1;
						}
						return 0;
					});
					var oAssigne_by = new JSONModel(that.oAssigne_by);
					that.getView().setModel(oAssigne_by, "oAssigne_by");
					console.log(that.oAssigne_by);
				}, function (error) {
					MessageToast.show("Data load Complete");
				});
			}
		},

		onPress: function (oEvent) {

			var path = oEvent.getSource().getBindingContextPath();
			var patharray = path.split('/');
			var nindex = patharray[patharray.length - 1];
			var oSelectedTask = this.oTasksList[nindex];
			var loRouter = sap.ui.core.UIComponent.getRouterFor(this);
			loRouter.navTo("taskDetail", {
				taskId: oSelectedTask.TID
			});

		},

		cdpitem: function (oEvent) {
			var cpd_id = '';
			var cdpid = oEvent.oSource.mProperties.text;
			// 			var cdpid = parseInt(cdpid);
			var olist = this.getView().getModel('TaskListModel').oData

			var oType = null
			olist.forEach(function (item, index) {
				if (item.POT_ID === cdpid) {
					oType = item.OBJTYP
				}
			})
			if (oType === 'P') {
				// console.log('COT')
				window.open().location.replace(
					"https://103.226.216.10:8600/sap/bc/ui5_ui5/ui2/ushell/shells/abap/Fiorilaunchpad.html#zso_POT-display");
			} else {

				window.open().location.replace(
					"https://103.226.216.10:8600/sap/bc/ui5_ui5/ui2/ushell/shells/abap/Fiorilaunchpad.html#zso_POT-display");
			}

		},

		onSearch: function (oEvt) {
			var aFilter;
			var sQuery = oEvt.getSource().getValue();
			// var dateVon = oEvt.getSource().getValue().replace("", ''); //regix
			// var CID = oEvt.getParameter("CID");
			if (sQuery && sQuery.length > 0) {
				aFilter = new sap.ui.model.Filter({
					filters: [
						new Filter("TID", sap.ui.model.FilterOperator.EQ, sQuery),
						new Filter("NOTIFY_AT", sap.ui.model.FilterOperator.EQ, sQuery),
						new Filter("TITLE", sap.ui.model.FilterOperator.Contains, sQuery),
						new Filter("STATUS_T", sap.ui.model.FilterOperator.Contains, sQuery),
						new Filter("PRIORITY_T", sap.ui.model.FilterOperator.Contains, sQuery),
						new Filter("TYPE_T", sap.ui.model.FilterOperator.Contains, sQuery),
						new Filter("ASSIGNEE", sap.ui.model.FilterOperator.Contains, sQuery),
						new Filter("AEDAT", sap.ui.model.FilterOperator.Contains, sQuery),
						new Filter("AENAM", sap.ui.model.FilterOperator.Contains, sQuery),
						new Filter("AETIM", sap.ui.model.FilterOperator.Contains, sQuery),
						new Filter("SAP_DOCNR", sap.ui.model.FilterOperator.EQ, sQuery),
						new Filter("SAP_DOCNM", sap.ui.model.FilterOperator.Contains, sQuery),
						new Filter("CID", sap.ui.model.FilterOperator.Contains, sQuery),
						// new Filter("CID", sap.ui.model.FilterOperator.Contains, sQuery),

					]
				});
			}
			// update list binding
			var list = this.getView().byId("gridlist");
			var binding = list.getBinding("items");
			binding.filter(aFilter);
		},
		handleOpen: function (oEvent) {
			debugger;
			var oButton = oEvent.getSource();
			if (!this._actionSheet) {
				this._actionSheet = sap.ui.xmlfragment(
					"zfiori.z_task_mng.fragments.ActionSheet",
					this
				);
				this.getView().addDependent(this._actionSheet);
			}
			this._actionSheet.open();
		},

		onPressNavToDetail: function () {

			var loRouter = sap.ui.core.UIComponent.getRouterFor(this);
			loRouter.navTo("taskCreate");
		},

		handleSortDialogConfirm: function (oEvent) {

			var oTable = this.byId("gridlist"),
				mParams = oEvent.getParameters(),
				oBinding = oTable.getBinding("items"),
				sPath,
				bDescending,
				aSorters = [];

			sPath = mParams.sortItem.getKey();
			bDescending = mParams.sortDescending;
			aSorters.push(new Sorter(sPath, bDescending));

			// apply the selected sort and group settings
			oBinding.sort(aSorters);
		},
		onAssign: function (oEvt) {
			var aFilter;
			var sQuery = oEvt.getSource().getValue();
			if (sQuery && sQuery.length > 0) {
				aFilter = new sap.ui.model.Filter({
					filters: [
						new Filter("ASSIGNEE", sap.ui.model.FilterOperator.Contains, sQuery)
					]
				});
			}

			var list = this.getView().byId("gridlist");
			var binding = list.getBinding("items");
			binding.filter(aFilter);
		},
		onAssign_by: function (oEvt) {
			var aFilter;
			var sQuery = oEvt.getSource().getValue();
			if (sQuery && sQuery.length > 0) {
				aFilter = new sap.ui.model.Filter({
					filters: [
						new Filter("AENAM", sap.ui.model.FilterOperator.Contains, sQuery)
					]
				});
			}

			var list = this.getView().byId("gridlist");
			var binding = list.getBinding("items");
			binding.filter(aFilter);
		},

	});

});