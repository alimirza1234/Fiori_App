sap.ui.define([
	"sap/ui/model/json/JSONModel"
], function (JSONModel) {
	"use strict";

	var _modelBase = null;

	function _getOData(sPath, oContext, oUrlParams, successCallback, errorCallback) {
		_modelBase.read(sPath, oContext, oUrlParams, true, function (response) {

			successCallback(response);
		}, function (response) {

			errorCallback(response);
		});
	}

	function _postData(sPath, oContext, sucessCallback, errorCallback) {
		_modelBase.create(sPath, oContext, null, sucessCallback, errorCallback);
	}

	return {

		init: function (oDataModel) {
			_modelBase = oDataModel;
			_modelBase.setCountSupported(false);
		},

		getoDataModel: function () {
			return _modelBase;
		},

		oModelRefresh: function () {
			_modelBase.refresh(true, false);
		},

		getTasksListData: function (successCallback, errorCallback) {

			// 	var paginationPrams = {
			// 	Max_R: sTaskID
			// };
			var sPath = "Get_dataSet(IvCall='L',IvGet='')";

			_getOData(sPath, null, null, function (objResponse) {
				var oResult = objResponse;

				successCallback(oResult);
			}, function (objResponse) {
				//console.log("Error");
				errorCallback(objResponse);
			});

		},

		// ActiveTask: function (Active, Tid, successCallback, errorCallback) {

		// 	var dataToPost = {
		// 		Active: Active,
		// 		Tid: Tid
		// 	};
		// 	dataToPost = JSON.stringify(dataToPost);
		// 	var sPath = "Adm_dataSetSet(IvCall='A',IvGet='" + dataToPost + "')";
		// 	// var sPath = "detail_data_set?$filter=ICall eq 'J' and IBanfn eq '" + sTaskID + "'";

		// 	_getOData(sPath, null, null, function (objResponse) {
		// 		var oResult = objResponse;

		// 		successCallback(oResult);
		// 	}, function (objResponse) {
		// 		//console.log("Error");
		// 		errorCallback(objResponse);
		// 	});

		// },
		ActiveTask: function (ActiveModel, sucessCallback, errorCallback) {
			debugger;
			var object = {
				IvCall: "A",
				IvGet: JSON.stringify(ActiveModel)
			};
			// var sPath = "Adm_dataSetSet(IvCall='A',IvGet='" + dataToPost + "')";
			var sPath = "/Adm_dataSetSet";
			_postData(sPath, object,
				function (objResponse) {
					var oResult = objResponse;
					sucessCallback(oResult);
				},
				function (objResponse) {
					errorCallback(objResponse);
				});

		},

		DeactiveTask: function (DeactiveModel, successCallback, errorCallback) {
			var dataToPost = {
				IvCall: "A",
				IvGet: JSON.stringify(DeactiveModel)
			};
			var sPath = "/Adm_dataSetSet";
			// var array = [];
			// array.push(dataToPost);
			// var sPath = "/Adm_dataSetSet";
			_postData(sPath, dataToPost,
				function (objResponse) {
					var oResult = objResponse;
					successCallback(oResult);
				},
				function (objResponse) {
					errorCallback(objResponse);
				});

		},

		get_alltask_filterlist: function (otabfilter, successCallback, errorCallback) {

			var sPath = "Get_dataSet(IvCall='" + otabfilter + "')";

			_getOData(sPath, null, null, function (objResponse) {
				var oResult = objResponse;

				successCallback(oResult);
			}, function (objResponse) {
				//console.log("Error");
				errorCallback(objResponse);
			});

		},
		get_assigneto_filterlist: function (otabfilter, successCallback, errorCallback) {
			var sPath = "Get_dataSet(IvCall='" + otabfilter + "',IvGet=' ')";

			_getOData(sPath, null, null, function (objResponse) {
				var oResult = objResponse;

				successCallback(oResult);
			}, function (objResponse) {
				//console.log("Error");
				errorCallback(objResponse);
			});

		},
		get_assigneby_filterlist: function (otabfilter, successCallback, errorCallback) {
			var sPath = "Get_dataSet(IvCall='" + otabfilter + "',IvGet=' ')";

			_getOData(sPath, null, null, function (objResponse) {
				var oResult = objResponse;

				successCallback(oResult);
			}, function (objResponse) {
				//console.log("Error");
				errorCallback(objResponse);
			});

		},

		getF4helpdata: function (successCallback, errorCallback) {
			var sPath = "Get_dataSet(IvCall='G',IvGet='')";
			_getOData(sPath, null, null, function (objResponse) {
				var oResult = objResponse;
				successCallback(oResult);
			}, function (objResponse) {
				//console.log("Error");
				errorCallback(objResponse);
			});
		},

		getTaskDetails: function (sTaskID, successCallback, errorCallback) {

			var dataToPost = {
				Parent: sTaskID
			};
			dataToPost = JSON.stringify(dataToPost);
			var sPath = "Get_dataSet(IvCall='D',IvGet='" + dataToPost + "')";
			// var sPath = "detail_data_set?$filter=ICall eq 'J' and IBanfn eq '" + sTaskID + "'";

			_getOData(sPath, null, null, function (objResponse) {
				var oResult = objResponse;

				successCallback(oResult);
			}, function (objResponse) {
				//console.log("Error");
				errorCallback(objResponse);
			});

		},

		getprintattachment: function (sTaskID, successCallback, errorCallback) {

			var dataToPost = {
				TID: sTaskID
			};
			dataToPost = JSON.stringify(dataToPost);

			var sPath = "Process_streamSet(IvCall='P',IvGet='" + dataToPost + "')";

			_getOData(sPath, null, null, function (success) {
				var oResult = success;

				successCallback(oResult);
			}, function (error) {
				//console.log("Error");
				errorCallback(error);
			});

		},
		// getReassigne: function (sTaskID, ReAssigne, Redate, successCallback, errorCallback) {

		// 	var dataToPost = {
		// 		Tid: sTaskID,
		// 		assignee: ReAssigne,
		// 		Tatt: Redate

		// 	};
		// 	dataToPost = JSON.stringify(dataToPost);
		// 	var sPath = "Get_dataSet(IvCall='A',IvGet='" + dataToPost + "')";
		// 	// var sPath = "detail_data_set?$filter=ICall eq 'J' and IBanfn eq '" + sTaskID + "'";

		// 	_getOData(sPath, null, null, function (objResponse) {
		// 		var oResult = objResponse;

		// 		successCallback(oResult);
		// 	}, function (objResponse) {
		// 		//console.log("Error");
		// 		errorCallback(objResponse);
		// 	});

		// },
		getReassigne: function (sTaskID, sucessCallback, errorCallback) {
			var object = {
				IvCall: "A",
				IvGet: JSON.stringify(sTaskID)
			};
			// var sPath = "Adm_dataSetSet(IvCall='A',IvGet='" + dataToPost + "')";
			var sPath = "/Action_dataSet";
			_postData(sPath, object,
				function (objResponse) {
					var oResult = objResponse;
					sucessCallback(oResult);
				},
				function (objResponse) {
					errorCallback(objResponse);
				});

		},

		// getReassigne: function (sTaskID, successCallback, errorCallback) {
		// 	var dataToPost = sTaskID;

		// 	dataToPost = JSON.stringify(dataToPost);
		// 	var sPath = "Get_dataSet(IvCall='A',IvGet='" + dataToPost + "')";

		// 	_getOData(sPath, null, null, function (objResponse) {
		// 		var oResult = objResponse;

		// 		successCallback(oResult);
		// 	}, function (objResponse) {
		// 		//console.log("Error");
		// 		errorCallback(objResponse);
		// 	});

		// }, // origional one
		getComplete: function (sTaskID, percentage, successCallback, errorCallback) {

			var dataToPost = {
				Parent: sTaskID,
				complete: percentage,
				// comment: comment
			};
			dataToPost = JSON.stringify(dataToPost);
			var sPath = "Get_dataSet(IvCall='C',IvGet='" + dataToPost + "')";
			// var sPath = "detail_data_set?$filter=ICall eq 'J' and IBanfn eq '" + sTaskID + "'";

			_getOData(sPath, null, null, function (objResponse) {
				var oResult = objResponse;

				successCallback(oResult);
			}, function (objResponse) {
				//console.log("Error");
				errorCallback(objResponse);
			});

		},
		saveTask: function (oObject, sucessCallback, errorCallback) {

			var dataToPost1 = {
				IvGet: JSON.stringify(oObject)
			};
			var sPath = "/Create_taskSet";
			_postData(sPath, dataToPost1,
				function (objResponse) {
					var oResult = objResponse;
					sucessCallback(oResult);
				},
				function (objResponse) {
					errorCallback(objResponse);
				});

		},
		getAttachmentList: function (otaskId, successCallback, errorCallback) {

			var obj = {
				TID: otaskId
			};
			obj = JSON.stringify(obj);
			var sPath = "Process_streamSet(IvCall='L',IvGet='" + obj + "')";

			_getOData(sPath, null, null, function (success) {
				var oResult = success;

				successCallback(oResult);
			}, function (error) {
				//console.log("Error");
				errorCallback(error);
			});

		},

		getAttachment: function (oFileObject, successCallback, errorCallback) {
			debugger;

			oFileObject = JSON.stringify(oFileObject);
			var sPath = "Process_streamSet(IvCall='R',IvGet='" + oFileObject + "')";

			_getOData(sPath, null, null, function (success) {
				var oResult = success;

				successCallback(oResult);
			}, function (error) {
				//console.log("Error");
				errorCallback(error);
			});

		},

		sendattachment: function (fileObject, successCallback, errorCallback) {

			var object = {
				IvCall: "C",
				IvGet: JSON.stringify(fileObject)
			};
			var sPath = "/Process_streamSet";
			// var array = [];
			// array.push(object);
			_postData(sPath, object,
				function (objResponse) {
					var oResult = objResponse;
					successCallback(oResult);
				},
				function (objResponse) {
					errorCallback(objResponse);
				});
		},

		editTask: function (oObject, sucessCallback, errorCallback) {
			var sPath = "/Update_dataSet";
			var obj = {
				IvGet: JSON.stringify(oObject)
			};
			_postData(sPath, obj,
				function (objResponse) {
					var oResult = objResponse;
					sucessCallback(oResult);
				},
				function (objResponse) {
					errorCallback(objResponse);
				});

		},
	};
});