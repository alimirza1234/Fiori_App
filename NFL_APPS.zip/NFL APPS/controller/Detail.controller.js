/*global location */
sap.ui.define([
  "zqc_ins_sf_slt/controller/BaseController",
  "sap/ui/model/json/JSONModel",
  "zqc_ins_sf_slt/model/formatter"
], function(BaseController, JSONModel, formatter) {
  "use strict";

  return BaseController.extend("zqc_ins_sf_slt.controller.Detail", {

    formatter: formatter,

    /* =========================================================== */
    /* lifecycle methods                                           */
    /* =========================================================== */

    onInit: function() {
      // Model used to manipulate control states. The chosen values make sure,
      // detail page is busy indication immediately so there is no break in
      // between the busy indication for loading the view's meta data
      var oViewModel = new JSONModel({
        busy: false,
        delay: 0
      });

      this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);

      this.setModel(oViewModel, "detailView");

      this.getOwnerComponent().oWhenMetadataIsLoaded.then(this._onMetadataLoaded.bind(this));
    },

    onNavBack: function() {
      // var oSplitApp = this.getView().getParent().getParent();
      // var oMaster = oSplitApp.getMasterPages()[0];
      // oSplitApp.toMaster(oMaster, "flip");
      this.getOwnerComponent().getRouter().getTargets().display("master");
      // var oHistory = sap.ui.core.routing.History.getInstance(),
      //  sPreviousHash = oHistory.getPreviousHash(),
      //  oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
      // if (sPreviousHash !== undefined) {
      //  // The history contains a previous entry
      //  history.go(-1);
      // } else {
      //  // Navigate back to FLP home
      //  oCrossAppNavigator.toExternal({
      //    target: {
      //      shellHash: "#"
      //    }
      //  });
      // }
    },

    /* =========================================================== */
    /* event handlers                                              */
    /* =========================================================== */

    /**
     * Event handler when the share button has been clicked
     * @param {sap.ui.base.Event} oEvent the butten press event
     * @public
     */
    onSharePress: function() {
      var oShareSheet = this.byId("shareSheet");
      oShareSheet.addStyleClass(this.getOwnerComponent().getContentDensityClass());
      oShareSheet.openBy(this.byId("shareButton"));
    },

    /* =========================================================== */
    /* begin: internal methods                                     */
    /* =========================================================== */
    onShareEmailPress: function() {
      var oViewModel = this.getModel("detailView");

      sap.m.URLHelper.triggerEmail(
        null,
        oViewModel.getProperty("/shareSendEmailSubject"),
        oViewModel.getProperty("/shareSendEmailMessage")
      );
    },

    onShareInJamPress: function() {
      var oViewModel = this.getModel("detailView"),
        oShareDialog = sap.ui.getCore().createComponent({
          name: "sap.collaboration.components.fiori.sharing.dialog",
          settings: {
            object: {
              id: location.href,
              share: oViewModel.getProperty("/shareOnJamTitle")
            }
          }
        });

      oShareDialog.open();
    },
    /**
     * Binds the view to the object path and expands the aggregated line items.
     * @function
     * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
     * @private
     */
    _onObjectMatched: function(oEvent) {
      var sObjectId = oEvent.getParameter("arguments").objectId;
      this.getOwnerComponent().oWhenMetadataIsLoaded.then(function() {
        var sObjectPath = this.getModel().createKey("ZQC_INS_SF_SLT_TSet", { //ZTB_QM_IP_PKL_BTLSet  ZTB_QM_IP_MMPSet
          INSPECTION_ID: sObjectId
        });
        this._bindView("/" + sObjectPath);
      }.bind(this));
      // var InsID = this.getView().byId("INSPECTION_ID_ID").getValue();
      // sap.m.MessageBox.alert(InsID + sObjectId);
      this.BindWeitTableData(sObjectId);
      this.BindImageTableData(sObjectId);
      // setTimeout(function() {
      //    this.setRanges();
      //  },
      //  1000);
    },

    /**
     * Binds the view to the object path. Makes sure that detail view displays
     * a busy indicator while data for the corresponding element binding is loaded.
     * @function
     * @param {string} sObjectPath path to the object to be bound to the view.
     * @private
     */
    _bindView: function(sObjectPath) {
      // Set busy indicator during view binding
      var oViewModel = this.getModel("detailView");

      // If the view was not bound yet its not busy, only if the binding requests data it is set to busy again
      oViewModel.setProperty("/busy", false);

      this.getView().bindElement({
        path: sObjectPath,
        events: {
          change: this._onBindingChange.bind(this),
          dataRequested: function() {
            oViewModel.setProperty("/busy", true);
          },
          dataReceived: function() {
            oViewModel.setProperty("/busy", false);
          }
        }
      });
    },

    _onBindingChange: function() {
      var oView = this.getView(),
        oElementBinding = oView.getElementBinding();

      // No data for the binding
      if (!oElementBinding.getBoundContext()) {
        this.getRouter().getTargets().display("detailObjectNotFound");
        // if object could not be found, the selection in the master list
        // does not make sense anymore.
        this.getOwnerComponent().oListSelector.clearMasterListSelection();
        return;
      }

      var sPath = oElementBinding.getPath(),
        oResourceBundle = this.getResourceBundle(),
        oObject = oView.getModel().getObject(sPath),
        sObjectId = oObject.INSPECTION_ID,
        sObjectName = oObject.PRODUCTION_ORDER_NO,
        oViewModel = this.getModel("detailView");

      this.getOwnerComponent().oListSelector.selectAListItem(sPath);

      oViewModel.setProperty("/saveAsTileTitle", oResourceBundle.getText("shareSaveTileAppTitle", [sObjectName]));
      oViewModel.setProperty("/shareOnJamTitle", sObjectName);
      oViewModel.setProperty("/shareSendEmailSubject",
        oResourceBundle.getText("shareSendEmailObjectSubject", [sObjectId]));
      oViewModel.setProperty("/shareSendEmailMessage",
        oResourceBundle.getText("shareSendEmailObjectMessage", [sObjectName, sObjectId, location.href]));
    },

    _onMetadataLoaded: function() {
      // Store original busy indicator delay for the detail view
      var iOriginalViewBusyDelay = this.getView().getBusyIndicatorDelay(),
        oViewModel = this.getModel("detailView");

      // Make sure busy indicator is displayed immediately when
      // detail view is displayed for the first time
      oViewModel.setProperty("/delay", 0);

      // Binding the view will set it to not busy - so the view is always busy if it is not bound
      oViewModel.setProperty("/busy", true);
      // Restore original busy indicator delay for the detail view
      oViewModel.setProperty("/delay", iOriginalViewBusyDelay);
    },
    fPackageChange: function(oEvent) {
      var sValue = this.getView().byId("ddl_PACKAGE_TYPE").getSelectedKey();
      var oInput = this.getView().byId("PACKAGE_TYPE");
      oInput.setValue(sValue);
      var newItem;
      if (sValue === "Carton") {
        newItem = new sap.ui.core.Item({
          key: "KG",
          text: "KG"
        });
        this.byId("ddl_Unit").removeAllItems();
        this.byId("ddl_Unit").addItem(newItem);
      } else {
        this.byId("ddl_Unit").removeAllItems();
        newItem = new sap.ui.core.Item({
          key: "GM",
          text: "GM"
        });
        this.byId("ddl_Unit").removeAllItems();
        this.byId("ddl_Unit").addItem(newItem);
      }
    },
    fnSaveWeightSet: function(oEvent) {
      // var that = this;
      var InsID = this.getView().byId("INSPECTION_ID_ID").getValue();
      var WeightID = this.getView().byId("Weight_id").getValue();
      var Package = this.getView().byId("PACKAGE_TYPE").getValue();
      // var Unit = this.getView().byId("Unit_id").getValue();
      var Unit = this.getView().byId("ddl_Unit").getSelectedItem().getText();
      if (InsID === "" || WeightID === "" || Unit === "" || Package === "") {
        sap.m.MessageBox.alert("All fields are mandatory");
      } else {
        var userRequestBody = {
          properties: {
            Inspection_Id: InsID,
            Weight: WeightID,
            Unit: Unit,
            Process_Id: '21', //01
            PACKAGE_TYPE: Package
          }
        };
        var oModel = this.getModel();
        var oContext = oModel.createEntry("/ZTB_QM_IPI_WEITSet", userRequestBody); // Give previous name as
        this.getView().setBindingContext(oContext);
        // oModel.setUseBatch(false);
        oModel.submitChanges();
        oModel.setRefreshAfterChange(true);
        var oMaterial = this.byId("Weight_id");
        // var oMaterialDesc = this.byId("Unit_id");
        oMaterial.setValue("");
        // oMaterialDesc.setValue("");
        // var oInput = this.getView().byId("ddl_Unit");
        // oInput.setSelectedKey("0");
        // oInput.setValue("");
      }
    },
    // if (InsID === "" || WeightID === "" || Unit === "") {
    //  sap.m.MessageBox.alert("All fields are mandatory");
    // } else {
    //  var dialog = new sap.m.Dialog({
    //    title: 'Confirm',
    //    type: 'Message',
    //    content: new sap.m.Text({
    //      text: 'Are you sure you want to save the weight sample against ' + InsID + ' ?'
    //    }),
    //    beginButton: new sap.m.Button({
    //      text: 'Save',
    //      press: function() {
    //        var userRequestBody = {
    //          properties: {
    //            Inspection_Id: InsID,
    //            Weight: WeightID,
    //            Unit: Unit,
    //            Process_Id: '01'
    //          }
    //        };
    //        var oModel = that.getModel();
    //        var oContext = oModel.createEntry("/ZTB_QM_IPI_WEITSet", userRequestBody);
    //        that.getView().setBindingContext(oContext);
    //        // oModel.setUseBatch(false);
    //        oModel.submitChanges();
    //        oModel.setRefreshAfterChange(true);
    //        var oMaterial = that.byId("Weight_id");
    //        // var oMaterialDesc = this.byId("Unit_id");
    //        oMaterial.setValue("");
    //        // oMaterialDesc.setValue("");
    //        var oInput = that.getView().byId("ddl_Unit");
    //        oInput.setValue("");

    //        dialog.close();
    //        oModel.setRefreshAfterChange(true);
    //        oModel.refresh(true);
    //        sap.ui.getCore().byId("ViewRepeater_Id").getModel().refresh(true);

    //      }
    //    }),
    //    endButton: new sap.m.Button({
    //      text: 'Cancel',
    //      press: function() {
    //        dialog.close();
    //      }
    //    }),
    //    afterClose: function() {
    //      // sap.m.MessageBox.alert("hi");
    //      dialog.destroy();
    //    }
    //  });

    //  dialog.open();
    // }

    /**
     * Event handler (attached declaratively) for the view Submit button. Submit the selected item. 
     * @function
     * @public
     */
    onSubmit: function() {
      var that = this;
      var InsID = this.getView().byId("INSPECTION_ID").getValue();

      //*************************************************************//
      var dialog = new sap.m.Dialog({
        title: 'Confirm',
        type: 'Message',
        content: new sap.m.Text({
          text: 'Are you sure you want to submit your inspection ' + InsID + ' ?'
        }),
        beginButton: new sap.m.Button({
          text: 'Submit',
          press: function() {
            // sap.m.MessageToast.show('Submit pressed!');
            // dialog.close();
            var ServiceUrl = "/sap/opu/odata/sap/ZQC_IPI_INS_UNIT_SRV_01/";
            var oModel = new sap.ui.model.odata.ODataModel(ServiceUrl);
            sap.ui.getCore().setModel(oModel, "Main");
            // var oJsonModel = new sap.ui.model.json.JSONModel();
            var uriL = "ZSF_SUBMIT?&INSPECTION_ID='" + InsID + "'" + "&STATUS='2'&TBL='ZQC_INS_SF_SLT_T'";
            oModel.read(uriL, null, [], false, function(Odata, response) {
              // window.mess = Odata.Error;
              // window.type = Odata.Ztype;
            });
            dialog.close();
            oModel.setRefreshAfterChange(true);
            // oModel.refresh(true);
            // sap.ui.getCore().byId("ViewRepeater_Id").getModel().refresh(true);
            that.getView().getModel().refresh();
            // window.location.reload();
            // var oList = this.getView().byId("list"),
            //  oFirstItem = oList.getItems()[0];
            // oList.setSelectedItem(oFirstItem, true, true);

          }
        }),
        endButton: new sap.m.Button({
          text: 'Cancel',
          press: function() {
            dialog.close();
          }
        }),
        afterClose: function() {
          // sap.m.MessageBox.alert("hi");
          dialog.destroy();
        }
      });

      dialog.open();

    },

    /**
     * Event handler (attached declaratively) for the view Submit button. Submit the selected item. 
     * @function
     * @public
     */
    onSubmitInvalid: function() {
      var that = this;
      var InsID = this.getView().byId("INSPECTION_ID").getValue();

      //*************************************************************//
      var dialog = new sap.m.Dialog({
        title: 'Confirm',
        type: 'Message',
        content: new sap.m.Text({
          text: 'Are you sure you want to ignore the inspection ' + InsID + ' ?'
        }),
        beginButton: new sap.m.Button({
          text: 'Ignore',
          press: function() {
            // sap.m.MessageToast.show('Submit pressed!');
            // dialog.close();
            var ServiceUrl = "/sap/opu/odata/sap/ZQC_IPI_INS_UNIT_SRV_01/";
            var oModel = new sap.ui.model.odata.ODataModel(ServiceUrl);
            sap.ui.getCore().setModel(oModel, "Main");
            // var oJsonModel = new sap.ui.model.json.JSONModel();
            var uriL = "ZSF_SUBMIT?&INSPECTION_ID='" + InsID + "'" + "&STATUS='3'&TBL='ZQC_INS_SF_SLT_T'";
            oModel.read(uriL, null, [], false, function(Odata, response) {
              // window.mess = Odata.Error;
              // window.type = Odata.Ztype;
            });
            dialog.close();
            oModel.setRefreshAfterChange(true);
            // oModel.refresh(true);
            // sap.ui.getCore().byId("ViewRepeater_Id").getModel().refresh(true);
            that.getView().getModel().refresh();
          }
        }),
        endButton: new sap.m.Button({
          text: 'Cancel',
          press: function() {
            dialog.close();
          }
        }),
        afterClose: function() {
          // sap.m.MessageBox.alert("hi");
          dialog.destroy();
        }
      });

      dialog.open();

    },

    // onBeforeUploadStarts: function(oEvent) {
    //  var inputslug = oEvent.getParameter("INSPECTION_ID_ID");
    //  inputslug = inputslug + "/" + "01";
    //  var oCustomerHeaderSlug = new sap.m.UploadCollectionParameter({
    //    name: "slug",
    //    value: inputslug
    //  });
    //  oEvent.getParameters().addHeaderParameter(oCustomerHeaderSlug);

    // },

    onUploadComplete: function(oEvent) {
      //This code was generated by the layout editor.
      // this.getView().byId("INSPECTION_ID_ID").getValue();

      var uc = this.getView().byId("UploadCollection");
      var oData = uc.getModel().getData();
      // var oData = this.getView().byId("UploadCollection").getModel().getData();
      // var aItems = jQuery.extend(true, {}, oData).items;
      var aItems = uc.aItems;
      // var aItems = jQuery.extend(true, {}, oData).items;
      var oItem = {};
      // var sUploadedFile = oEvent.getParameter("files")[0].fileName;
      var sUploadedFile = oEvent.getParameter("files")[0].fileName;
      // at the moment parameter fileName is not set in IE9
      if (!sUploadedFile) {
        var aUploadedFile = (oEvent.getParameters().getSource().getProperty("value")).split(/\" "/);
        sUploadedFile = aUploadedFile[0];
      }
      var InsID = this.getView().byId("INSPECTION_ID").getValue();
      oItem = {
        "fileName": sUploadedFile,
        "documentId": jQuery.now().toString(),
        "uploadedDate": new Date(jQuery.now()).toLocaleDateString(),
        "url": "/sap/opu/odata/sap/ZQC_IPI_INS_UNIT_SRV_01/",
        "Mimetype": "",
        "ProcessId": '21',
        "InspectionId": InsID,
        // "thumbnailUrl": "",
        //    "url" : "",
        // "contributor": "You",
        "fileSize": "505000" // TODO get file size

      };
      aItems.unshift(oItem);

      var that = this;
      // this.getView().getModel().refresh();
      setTimeout(function() {
          that.getView().getModel().refresh();
          sap.m.MessageToast.show("UploadComplete event triggered.");
        },
        4000);

    },
    onChange: function(oEvent) {
      // var ServiceUrl = "../../../../../../sap/opu/odata/sap/ZQI_IPI_INS_UNIT_SRV/";
      // ../../../../../../sap/opu/odata/sap/ZQI_IPI_INS_UNIT_SRV/FILESet
      //var oModeltest = new sap.ui.model.odata.ODataModel(ServiceUrl);

      var oModel = this.getView().getModel();
      oModel.refreshSecurityToken();
      var oHeaders = oModel.oHeaders;

      var sToken = oHeaders['x-csrf-token'];
      var oUploadCollection = oEvent.getSource();
      var oCustomerHeaderToken = new sap.m.UploadCollectionParameter({
        name: "x-csrf-token",
        value: sToken
      });
      oUploadCollection.addHeaderParameter(oCustomerHeaderToken);
      var InsID = this.getView().byId("INSPECTION_ID").getValue();
      var PrcsID = "21";

      // var inputslug = oEvent.getParameter("fileName");
      var inputslug = InsID + "/" + PrcsID;
      // inputslug = inputslug + "/" + "01";
      var oCustomerHeaderSlug = new sap.m.UploadCollectionParameter({
        name: "slug",
        value: inputslug
          // value: oEvent.getParameter("fileName")
      });
      oUploadCollection.addHeaderParameter(oCustomerHeaderSlug);

    },

    // var url = "/sap/opu/odata/sap/ZQI_IPI_INS_UNIT_SRV/ZTB_QM_IPI_WEITSet/?$filter=INSPECTION_ID eq '" + InsID +
    //  "' and ProcessId eq '1'";

    onbtnclicked: function() {
      // var oModel = this.getModel();
      var InsID = this.getView().byId("INSPECTION_ID").getValue();
      // sap.m.MessageBox.alert()
      var oFilter = new sap.ui.model.Filter([
        new sap.ui.model.Filter("INSPECTION_ID", sap.ui.model.FilterOperator.EQ, InsID),
        new sap.ui.model.Filter("Process_Id", sap.ui.model.FilterOperator.EQ, '21')
      ], true);
//      var oBinding = this.byId("idWeightsTable").getBinding("items");
      oBinding.filter([oFilter]);

    },

    onTabSelect: function(oEvent) {
      var sKey = oEvent.getParameter("selectedKey");
      if (sKey === "info") {
        // oFilter = new sap.ui.model.Filter("WeightMeasure", "LE", 1000);
      } else if (sKey === "attach") {

        // var InsID = this.getView().byId("INSPECTION_ID_ID").getValue();
        // this.BindImageTableData(InsID);
      } else if (sKey === "picture") {
        // oFilter = new sap.ui.model.Filter("WeightMeasure", "GT", 2000);
      } else {
        // sap.m.MessageBox.alert(sKey);
      }
    },
    ////// Text nox fields validations
    isNumeric: function(obj) {
      var realStringObj = obj && obj.toString();
      return !jQuery.isArray(obj) && (realStringObj - parseFloat(realStringObj) + 1) >= 0;
    },

    valInput: function() {
      var FillingTemperature = this.getView().byId("Weight_id").getValue();
      var textval = this.byId("Weight_id");
      var oResult = this.isNumeric(FillingTemperature);
      if (!oResult) {
        sap.m.MessageBox.alert("Invalid Input, please input correct data");
        textval.setValue("");
      }
    },

    OnTypeMissmatch: function(oEvent) {
      sap.m.MessageBox.alert("File type invalid, only support jpeg,jpg.");
    },

    BindWeitTableData: function(insID) {
//      var oFilter = new sap.ui.model.Filter([
//        new sap.ui.model.Filter("Inspection_Id", sap.ui.model.FilterOperator.EQ, insID),
//        new sap.ui.model.Filter("Process_Id", sap.ui.model.FilterOperator.EQ, '21')
//      ], true);
//      var oBinding = this.byId("idWeightsTable").getBinding("items");
//      oBinding.filter([oFilter]);
      // setTimeout(function() {
      //    this.setRanges();
      //  },
      //  1000);

    },

    BindImageTableData: function(insID) {
      var oFilter = new sap.ui.model.Filter([
        new sap.ui.model.Filter("InspectionId", sap.ui.model.FilterOperator.EQ, insID),
        new sap.ui.model.Filter("ProcessId", sap.ui.model.FilterOperator.EQ, '21')
      ], true);
      var oBinding = this.byId("UploadCollection").getBinding("items");
      oBinding.filter([oFilter]);
    },

    handleAdd: function() {
      this.getRouter().getTargets().display("create");
    }
  });

});