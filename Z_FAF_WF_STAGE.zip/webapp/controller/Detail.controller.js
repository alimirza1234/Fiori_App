sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device",
	"sap/ui/model/Filter",
	"WF_STAGE2/Z_FAF_WF_STAGE/util/dataManagerLib",
	"sap/m/Dialog",
	"sap/m/Button",
	"sap/m/Text",
	"sap/m/Label",
	"sap/m/TextArea"
], function (Controller, JSONModel, Device, Filter, dataManagerLib, Dialog, Button, Text, Label, TextArea) {
	"use strict";

	return Controller.extend("WF_STAGE2.Z_FAF_WF_STAGE.controller.Detail", {
		ParticipateRowId: {
			id: ""
		},
		AnnexureARowId: {
			id: ""
		},
		AnnexureBRowId: {
			id: ""
		},
		AnnexureDRowId: {
			id: ""
		},
		AnnexureERowId: {
			id: ""
		},
		AnnexureFRowId: {
			id: ""
		},
		AnnexureHRowId: {
			id: ""
		},

		onInit: function () {
			debugger;
			// this._wizard.invalidateStep(this.byId("ProductInfo"));
		},

		btnapprove: function (oEvent) {
			var that = this;
			var oShell = sap.ui.getCore().byId('Shell');

			var dialog = new Dialog({
				title: 'Approve',
				type: 'Message',
				state: 'Success',
				content: [
					new Label({
						text: "Do you want to Approve this Request?",
						labelFor: "approveNote"
					}),
					new TextArea("approveNote", {
						width: "100%",
						placeholder: "Add note (optional)"
					})
				],
				beginButton: new Button({
					type: sap.m.ButtonType.Emphasized,
					text: 'Yes',
					press: function () {
						var ApproverNote = sap.ui.getCore().byId('approveNote').getValue()
						var studentnum = that.getView().getModel('oHeaderModel').getData().OBJID;
						//call for Approve Data
						dataManagerLib.Approve(studentnum, ApproverNote, function (response) {
								debugger;
								var oStudentData = response.EvJson;

								if (oStudentData === 'S') {
									var dialog = new Dialog({
										title: 'Confirm',
										type: 'Message',
										state: 'Success',
										content: new Text({
											text: 'Request has been Approved.'
										}),
										beginButton: new Button({
											type: sap.m.ButtonType.Emphasized,
											text: 'OK',
											press: function () {

												dataManagerLib.getHeaderData(function (Header) {
													if (Header.EvJson != "") {
														var oData = JSON.parse(Header.EvJson);
														var oStudentModel = new JSONModel(oData);
														oShell.setModel(oStudentModel, "oStudentModel");
														//Navation to Master Page
														that.nav.to('Master');
													}

												}, function (error) {
													console.log("error");
												});
												dialog.close();
											}
										})
									});
									dialog.open();
								}

								// var oData = JSON.parse(response.EvJson);
								// var oStudentModel = new JSONModel(oData);
								// oShell.setModel(oStudentModel, "oStudentModel");

							},
							function (error) {
								console.log("error");
							});

						dialog.close();
					}

				}),
				endButton: new Button({
					text: 'No',
					press: function () {
						dialog.close();
					}
				}),
				afterClose: function () {
					dialog.destroy();
				}
			});
			dialog.open();

		},

		btnreject: function (oEvent) {
			debugger;
			var that = this;
			var oShell = sap.ui.getCore().byId('Shell');

			var dialog = new Dialog({
				title: 'Reject',
				type: 'Message',
				state: 'Warning',
				content: [
					new Label({
						text: "Do you want to Reject this Request?",
						labelFor: "rejectNote"
					}),
					new TextArea("rejectNote", {
						width: "100%",
						placeholder: "Add note (optional)"
					})
				],
				beginButton: new Button({
					type: sap.m.ButtonType.Emphasized,
					text: 'Yes',
					press: function () {
						var RejectNote = sap.ui.getCore().byId('rejectNote').getValue();
						var studentnum = that.getView().getModel('oHeaderModel').getData().OBJID;
						//call for Reject Data
						dataManagerLib.Reject(studentnum, RejectNote, function (response) {
								debugger;
								var oStudentData = response.EvJson;

								if (oStudentData === 'S') {
									var dialog = new Dialog({
										title: 'Confirm',
										type: 'Message',
										state: 'Success',
										content: new Text({
											text: 'Request has been Rejected.'
										}),
										beginButton: new Button({
											type: sap.m.ButtonType.Emphasized,
											text: 'OK',
											press: function () {

												dataManagerLib.getHeaderData(function (Header) {
													var oData = JSON.parse(Header.EvJson);
													var oStudentModel = new JSONModel(oData);
													oShell.setModel(oStudentModel, "oStudentModel");
													//Navation to Master Page
													that.nav.to('Master');

												}, function (error) {
													console.log("error");
												});
												dialog.close();
											}
										})
									});
									dialog.open();
								}

								// var oData = JSON.parse(response.EvJson);
								// var oStudentModel = new JSONModel(oData);
								// oShell.setModel(oStudentModel, "oStudentModel");

							},
							function (error) {
								console.log("error");
							});

						dialog.close();
					}

				}),
				endButton: new Button({
					text: 'No',
					press: function () {
						dialog.close();
					}
				}),
				afterClose: function () {
					dialog.destroy();
				}
			});
			dialog.open();

		},

		onAddSectionBTblRow: function (oEvent) {
			var that = this;

			var oText;
			that.ParticipateRowId.id = that.ParticipateRowId.id + 1;

			//window.id = window.id + 1;
			oText = "Name" + that.ParticipateRowId.id;
			var NameID = oText;
			oText = "Relation" + that.ParticipateRowId.id;
			var RelationID = oText;
			oText = "Age" + that.ParticipateRowId.id;
			var AgeID = oText;
			oText = "MaritalStatus" + that.ParticipateRowId.id;
			var MaritalStatusID = oText;
			oText = "EconomicStatus" + that.ParticipateRowId.id;
			var EconomicStatusID = oText;
			oText = "PhysicalStatus" + that.ParticipateRowId.id;
			var PhysicalStatusID = oText;
			oText = "Livingwithhousehold" + that.ParticipateRowId.id;
			var LivingwithhouseholdID = oText;

			var oItem = new sap.m.ColumnListItem({
				cells: [
					new sap.m.Input(NameID, {
						width: "100%"
					}),
					new sap.m.Input(RelationID, {
						width: "100%"
					}),
					new sap.m.Input(AgeID, {
						width: "100%"
					}),
					new sap.m.Input(MaritalStatusID, {
						width: "100%"
					}),
					new sap.m.Input(EconomicStatusID, {
						width: "100%"
					}),
					new sap.m.Input(PhysicalStatusID, {
						width: "100%"
					}),
					new sap.m.Input(LivingwithhouseholdID, {
						width: "100%"
					}),
				]
			});

			var oTable = this.getView().byId('SectionBTbl');
			oTable.addItem(oItem);

			// this.byId('SectionBTbl').mAggregations.items[0].mAggregations.cells
			// this.byId('SectionBTbl').mAggregations.items[0].mAggregations.cells[0].mProperties.value;

		},

		deleteRowSectionBTbl: function (oEvent) {
			// var that = this;
			var ButtonID = oEvent.getSource().getId().split('-')[2];
			var oTable = this.getView().byId(ButtonID);
			oTable.removeItem(oEvent.getParameter('listItem'));
		},

		onAddSectionBAnnexureATblRow: function (oEvent) {
			var that = this;
			var oText;
			that.AnnexureARowId.id = that.AnnexureARowId.id + 1;

			//window.id = window.id + 1;
			oText = "AnnAName" + that.AnnexureARowId.id;
			var AnnANameID = oText;
			oText = "TypeOfWork" + that.AnnexureARowId.id;
			var TypeofWorkID = oText;
			oText = "NameAddress" + that.AnnexureARowId.id;
			var NameAddressID = oText;
			oText = "AnnIncomeSalary" + that.AnnexureARowId.id;
			var AnnIncomeSalaryID = oText;
			oText = "AnnIncomeInv" + that.AnnexureARowId.id;
			var AnnIncomeInvID = oText;
			oText = "OtherIncome" + that.AnnexureARowId.id;
			var OtherIncomeID = oText;

			var oItem = new sap.m.ColumnListItem({
				cells: [
					new sap.m.Input(AnnANameID, {
						width: "100%"
					}),
					new sap.m.Input(TypeofWorkID, {
						width: "100%"
					}),
					new sap.m.Input(NameAddressID, {
						width: "100%"
					}),
					new sap.m.Input(AnnIncomeSalaryID, {
						width: "100%"
					}),
					new sap.m.Input(AnnIncomeInvID, {
						width: "100%"
					}),
					new sap.m.Input(OtherIncomeID, {
						width: "100%"
					}),
				]
			});

			var oTable = this.getView().byId('SectionBAnnexureATbl');
			oTable.addItem(oItem);

		},

		deleteRowSectionBAnnexureATbl: function (oEvent) {
			// var that = this;
			var ButtonID = oEvent.getSource().getId().split('-')[2];
			var oTable = this.getView().byId(ButtonID);
			oTable.removeItem(oEvent.getParameter('listItem'));
		},

		onAddSectionBAnnexureBTblRow: function (oEvent) {
			var that = this;
			var oText;
			that.AnnexureBRowId.id = that.AnnexureBRowId.id + 1;

			//window.id = window.id + 1;
			oText = "AnnBNameB" + that.AnnexureBRowId.id;
			var AnnBNameBID = oText;
			oText = "ClassLevelB" + that.AnnexureBRowId.id;
			var ClassLevelBID = oText;
			oText = "NameInstituteB" + that.AnnexureBRowId.id;
			var NameInstituteBID = oText;
			oText = "AnnCostB" + that.AnnexureBRowId.id;
			var AnnCostBID = oText;
			oText = "AnnFinAidB" + that.AnnexureBRowId.id;
			var AnnFinAidBID = oText;
			oText = "SoruceAnnFinAidB" + that.AnnexureBRowId.id;
			var SoruceAnnFinAidBID = oText;

			var oItem = new sap.m.ColumnListItem({
				cells: [
					new sap.m.Input(AnnBNameBID, {
						width: "100%"
					}),
					new sap.m.Input(ClassLevelBID, {
						width: "100%"
					}),
					new sap.m.Input(NameInstituteBID, {
						width: "100%"
					}),
					new sap.m.Input(AnnCostBID, {
						width: "100%"
					}),
					new sap.m.Input(AnnFinAidBID, {
						width: "100%"
					}),
					new sap.m.Input(SoruceAnnFinAidBID, {
						width: "100%"
					}),
				]
			});

			var oTable = this.getView().byId('SectionBAnnexureBTbl');
			oTable.addItem(oItem);

		},

		deleteRowSectionBAnnexureBTbl: function (oEvent) {
			var that = this;
			var ButtonID = oEvent.getSource().getId().split('-')[2];
			var oTable = this.getView().byId(ButtonID);
			oTable.removeItem(oEvent.getParameter('listItem'));
		},

		onAddSectionBAnnexureDTblRow: function (oEvent) {
			var that = this;
			var oText;
			that.AnnexureDRowId.id = that.AnnexureDRowId.id + 1;

			//window.id = window.id + 1;
			oText = "DateofPurchaseD" + that.AnnexureDRowId.id;
			var DateofPurchaseDID = oText;
			oText = "SizeofPlotD" + that.AnnexureDRowId.id;
			var SizeofPlotDID = oText;
			oText = "LocationD" + that.AnnexureDRowId.id;
			var LocationDID = oText;
			oText = "CityD" + that.AnnexureDRowId.id;
			var CityDID = oText;
			oText = "ResidentialD" + that.AnnexureDRowId.id;
			var ResidentialDID = oText;
			oText = "OriginalCostD" + that.AnnexureDRowId.id;
			var OriginalCostDID = oText;
			oText = "CurrentMarketValueD" + that.AnnexureDRowId.id;
			var CurrentMarketValueDID = oText;

			var oItem = new sap.m.ColumnListItem({
				cells: [
					new sap.m.Input(DateofPurchaseDID, {
						width: "100%"
					}),
					new sap.m.Input(SizeofPlotDID, {
						width: "100%"
					}),
					new sap.m.Input(LocationDID, {
						width: "100%"
					}),
					new sap.m.Input(CityDID, {
						width: "100%"
					}),
					new sap.m.Input(ResidentialDID, {
						width: "100%"
					}),
					new sap.m.Input(OriginalCostDID, {
						width: "100%"
					}),
					new sap.m.Input(CurrentMarketValueDID, {
						width: "100%"
					}),
				]
			});

			var oTable = this.getView().byId('SectionBAnnexureDTbl');
			oTable.addItem(oItem);

		},

		deleteRowSectionBAnnexureDTbl: function (oEvent) {
			var that = this;
			var ButtonID = oEvent.getSource().getId().split('-')[2];
			var oTable = this.getView().byId(ButtonID);
			oTable.removeItem(oEvent.getParameter('listItem'));
		},

		onAddSectionBAnnexureETblRow: function (oEvent) {
			var that = this;
			var oText;
			that.AnnexureERowId.id = that.AnnexureERowId.id + 1;

			//window.id = window.id + 1;
			oText = "DateofPurchaseE" + that.AnnexureERowId.id;
			var DateofPurchaseEID = oText;
			oText = "CoveredAreaE" + that.AnnexureERowId.id;
			var CoveredAreaEID = oText;
			oText = "LocationE" + that.AnnexureERowId.id;
			var LocationEID = oText;
			oText = "CityE" + that.AnnexureERowId.id;
			var CityID = oText;
			oText = "ResidentialE" + that.AnnexureERowId.id;
			var ResidentialEID = oText;
			oText = "OriginalCostE" + that.AnnexureERowId.id;
			var OriginalCostEID = oText;
			oText = "CurrentMarketValueE" + that.AnnexureERowId.id;
			var CurrentMarketValueEID = oText;

			var oItem = new sap.m.ColumnListItem({
				cells: [
					new sap.m.Input(DateofPurchaseEID, {
						width: "100%"
					}),
					new sap.m.Input(CoveredAreaEID, {
						width: "100%"
					}),
					new sap.m.Input(LocationEID, {
						width: "100%"
					}),
					new sap.m.Input(CityID, {
						width: "100%"
					}),
					new sap.m.Input(ResidentialEID, {
						width: "100%"
					}),
					new sap.m.Input(OriginalCostEID, {
						width: "100%"
					}),
					new sap.m.Input(CurrentMarketValueEID, {
						width: "100%"
					}),
				]
			});

			var oTable = this.getView().byId('SectionBAnnexureETbl');
			oTable.addItem(oItem);

		},

		deleteRowSectionBAnnexureETbl: function (oEvent) {
			var that = this;
			var ButtonID = oEvent.getSource().getId().split('-')[2];
			var oTable = this.getView().byId(ButtonID);
			oTable.removeItem(oEvent.getParameter('listItem'));
		},

		onAddSectionBAnnexureFTblRow: function (oEvent) {
			var that = this;
			var oText;
			that.AnnexureFRowId.id = that.AnnexureFRowId.id + 1;

			//window.id = window.id + 1;
			oText = "MakeandModelF" + that.AnnexureFRowId.id;
			var MakeandModelFID = oText;
			oText = "YearofManufactureF" + that.AnnexureFRowId.id;
			var YearofManufactureFID = oText;
			oText = "YearofPurchaseF" + that.AnnexureFRowId.id;
			var YearofPurchaseFID = oText;
			oText = "OriginalPurchasePriseF" + that.AnnexureFRowId.id;
			var OriginalPurchasePriseFID = oText;
			oText = "CurrentMarketValueF" + that.AnnexureFRowId.id;
			var CurrentMarketValueFID = oText;

			var oItem = new sap.m.ColumnListItem({
				cells: [
					new sap.m.Input(MakeandModelFID, {
						width: "100%"
					}),
					new sap.m.Input(YearofManufactureFID, {
						width: "100%"
					}),
					new sap.m.Input(YearofPurchaseFID, {
						width: "100%"
					}),
					new sap.m.Input(OriginalPurchasePriseFID, {
						width: "100%"
					}),
					new sap.m.Input(CurrentMarketValueFID, {
						width: "100%"
					}),
				]
			});

			var oTable = this.getView().byId('SectionBAnnexureFTbl');
			oTable.addItem(oItem);

		},

		deleteRowSectionBAnnexureFTbl: function (oEvent) {
			var that = this;
			var ButtonID = oEvent.getSource().getId().split('-')[2];
			var oTable = this.getView().byId(ButtonID);
			oTable.removeItem(oEvent.getParameter('listItem'));
		},

		onAddSectionBAnnexureHTblRow: function (oEvent) {
			var that = this;
			var oText;
			that.AnnexureHRowId.id = that.AnnexureHRowId.id + 1;

			//window.id = window.id + 1;
			oText = "NameofAccountHolder" + that.AnnexureHRowId.id;
			var NameofAccountHolderID = oText;
			oText = "NameofBank" + that.AnnexureHRowId.id;
			var NameofBankID = oText;
			oText = "AccountType" + that.AnnexureHRowId.id;
			var AccountTypeID = oText;
			oText = "Currency" + that.AnnexureHRowId.id;
			var CurrencyID = oText;
			oText = "Amount" + that.AnnexureHRowId.id;
			var AmountID = oText;

			var oItem = new sap.m.ColumnListItem({
				cells: [
					new sap.m.Input(NameofAccountHolderID, {
						width: "100%"
					}),
					new sap.m.Input(NameofBankID, {
						width: "100%"
					}),
					new sap.m.Input(AccountTypeID, {
						width: "100%"
					}),
					new sap.m.Input(CurrencyID, {
						width: "100%"
					}),
					new sap.m.Input(AmountID, {
						width: "100%"
					}),
				]
			});

			var oTable = this.getView().byId('SectionBAnnexureHTbl');
			oTable.addItem(oItem);

		},

		deleteRowSectionBAnnexureHTbl: function (oEvent) {
			var that = this;
			var ButtonID = oEvent.getSource().getId().split('-')[2];
			var oTable = this.getView().byId(ButtonID);
			oTable.removeItem(oEvent.getParameter('listItem'));
		},

		onBack: function () {
			this.nav.to("Master");
		},
	});
});