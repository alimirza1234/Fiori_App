sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device",
	"sap/ui/model/Filter",
	"WF_STAGE2/Z_FAF_WF_STAGE/util/dataManagerLib",
], function (Controller, JSONModel, Device, Filter, dataManagerLib) {
	"use strict";

	return Controller.extend("WF_STAGE2.Z_FAF_WF_STAGE.controller.Master", {
		onInit: function () {},

		onAfterRendering: function () {
			var oShell = sap.ui.getCore().byId('Shell');
			dataManagerLib.getHeaderData(function (response) {
				var oData = response.results;
				var oStudentModel = new JSONModel(oData);
				oShell.setModel(oStudentModel, "oStudentModel");

			}, function (error) {
				console.log("error");
			});

		},

		onSearch: function (oEvt) {
			var aFilter;
			var sQuery = oEvt.getSource().getValue();
			if (sQuery && sQuery.length > 0) {
				aFilter = new sap.ui.model.Filter({
					filters: [
						new Filter("TID", sap.ui.model.FilterOperator.EQ, sQuery),
					]
				});
			}
			// update list binding
			var list = this.getView().byId("gridlist");
			var binding = list.getBinding("items");
			binding.filter(aFilter);
		},
		onPress: function (oEvent) {
			var that = this;

			var path = oEvent.getSource().getBindingContextPath();
			var patharray = path.split('/');
			var nindex = patharray[patharray.length - 1];
			var oData = sap.ui.getCore().byId('Master').getModel('oStudentModel').getData()[nindex];
			var studentID = oData.StudentId;

			var oShell = sap.ui.getCore().byId('Shell');
			dataManagerLib.getStudentDetail(studentID, function (response) {

					var oStudentData = response.results;

					oStudentData.forEach(function (oValue) {

						//Student Data 
						if (oValue.Key === 'Header') {
							var oStudentHeader = JSON.parse(oValue.Value);
							var oHeaderModel = new JSONModel(oStudentHeader);
							oShell.setModel(oHeaderModel, "oHeaderModel");
						}

						//All Data
						if (oValue.Key === 'All Data') {
							var oAllData = JSON.parse(oValue.Value);
							var oAllDataModel = new JSONModel(oAllData);
							// sap.ui.getCore().byId('Detail').setModel(oAllDataModel, "oAllDataModel");
							oShell.setModel(oAllDataModel, "oAllDataModel");
							// sap.ui.getCore().byId('Master').getModel('oAllDataModel').refresh();
						}

						//Section B Data
						if (oValue.Key === 'Sec B') {
							var oSecBData = JSON.parse(oValue.Value);
							var oSectionBModel = new JSONModel(oSecBData);
							// sap.ui.getCore().byId('Detail').setModel(oSectionBModel, "oSectionBModel");
							oShell.setModel(oSectionBModel, "oSectionBModel");
							// sap.ui.getCore().byId('Master').getModel('oSectionBModel').refresh();
						}

						//Section B Table Data
						if (oValue.Key === 'Sec B Tbl') {
							var oSecBTblData = JSON.parse(oValue.Value);
							var oSectionBTblModel = new JSONModel(oSecBTblData);
							// sap.ui.getCore().byId('Detail').setModel(oSectionBTblModel, "oSectionBTblModel");
							oShell.setModel(oSectionBTblModel, "oSectionBTblModel");
							// sap.ui.getCore().byId('Master').getModel('oSectionBTblModel').refresh();
						}

						//Section C Data
						if (oValue.Key === 'Sec C') {
							var oSecCData = JSON.parse(oValue.Value);
							var oSectionCModel = new JSONModel(oSecCData);
							// sap.ui.getCore().byId('Detail').setModel(oSectionCModel, "oSectionCModel");
							oShell.setModel(oSectionCModel, "oSectionCModel");
							// sap.ui.getCore().byId('Master').getModel('oSectionCModel').refresh();
						}

						//Section D Data
						if (oValue.Key === 'Sec D') {
							var oSecDData = JSON.parse(oValue.Value);
							var oSectionDModel = new JSONModel(oSecDData);
							// sap.ui.getCore().byId('Detail').setModel(oSectionDModel, "oSectionDModel");
							oShell.setModel(oSectionDModel, "oSectionDModel");
							// sap.ui.getCore().byId('Master').getModel('oSectionDModel').refresh();
						}

						//Section D Table Data
						if (oValue.Key === 'Sec D Tbl') {
							var oSecDTblData = JSON.parse(oValue.Value);
							var oSectionDTBLModel = new JSONModel(oSecDTblData);
							// sap.ui.getCore().byId('Detail').setModel(oSectionDTBLModel, "oSectionDTBLModel");
							oShell.setModel(oSectionDTBLModel, "oSectionDTBLModel");
							// sap.ui.getCore().byId('Master').getModel('oSectionDTBLModel').refresh();
						}

						//Section E Data
						if (oValue.Key === 'Sec E') {
							var oSecEData = JSON.parse(oValue.Value);
							var oSectionEModel = new JSONModel(oSecEData);
							// sap.ui.getCore().byId('Detail').setModel(oSectionEModel, "oSectionEModel");
							oShell.setModel(oSectionEModel, "oSectionEModel");
							// sap.ui.getCore().byId('Master').getModel('oSectionEModel').refresh();
						}

						//Section E 1 Table Data
						if (oValue.Key === 'Sec E 1') {
							var oSecE1Data = JSON.parse(oValue.Value);
							var oSectionETbl1Model = new JSONModel(oSecE1Data);
							// sap.ui.getCore().byId('Detail').setModel(oSectionETbl1Model, "oSectionETbl1Model");
							oShell.setModel(oSectionETbl1Model, "oSectionETbl1Model");
							// sap.ui.getCore().byId('Master').getModel('oSectionETbl1Model').refresh();
						}

						//Section E 2 Table Data
						if (oValue.Key === 'Sec E 2') {
							var oSecE2Data = JSON.parse(oValue.Value);
							var oSectionETbl2Model = new JSONModel(oSecE2Data);
							// sap.ui.getCore().byId('Detail').setModel(oSectionETbl2Model, "oSectionETbl2Model");
							oShell.setModel(oSectionETbl2Model, "oSectionETbl2Model");
							// sap.ui.getCore().byId('Master').getModel('oSectionETbl2Model').refresh();
						}

						//Section F Data
						if (oValue.Key === 'Sec F') {
							var oSecFData = JSON.parse(oValue.Value);
							var oSectionFModel = new JSONModel(oSecFData);
							// sap.ui.getCore().byId('Detail').setModel(oSectionFModel, "oSectionFModel");
							oShell.setModel(oSectionFModel, "oSectionFModel");
							// sap.ui.getCore().byId('Master').getModel('oSectionFModel').refresh();
						}

						//Annexure A Data
						if (oValue.Key === 'Ann A') {
							var oAnxAData = JSON.parse(oValue.Value);
							var oAnnexureAModel = new JSONModel(oAnxAData);
							// sap.ui.getCore().byId('Detail').setModel(oAnnexureAModel, "oAnnexureAModel");
							oShell.setModel(oAnnexureAModel, "oAnnexureAModel");
							// sap.ui.getCore().byId('Master').getModel('oAnnexureAModel').refresh();
						}

						//Annexure B Data
						if (oValue.Key === 'Ann B') {
							var oAnxBData = JSON.parse(oValue.Value);
							var oAnnexureBModel = new JSONModel(oAnxBData);
							// sap.ui.getCore().byId('Detail').setModel(oAnnexureBModel, "oAnnexureBModel");
							oShell.setModel(oAnnexureBModel, "oAnnexureBModel");
							// sap.ui.getCore().byId('Master').getModel('oAnnexureBModel').refresh();
						}

						//Annexure C Data
						if (oValue.Key === 'Ann C') {
							var oAnxCData = JSON.parse(oValue.Value);
							var oAnnexureCModel = new JSONModel(oAnxCData);
							// sap.ui.getCore().byId('Detail').setModel(oAnnexureCModel, "oAnnexureCModel");
							oShell.setModel(oAnnexureCModel, "oAnnexureCModel");
							// sap.ui.getCore().byId('Master').getModel('oAnnexureCModel').refresh();
						}

						//Annexure D Data
						if (oValue.Key === 'Ann D') {
							var oAnxDData = JSON.parse(oValue.Value);
							var oAnnexureDModel = new JSONModel(oAnxDData);
							// sap.ui.getCore().byId('Detail').setModel(oAnnexureDModel, "oAnnexureDModel");
							oShell.setModel(oAnnexureDModel, "oAnnexureDModel");
							// sap.ui.getCore().byId('Master').getModel('oAnnexureDModel').refresh();
						}

						//Annexure E Data
						if (oValue.Key === 'Ann E') {
							var oAnxEData = JSON.parse(oValue.Value);
							var oAnnexureEModel = new JSONModel(oAnxEData);
							// sap.ui.getCore().byId('Detail').setModel(oAnnexureEModel, "oAnnexureEModel");
							oShell.setModel(oAnnexureEModel, "oAnnexureEModel");
							// sap.ui.getCore().byId('Master').getModel('oAnnexureEModel').refresh();
						}

						//Annexure F Data
						if (oValue.Key === 'Ann F') {
							var oAnxFData = JSON.parse(oValue.Value);
							var oAnnexureFModel = new JSONModel(oAnxFData);
							// sap.ui.getCore().byId('Detail').setModel(oAnnexureFModel, "oAnnexureFModel");
							oShell.setModel(oAnnexureFModel, "oAnnexureFModel");
							// sap.ui.getCore().byId('Master').getModel('oAnnexureFModel').refresh();
						}

						//Annexure G Data
						if (oValue.Key === 'Ann G') {
							var oAnxGData = JSON.parse(oValue.Value);
							var oAnnexureGModel = new JSONModel(oAnxGData);
							// sap.ui.getCore().byId('Detail').setModel(oAnnexureGModel, "oAnnexureGModel");
							oShell.setModel(oAnnexureGModel, "oAnnexureGModel");
							// sap.ui.getCore().byId('Master').getModel('oAnnexureGModel').refresh();
						}

						//Annexure H Data
						if (oValue.Key === 'Ann H') {
							var oAnxHData = JSON.parse(oValue.Value);
							var oAnnexureHModel = new JSONModel(oAnxHData);
							// sap.ui.getCore().byId('Detail').setModel(oAnnexureHModel, "oAnnexureHModel");
							oShell.setModel(oAnnexureHModel, "oAnnexureHModel");
							// sap.ui.getCore().byId('Master').getModel('oAnnexureHModel').refresh();
						}

					});

					// var oData = JSON.parse(response.EvJson);
					// var oStudentModel = new JSONModel(oData);
					// oShell.setModel(oStudentModel, "oStudentModel");

				},
				function (error) {
					console.log("error");
				});
			this.nav.to("Detail");

		},
	});
});