sap.ui.define([
	"WF_STAGE2/Z_FAF_WF_STAGE/test/unit/controller/Master.controller"
], function () {
	"use strict";
});