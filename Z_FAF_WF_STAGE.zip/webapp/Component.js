sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"WF_STAGE2/Z_FAF_WF_STAGE/model/models",
	"WF_STAGE2/Z_FAF_WF_STAGE/util/dataManagerLib"
], function (UIComponent, Device, models, dataManagerLib) {
	"use strict";

	return UIComponent.extend("WF_STAGE2.Z_FAF_WF_STAGE.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function () {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// enable routing
			this.getRouter().initialize();

			// set the device model
			this.setModel(models.createDeviceModel(), "device");
			var sUrl = "/sap/opu/odata/sap/Z_FAF_WF_STAGE_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
			sap.ui.getCore().setModel(oModel);
			dataManagerLib.init(oModel);
		}
	});
});