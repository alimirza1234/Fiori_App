sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device"
], function (JSONModel, Device) {
	"use strict";
	var _modelBase = null;
	return {
		init: function (oDataModel) {
			_modelBase = oDataModel;
			_modelBase.setCountSupported(false);
		},
		getoDataModel: function () {
			return _modelBase;
		},
		oModelRefresh: function () {
			_modelBase.refresh(true, false);
		},
		_getOData: function (sPath, oContext, oUrlParams, successCallback, errorCallback) {
			_modelBase.read(sPath, oContext, oUrlParams, true, function (response) {
				successCallback(response);
			}, function (response) {
				errorCallback(response);
			});
		},
		_postData: function (sPath, oContext, sucessCallback, errorCallback) {
			_modelBase.create(sPath, oContext, null, sucessCallback, errorCallback)
		},

		getHeaderData: function (successCallback, errorCallback) {
			var sPath = "Initial_set?$filter=IvCall eq 'I'"; //personalInfoSet(ICall='R')";
			//	var sPath = "Initial_call_set?$filter=ICall eq 'R'";

			this._getOData(sPath, null, null, function (objResponse) {
				var oResult = objResponse;

				successCallback(oResult);
			}, function (objResponse) {
				//console.log("Error");
				errorCallback(objResponse);
			});
		},

		getStudentDetail: function (iv_studentID, successCallback, errorCallback) {
			var sPath = "Detail_set?$filter=IvCall eq 'D' and IvStudentNo eq '" + iv_studentID + "'";

			this._getOData(sPath, null, null, function (objResponse) {
				var oResult = objResponse;

				successCallback(oResult);
			}, function (objResponse) {
				//console.log("Error");
				errorCallback(objResponse);
			});

		},

		Approve: function (IvStudentNo, IvRemarks, successCallback, errorCallback) {
			var sPath = "Approve_set(IvCall='A',IvStudentNo='" + IvStudentNo + "',IvRemarks='" + IvRemarks + "')"; //personalInfoSet(ICall='R')";
			//	var sPath = "Initial_call_set?$filter=ICall eq 'R'";

			this._getOData(sPath, null, null, function (objResponse) {
				var oResult = objResponse;

				successCallback(oResult);
			}, function (objResponse) {
				//console.log("Error");
				errorCallback(objResponse);
			});
		},

		Reject: function (IvStudentNo, IvRemarks, successCallback, errorCallback) {
			var sPath = "Approve_set(IvCall='R',IvStudentNo='" + IvStudentNo + "',IvRemarks='" + IvRemarks + "')"; //personalInfoSet(ICall='R')";
			//	var sPath = "Initial_call_set?$filter=ICall eq 'R'";

			this._getOData(sPath, null, null, function (objResponse) {
				var oResult = objResponse;

				successCallback(oResult);
			}, function (objResponse) {
				//console.log("Error");
				errorCallback(objResponse);
			});
		},

		saveData: function (oObject, sucessCallback, errorCallback) {
			var sPath = "save_data_set";

			this._postData(sPath, oObject,
				function (objResponse) {
					var oResult = objResponse;
					sucessCallback(oResult);
				},
				function (objResponse) {
					console.log("Error");
					errorCallback(objResponse);
				});

		},

	};
});