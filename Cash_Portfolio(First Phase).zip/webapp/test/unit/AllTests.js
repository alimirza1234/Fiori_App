sap.ui.define([
	"Cash_Portal/Cash_Portfolio/test/unit/controller/App.controller"
], function () {
	"use strict";
});