sap.ui.define([
	"sap/ui/core/mvc/Controller",
	'sap/ui/model/json/JSONModel',
	// 'sap/viz/ui5/data/FlattenedDataset',
	// 'sap/viz/ui5/controls/common/feeds/FeedItem',
	// 'sap/m/Label',
	// 'sap/m/ColumnListItem',
	// 'sap/m/library',
	// 'sap/m/MessageToast',
	// 'sap/m/Column',
	// 'sap/viz/ui5/controls/common/feeds/AnalysisObject',
	// 'sap/suite/ui/commons/ChartContainerContent',
	// 'sap/ui/core/Item',
	// 'sap/m/Table',
	// 'sap/viz/ui5/controls/Popover',
	// 'sap/viz/ui5/format/ChartFormatter',
	// 'sap/viz/ui5/api/env/Format',
	"sap/ui/core/routing/History",
], function (Controller, JSONModel, FlattenedDataset, FeedItem, Label, ColumnListItem, MobileLibrary, MessageToast, Column,
	AnalysisObject, ChartContainerContent, Item, Table, Popover, ChartFormatter, Format, History) {
	"use strict";

	return Controller.extend("Cash_Portal.Cash_Portfolio.controller.Master", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf Cash_Portal.Cash_Portfolio.view.Master
		 */

		onInit: function () {
			var oVizFrame = this.getView().byId("idVizFrame_1");
			var oModel = new sap.ui.model.json.JSONModel();
			var data = {
				'Cars': [{
					"Model": "Total",
					"Value": "758620"

				}, {
					"Model": "DEBT AND INVESTMENT",
					"Value": "431160"

				}, {
					"Model": "Cash Position",
					"Value": "231160"

				}]
			};
			oModel.setData(data);

			var oDataSet = new sap.viz.ui5.data.FlattenedDataset({
				//horizontal
				dimensions: [{

					name: 'Bank',
					value: "{Model}"
				}],
				measures: [{
					//vertical
					name: 'Amount',
					value: "{Value}",

				}],

				data: {
					path: "/Cars"
				}

			});
			oVizFrame.setDataset(oDataSet);
			oVizFrame.setModel(oModel);
			oVizFrame.setVizType('bar');

			oVizFrame.setVizProperties({
				plotArea: {
					colorPalette: d3.scale.category20().range()

				}
			});
			var feedValueAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
					'uid': "valueAxis",
					'type': "Measure",
					'values': ["Amount"]
				}),
				feedCategoryAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
					'uid': "categoryAxis",
					'type': "Dimension",
					'values': ["Bank"]
				});

			oVizFrame.addFeed(feedValueAxis);
			oVizFrame.addFeed(feedCategoryAxis);

			this.oPopOver = this.getView().byId("idPopOver");
			// uiConfig="{applicationSet:'fiori'}"
			// var popoverProps = {};
			// var chartPopover = new sap.viz.ui5.controls.Popover();
			this.oPopOver.connect(oVizFrame.getVizUid());

			this.oPopOver.setActionItems([{

				type: 'action',
				text: 'TOTAL',
				press: function (oEvent) {
					sap.ui.getCore().byId("App").to(sap.ui.getCore().byId("Detail"));
				}
			}, {

				type: 'action',
				text: '"DEBT AND INVESTMENT',
				press: function (oEvent) {
					// sap.ui.getCore().byId("App").to(sap.ui.getCore().byId("Detail"));
				}
			}, {

				type: 'action',
				text: 'CASH POTION',
				press: function (oEvent) {
					// sap.ui.getCore().byId("App").to(sap.ui.getCore().byId("Detail"));
				}
			}]);
			// this.oPopOver.setFormatString(formatPattern.STANDARDFLOAT);

			// InitPageUtil.initPageSettings(this.getView());

			// var ActionPerform = new sap.m.ActionListItem({})
			// var Json = [{
			// 	"Manpower": [{
			// 		"Year": 2001,
			// 		"cash": "EUR",
			// 		"Profit": 120000,
			// 		"Unit Price": 1117.60,
			// 		"Units Available": 13076,
			// 		"Cost": 139033.42,
			// 		"Revenue": 207685.42,
			// 		"Units Sold": 4437,
			// 		"Catogery": "Export",
			// 		"Cost12": ""
			// 	}, {
			// 		"Year": 2001,
			// 		"cash": "Dollar",
			// 		"Profit": 145000,
			// 		"Unit Price": 1117.60,
			// 		"Units Available": 13076,
			// 		"Cost": 139033.42,
			// 		"Revenue": 207685.42,
			// 		"Units Sold": 4437,
			// 		"Catogery": "Export",
			// 		"Cost12": ""
			// 	}]
			// }, {
			// 	"Manpower": [{
			// 		"Year": 2001,
			// 		"City": "Washington",
			// 		"Profit": 170,
			// 		"Unit Price": 1117.60,
			// 		"Units Available": 13076,
			// 		"Cost": 139033.42,
			// 		"Revenue": 207685.42,
			// 		"Units Sold": 4437,
			// 		"Catogery": "Export",
			// 		"Cost12": ""
			// 	}]
			// }];

			// var oModel = new sap.ui.model.json.JSONModel();
			// oModel.setData(Json);
			// this.getView().setModel(oModel, "MainModel");
			// this.changeData(0);
		},
		// changeData: function (sPath) {
		// 	this.getView().bindElement({
		// 		path: '/' + sPath,
		// 		model: "MainModel"
		// 	});
		// }

		/**
		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf Cash_Portal.Cash_Portfolio.view.Master
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf Cash_Portal.Cash_Portfolio.view.Master
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf Cash_Portal.Cash_Portfolio.view.Master
		 */
		//	onExit: function() {
		//
		//	}

	});

});